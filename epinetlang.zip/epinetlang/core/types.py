"""Système de types d'EpiNetLang : types déclarés + analyse dimensionnelle.

Chaque quantité possède une dimension ``individus^a · temps^b`` :

* ``rate``        : temps⁻¹, ≥ 0
* ``probability`` : sans dimension, dans [0, 1]
* ``count``       : individus, ≥ 0
* ``time``        : temps, ≥ 0
* ``real``        : sans dimension
* compartiment    : individus

Le flux d'une transition doit avoir la dimension individus·temps⁻¹.
Cette règle détecte par exemple l'oubli classique de ``/ N`` dans
``beta * S * I`` (dimension individus²·temps⁻¹).

Les littéraux numériques sont *polymorphes* (dimension inconnue, ``None``) :
``0.01 * S`` est accepté comme flux, l'utilisateur étant responsable de l'unité.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from fractions import Fraction

from . import ast
from .errors import ERROR, Diagnostic

_SUP = str.maketrans("-0123456789/", "⁻⁰¹²³⁴⁵⁶⁷⁸⁹ᐟ")


@dataclass(frozen=True)
class Dim:
    pop: Fraction = Fraction(0)
    time: Fraction = Fraction(0)

    def __mul__(self, o: "Dim") -> "Dim":
        return Dim(self.pop + o.pop, self.time + o.time)

    def __truediv__(self, o: "Dim") -> "Dim":
        return Dim(self.pop - o.pop, self.time - o.time)

    def __pow__(self, n) -> "Dim":
        n = Fraction(n)
        return Dim(self.pop * n, self.time * n)

    @property
    def dimensionless(self) -> bool:
        return self.pop == 0 and self.time == 0

    def __str__(self) -> str:
        if self.dimensionless:
            return "sans dimension"
        parts = []
        for base, e in (("individus", self.pop), ("temps", self.time)):
            if e == 1:
                parts.append(base)
            elif e != 0:
                parts.append(base + str(e).translate(_SUP))
        return "·".join(parts)


DIMENSIONLESS = Dim()
POPULATION = Dim(Fraction(1), Fraction(0))
TIME = Dim(Fraction(0), Fraction(1))
RATE = Dim(Fraction(0), Fraction(-1))
FLOW = POPULATION / TIME


@dataclass(frozen=True)
class EpiType:
    name: str
    dim: Dim
    lower: float = -math.inf
    upper: float = math.inf
    description: str = ""

    def check_value(self, v: float) -> str | None:
        if math.isnan(v):
            return "la valeur n'est pas un nombre (NaN)"
        if v < self.lower or v > self.upper:
            lo = "-∞" if self.lower == -math.inf else f"{self.lower:g}"
            hi = "+∞" if self.upper == math.inf else f"{self.upper:g}"
            return f"valeur {v:g} hors du domaine [{lo}, {hi}] du type « {self.name} »"
        return None


TYPES: dict[str, EpiType] = {
    "rate": EpiType("rate", RATE, 0.0, math.inf, "taux par unité de temps"),
    "probability": EpiType("probability", DIMENSIONLESS, 0.0, 1.0, "probabilité ou proportion"),
    "count": EpiType("count", POPULATION, 0.0, math.inf, "effectif d'individus"),
    "time": EpiType("time", TIME, 0.0, math.inf, "durée ou date"),
    "real": EpiType("real", DIMENSIONLESS, -math.inf, math.inf, "réel sans dimension"),
}
TYPES["fraction"] = TYPES["probability"]
COMPARTMENT = EpiType("compartment", POPULATION, 0.0, math.inf, "compartiment")

# Fonctions intégrées : nom -> (arité, -1 = variable)
BUILTINS: dict[str, int] = {
    "exp": 1, "log": 1, "log10": 1, "sqrt": 1, "abs": 1, "sin": 1, "cos": 1, "tanh": 1,
    "min": -1, "max": -1, "step": 1,
    "contact": 1,      # proportion de C parmi les contacts (C/N en champ moyen)
    "neighbours": 1,   # nombre de voisins dans C (⟨k⟩·C/N en champ moyen)
    "total": 0,        # population totale vivante
}
RESERVED_NAMES = frozenset({"t"} | set(BUILTINS))
_DIMLESS_FUNCS = {"exp", "log", "log10", "sin", "cos", "tanh"}


def lookup_type(name: str) -> EpiType | None:
    return TYPES.get(name)


def compatible(a: Dim | None, b: Dim | None) -> bool:
    return a is None or b is None or a == b


class TypeChecker:
    """Inférence de dimension sur une expression ; consigne les erreurs."""

    def __init__(self, symbols: dict[str, Dim | None], compartments: set[str],
                 diagnostics: list[Diagnostic]):
        self.symbols = symbols
        self.compartments = compartments
        self.diagnostics = diagnostics

    def _error(self, msg: str, node: ast.Node, hint: str | None = None) -> None:
        self.diagnostics.append(Diagnostic(ERROR, msg, node.pos, hint, code="TYP"))

    def infer(self, e: ast.Expr) -> Dim | None:
        if isinstance(e, ast.Number):
            return None
        if isinstance(e, ast.Name):
            if e.id == "t":
                return TIME
            if e.id not in self.symbols:
                self._error(f"identifiant « {e.id} » non déclaré", e)
                return None
            return self.symbols[e.id]
        if isinstance(e, ast.UnaryOp):
            return self.infer(e.operand)
        if isinstance(e, ast.BinOp):
            return self._binop(e)
        if isinstance(e, ast.Call):
            return self._call(e)
        raise TypeError(e)

    def _binop(self, e: ast.BinOp) -> Dim | None:
        left = self.infer(e.left)
        if e.op == "^":
            right = self.infer(e.right)
            if right is not None and not right.dimensionless:
                self._error(f"l'exposant doit être sans dimension (trouvé {right})", e.right)
            if left is None or left.dimensionless:
                return left
            if isinstance(e.right, ast.Number):
                return left ** Fraction(e.right.value).limit_denominator(64)
            self._error(f"une quantité de dimension {left} ne peut être élevée qu'à une "
                         f"puissance littérale", e)
            return None
        right = self.infer(e.right)
        if e.op in "+-":
            if not compatible(left, right):
                self._error(f"addition de dimensions incompatibles : {left} {e.op} {right}", e)
                return None
            return left if left is not None else right
        if left is None or right is None:
            return None
        return left * right if e.op == "*" else left / right

    def _call(self, e: ast.Call) -> Dim | None:
        f = e.func
        if f not in BUILTINS:
            self._error(f"fonction inconnue « {f}() »", e,
                        "fonctions disponibles : " + ", ".join(sorted(BUILTINS)))
            return None
        arity = BUILTINS[f]
        if (arity >= 0 and len(e.args) != arity) or (arity < 0 and len(e.args) < 2):
            attendu = arity if arity >= 0 else "au moins 2"
            self._error(f"{f}() attend {attendu} argument(s), {len(e.args)} fourni(s)", e)
            return None
        if f in ("contact", "neighbours"):
            arg = e.args[0]
            if not (isinstance(arg, ast.Name) and arg.id in self.compartments):
                self._error(f"l'argument de {f}() doit être un nom de compartiment", e)
            return DIMENSIONLESS
        if f == "total":
            return POPULATION
        dims = [self.infer(a) for a in e.args]
        if f in _DIMLESS_FUNCS:
            if dims[0] is not None and not dims[0].dimensionless:
                self._error(f"{f}() exige un argument sans dimension (trouvé {dims[0]})", e)
            return DIMENSIONLESS
        if f == "sqrt":
            return None if dims[0] is None else dims[0] ** Fraction(1, 2)
        if f == "step":
            return DIMENSIONLESS
        if f in ("min", "max"):
            known = [d for d in dims if d is not None]
            if any(d != known[0] for d in known):
                self._error(f"{f}() : arguments de dimensions différentes", e)
            return known[0] if known else None
        return dims[0]  # abs
