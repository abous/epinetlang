"""Vérificateur sémantique d'EpiNetLang.

Contrôles effectués (codes entre crochets dans les messages) :

* [NOM] déclarations dupliquées, noms réservés, identifiants non déclarés,
  paramètres utilisés avant leur déclaration ;
* [TYP] analyse dimensionnelle (voir ``core.types``) ;
* [DOM] domaines de valeurs (probabilité dans [0, 1], taux ≥ 0, effectifs ≥ 0) ;
* [TRA] cohérence des transitions (compartiments existants, source ≠ cible…) ;
* [RES] configuration du réseau ;
* [INT] interventions (dates, cibles, opérations autorisées) ;
* [SIM] configuration de simulation.
"""
from __future__ import annotations

import math
from collections import Counter

from . import ast
from .errors import ERROR, INFO, WARNING, Diagnostic, EpiSemanticError
from .model import NETWORK_TYPES, SIM_METHODS, evaluate_constant
from .types import (BUILTINS, COMPARTMENT, DIMENSIONLESS, FLOW, POPULATION, RATE,
                    RESERVED_NAMES, TIME, Dim, TypeChecker, lookup_type)

NETWORK_KEYS = {"type", "nodes", "seed", "file", "mean_degree", "p", "m", "k", "rewiring"}
SIM_KEYS = {"t_start", "t_end", "dt", "method", "seed", "output_every", "replicates"}


class ValidationReport:
    def __init__(self, model_name: str, diagnostics: list[Diagnostic]):
        self.model_name = model_name
        self.diagnostics = diagnostics

    @property
    def errors(self) -> list[Diagnostic]:
        return [d for d in self.diagnostics if d.severity == ERROR]

    @property
    def warnings(self) -> list[Diagnostic]:
        return [d for d in self.diagnostics if d.severity == WARNING]

    @property
    def ok(self) -> bool:
        return not self.errors

    def raise_if_errors(self) -> None:
        if self.errors:
            raise EpiSemanticError(self.diagnostics)

    def __str__(self) -> str:
        head = (f"Modèle {self.model_name} : {len(self.errors)} erreur(s), "
                f"{len(self.warnings)} avertissement(s)")
        return "\n".join([head] + [str(d) for d in self.diagnostics])


class Validator:
    def __init__(self, decl: ast.ModelDecl):
        self.decl = decl
        self.diags: list[Diagnostic] = []
        self.param_dims: dict[str, Dim | None] = {}
        self.param_values: dict[str, float] = {}
        self.compartments: set[str] = set()

    # -- utilitaires ----------------------------------------------------------
    def _add(self, sev: str, code: str, msg: str, node=None, hint: str | None = None) -> None:
        self.diags.append(Diagnostic(sev, msg, getattr(node, "pos", None), hint, code))

    def _checker(self, with_compartments: bool = True) -> TypeChecker:
        symbols: dict[str, Dim | None] = dict(self.param_dims)
        if with_compartments:
            symbols.update({c: POPULATION for c in self.compartments})
        return TypeChecker(symbols, self.compartments if with_compartments else set(), self.diags)

    def _const(self, e: ast.Expr, what: str) -> float | None:
        """Évalue une expression ne dépendant que des paramètres."""
        bad = ast.names_in(e) - set(self.param_values)
        if bad:
            for n in sorted(bad):
                kind = "compartiment" if n in self.compartments else "identifiant"
                self._add(ERROR, "NOM", f"{what} : {kind} « {n} » non autorisé ici "
                                        f"(seuls les paramètres déjà déclarés le sont)", e)
            return None
        if ast.calls_in(e, "contact") or ast.calls_in(e, "neighbours") or ast.calls_in(e, "total"):
            self._add(ERROR, "NOM", f"{what} : contact()/neighbours()/total() interdits ici", e)
            return None
        try:
            return evaluate_constant(e, self.param_values)
        except Exception as exc:  # division par zéro, log négatif…
            self._add(ERROR, "DOM", f"{what} : évaluation impossible ({exc})", e)
            return None

    def _expect_dim(self, e: ast.Expr, expected: Dim, what: str, with_comp: bool = True) -> Dim | None:
        n_before = len(self.diags)
        dim = self._checker(with_comp).infer(e)
        if len(self.diags) > n_before:
            return None
        if dim is not None and dim != expected:
            hint = None
            if expected == FLOW and dim == POPULATION ** 2 / TIME:
                hint = "oubli de la division par la population (ex. beta * S * I / N) ?"
            elif expected == FLOW and dim == RATE:
                hint = "multiplier par le compartiment source (ex. gamma * I) ?"
            elif expected == FLOW and dim == POPULATION:
                hint = "il manque un taux (temps⁻¹) dans l'expression"
            self._add(ERROR, "TYP", f"{what} : dimension {dim}, attendu {expected}", e, hint)
        return dim

    # -- passes ---------------------------------------------------------------
    def validate(self) -> ValidationReport:
        self._names()
        self._parameters()
        self._compartments()
        self._transitions()
        self._network()
        self._interventions()
        self._simulation()
        self._structure()
        return ValidationReport(self.decl.name, self.diags)

    def _names(self) -> None:
        names = [(p.name, p) for p in self.decl.parameters] + \
                [(c.name, c) for c in self.decl.compartments]
        seen: dict[str, ast.Node] = {}
        for name, node in names:
            if name in RESERVED_NAMES:
                self._add(ERROR, "NOM", f"« {name} » est un nom réservé", node)
            if name in seen:
                self._add(ERROR, "NOM", f"« {name} » est déclaré deux fois", node,
                          f"première déclaration en {seen[name].pos}")
            else:
                seen[name] = node
        self.compartments = {c.name for c in self.decl.compartments}

    def _parameters(self) -> None:
        declared = [p.name for p in self.decl.parameters]
        for i, p in enumerate(self.decl.parameters):
            ty = lookup_type(p.type_name)
            if ty is None:
                self._add(ERROR, "TYP", f"type « {p.type_name} » inconnu pour « {p.name} »", p,
                          "types : rate, probability, count, time, real")
                ty = lookup_type("real")
            later = (ast.names_in(p.value) & set(declared[i:])) - self.compartments
            for n in sorted(later):
                self._add(ERROR, "NOM", f"« {n} » est utilisé avant sa déclaration", p)
            if not later:
                self._expect_dim(p.value, ty.dim, f"valeur de « {p.name} »", with_comp=False)
                v = self._const(p.value, f"valeur de « {p.name} »")
                if v is not None:
                    problem = ty.check_value(v)
                    if problem:
                        self._add(ERROR, "DOM", f"paramètre « {p.name} » : {problem}", p)
                    self.param_values[p.name] = v
            self.param_dims[p.name] = ty.dim
            self.param_values.setdefault(p.name, 0.0)

    def _compartments(self) -> None:
        if not self.decl.compartments:
            self._add(ERROR, "TRA", "le modèle ne déclare aucun compartiment", self.decl)
        for c in self.decl.compartments:
            self._expect_dim(c.initial, POPULATION, f"effectif initial de « {c.name} »", with_comp=False)
            v = self._const(c.initial, f"effectif initial de « {c.name} »")
            if v is not None and (problem := COMPARTMENT.check_value(v)):
                self._add(ERROR, "DOM", f"compartiment « {c.name} » : {problem}", c)

    def _check_transition(self, t: ast.TransitionDecl, expected: Dim, what: str) -> None:
        for end in (t.source, t.target):
            if end is not None and end not in self.compartments:
                self._add(ERROR, "TRA", f"{what} : compartiment « {end} » non déclaré", t)
        if t.source is None and t.target is None:
            self._add(ERROR, "TRA", f"{what} : « * -> * » n'a pas de sens", t)
        if t.source is not None and t.source == t.target:
            self._add(ERROR, "TRA", f"{what} : source et cible identiques (« {t.source} »)", t)
        if ast.calls_in(t.rate, "neighbours") and self.decl.network is None:
            self._add(ERROR, "RES", f"{what} : neighbours() exige un bloc « network »", t,
                      "utiliser contact(C) en champ moyen, ou déclarer un réseau")
        self._expect_dim(t.rate, expected, what)
        if (expected == FLOW and t.source is not None and t.source in self.compartments
                and t.source not in ast.names_in(t.rate)):
            self._add(WARNING, "TRA", f"{what} : le taux ne dépend pas de « {t.source} » ; "
                                      f"le compartiment peut devenir négatif", t,
                      f"forme usuelle : taux × {t.source}")

    def _transitions(self) -> None:
        labels = Counter(t.label for t in self.decl.transitions if t.label)
        for lab, n in labels.items():
            if n > 1:
                self._add(ERROR, "TRA", f"étiquette de transition « {lab} » utilisée {n} fois")
        if not self.decl.transitions:
            self._add(WARNING, "TRA", "aucune transition : le modèle est statique", self.decl)
        for t in self.decl.transitions:
            self._check_transition(t, FLOW, f"transition « {t.label or self._arrow(t)} »")

    @staticmethod
    def _arrow(t: ast.TransitionDecl) -> str:
        return f"{t.source or '*'} -> {t.target or '*'}"

    def _network(self) -> None:
        if self.decl.network is None:
            return
        values = {}
        for s in self.decl.network:
            if s.key not in NETWORK_KEYS:
                self._add(ERROR, "RES", f"réglage réseau inconnu « {s.key} »", s,
                          "réglages : " + ", ".join(sorted(NETWORK_KEYS)))
                continue
            if isinstance(s.value, str) or (isinstance(s.value, ast.Name) and s.value.id not in self.param_values):
                values[s.key] = s.value if isinstance(s.value, str) else s.value.id
            else:
                values[s.key] = self._const(s.value, f"réseau.{s.key}")
        ntype = values.get("type", "file" if "file" in values else "erdos_renyi")
        if ntype not in NETWORK_TYPES:
            self._add(ERROR, "RES", f"type de réseau « {ntype} » inconnu", self.decl,
                      "types : " + ", ".join(NETWORK_TYPES))
        nodes = values.get("nodes")
        if ntype != "file":
            if not isinstance(nodes, float) or nodes < 2 or not nodes.is_integer():
                self._add(ERROR, "RES", "réseau : « nodes » doit être un entier ≥ 2", self.decl)
                return
        if ntype == "barabasi_albert" and not (1 <= values.get("m", 2) < (nodes or 0)):
            self._add(ERROR, "RES", "barabasi_albert : il faut 1 ≤ m < nodes", self.decl)
        if ntype == "erdos_renyi" and "p" not in values and "mean_degree" not in values:
            self._add(ERROR, "RES", "erdos_renyi : préciser « p » ou « mean_degree »", self.decl)
        if "p" in values and isinstance(values["p"], float) and not 0 <= values["p"] <= 1:
            self._add(ERROR, "DOM", "réseau : « p » doit être une probabilité", self.decl)
        if ntype in ("watts_strogatz", "regular"):
            k = values.get("k", 4)
            if not isinstance(k, float) or k % 2 or k < 2 or k >= nodes:
                self._add(ERROR, "RES", f"{ntype} : « k » doit être pair, ≥ 2 et < nodes", self.decl)
        if ntype == "complete" and nodes and nodes > 5000:
            self._add(WARNING, "RES", f"graphe complet à {nodes:g} nœuds : mémoire importante", self.decl)
        for t in self.decl.transitions:
            if t.source is None:
                self._add(WARNING, "RES", f"transition « {self._arrow(t)} » (entrée extérieure) "
                                          f"ignorée par le simulateur sur réseau", t)
            elif ast.names_in(t.rate) and sum(isinstance(e, ast.Name) and e.id == t.source
                                              for e in ast.walk(t.rate)) != 1:
                self._add(WARNING, "RES", f"transition « {self._arrow(t)} » : le taux devrait être "
                                          f"linéaire en « {t.source} » pour le simulateur sur réseau", t)

    def _interventions(self) -> None:
        names = Counter(iv.name for iv in self.decl.interventions)
        for n, c in names.items():
            if c > 1:
                self._add(ERROR, "INT", f"intervention « {n} » déclarée {c} fois")
        for iv in self.decl.interventions:
            what = f"intervention « {iv.name} »"
            start = self._const(iv.start, f"{what} (date de début)")
            end = self._const(iv.end, f"{what} (date de fin)") if iv.end is not None else math.inf
            if start is not None and start < 0:
                self._add(ERROR, "INT", f"{what} : date négative", iv)
            if start is not None and end is not None and end <= start:
                self._add(ERROR, "INT", f"{what} : la fin ({end:g}) doit suivre le début ({start:g})", iv)
            if not iv.assigns and not iv.transitions:
                self._add(WARNING, "INT", f"{what} : aucune action", iv)
            for a in iv.assigns:
                self._check_assign(iv, a, what)
            for i, t in enumerate(iv.transitions):
                expected = FLOW if iv.kind == "window" else POPULATION
                self._check_transition(t, expected, f"{what}, transition {self._arrow(t)}")

    def _check_assign(self, iv: ast.InterventionDecl, a: ast.Assign, what: str) -> None:
        if a.target in self.param_dims:
            dim = self.param_dims[a.target]
            expected = DIMENSIONLESS if a.op in ("*=", "/=") else dim
            self._expect_dim(a.value, expected, f"{what}, « {a.target} {a.op} … »")
            if a.op in ("*=", "/=", "=") and not (ast.names_in(a.value) & self.compartments):
                v = self._const(a.value, f"{what}, « {a.target} {a.op} … »")
                if v is not None and a.op == "/=" and v == 0:
                    self._add(ERROR, "DOM", f"{what} : division par zéro", a)
        elif a.target in self.compartments:
            if iv.kind == "window":
                self._add(ERROR, "INT", f"{what} : modification directe de « {a.target} » "
                                        f"interdite dans une fenêtre « from … to »", a,
                          "utiliser une intervention ponctuelle « at t » ou une transition")
                return
            expected = DIMENSIONLESS if a.op in ("*=", "/=") else POPULATION
            self._expect_dim(a.value, expected, f"{what}, « {a.target} {a.op} … »")
        else:
            self._add(ERROR, "NOM", f"{what} : « {a.target} » n'est ni un paramètre ni un compartiment", a)

    def _simulation(self) -> None:
        values = {}
        for s in self.decl.simulation:
            if s.key not in SIM_KEYS:
                self._add(ERROR, "SIM", f"réglage de simulation inconnu « {s.key} »", s,
                          "réglages : " + ", ".join(sorted(SIM_KEYS)))
            elif s.key == "method":
                m = s.value if isinstance(s.value, str) else getattr(s.value, "id", None)
                if m not in SIM_METHODS:
                    self._add(ERROR, "SIM", f"méthode « {m} » inconnue", s,
                              "méthodes : " + ", ".join(SIM_METHODS))
                values["method"] = m
            else:
                values[s.key] = self._const(s.value, f"simulation.{s.key}")
        t0, t1, dt = values.get("t_start", 0.0), values.get("t_end", 100.0), values.get("dt", 0.1)
        if None in (t0, t1, dt):
            return
        if t1 <= t0:
            self._add(ERROR, "SIM", f"t_end ({t1:g}) doit être supérieur à t_start ({t0:g})", self.decl)
        if dt <= 0:
            self._add(ERROR, "SIM", "dt doit être strictement positif", self.decl)
        elif dt > (t1 - t0):
            self._add(ERROR, "SIM", "dt est plus grand que la durée simulée", self.decl)
        elif (t1 - t0) / dt > 5e7:
            self._add(WARNING, "SIM", f"{(t1 - t0) / dt:.2g} pas de temps : simulation très longue", self.decl)
        for key in ("output_every", "replicates"):
            v = values.get(key)
            if v is not None and (v < 1 or not float(v).is_integer()):
                self._add(ERROR, "SIM", f"« {key} » doit être un entier ≥ 1", self.decl)
        if values.get("method") == "network" and self.decl.network is None:
            self._add(ERROR, "SIM", "method = network exige un bloc « network »", self.decl)

    def _structure(self) -> None:
        used = set()
        all_tr = list(self.decl.transitions) + [t for iv in self.decl.interventions for t in iv.transitions]
        for t in all_tr:
            used.update(x for x in (t.source, t.target) if x)
        for c in self.decl.compartments:
            if c.name not in used and self.decl.transitions:
                self._add(WARNING, "TRA", f"compartiment « {c.name} » isolé (aucune transition)", c)
        if not any(set(ast.names_in(t.rate) & self.compartments) - {t.source}
                   for t in self.decl.transitions if t.source and t.target):
            self._add(INFO, "TRA", "aucune transition par contact détectée : R0 non calculable", self.decl)


def validate(decl: ast.ModelDecl, raise_on_error: bool = False) -> ValidationReport:
    report = Validator(decl).validate()
    if raise_on_error:
        report.raise_if_errors()
    return report


__all__ = ["Validator", "ValidationReport", "validate", "BUILTINS"]
