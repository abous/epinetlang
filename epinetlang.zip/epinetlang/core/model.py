"""Représentation sémantique d'un modèle EpiNetLang validé.

``EpidemicModel`` est la forme « résolue » de l'AST : paramètres évalués,
conditions initiales numériques, transitions classées (infection ou non),
interventions converties en dates, configuration réseau et simulation.
Il fournit aussi un **interpréteur** d'expressions, utilisé par le simulateur
sur réseau, le calcul de R0 et comme référence pour tester le code compilé.
"""
from __future__ import annotations

import functools
import math
from dataclasses import dataclass, field
from typing import Callable, Mapping

import numpy as np

from . import ast
from .errors import EpiRuntimeError, SourcePos

# ---------------------------------------------------------------------------
# Interpréteur d'expressions
# ---------------------------------------------------------------------------
_FUNCS: dict[str, Callable] = {
    "exp": np.exp, "log": np.log, "log10": np.log10, "sqrt": np.sqrt, "abs": np.abs,
    "sin": np.sin, "cos": np.cos, "tanh": np.tanh,
}


class EvalContext:
    """Environnement d'évaluation : valeurs des noms + sémantique de contact().

    En champ moyen (EDO), ``contact(C) = C / total`` et
    ``neighbours(C) = ⟨k⟩ · C / total``. Le simulateur sur réseau remplace ces
    deux fonctions par des valeurs *locales* calculées nœud par nœud.
    """

    __slots__ = ("env", "_total", "mean_degree", "contact_fn", "neighbours_fn")

    def __init__(self, env: Mapping[str, object], total=None, mean_degree: float | None = None,
                 contact: Callable | None = None, neighbours: Callable | None = None):
        self.env = env
        self._total = total
        self.mean_degree = mean_degree
        self.contact_fn = contact
        self.neighbours_fn = neighbours

    def total(self):
        if self._total is None:
            raise EpiRuntimeError("total() n'est utilisable que dans les taux de transition")
        return self._total

    def contact(self, c: str):
        if self.contact_fn is not None:
            return self.contact_fn(c)
        tot = self.total()
        return self.env[c] / tot if tot > 0 else 0.0

    def neighbours(self, c: str):
        if self.neighbours_fn is not None:
            return self.neighbours_fn(c)
        if self.mean_degree is None:
            raise EpiRuntimeError("neighbours() exige un bloc network (degré moyen inconnu)")
        return self.mean_degree * self.contact(c)


def evaluate(e: ast.Expr, ctx: EvalContext):
    """Évalue une expression ; fonctionne sur des scalaires ou des tableaux numpy."""
    if isinstance(e, ast.Number):
        return e.value
    if isinstance(e, ast.Name):
        try:
            return ctx.env[e.id]
        except KeyError:
            raise EpiRuntimeError(f"identifiant « {e.id} » inconnu à l'exécution") from None
    if isinstance(e, ast.BinOp):
        a, b = evaluate(e.left, ctx), evaluate(e.right, ctx)
        if e.op == "+":
            return a + b
        if e.op == "-":
            return a - b
        if e.op == "*":
            return a * b
        if e.op == "/":
            if np.isscalar(b) and b == 0:
                raise EpiRuntimeError(f"division par zéro dans « {ast.expr_to_str(e)} »")
            return a / b
        return a ** b
    if isinstance(e, ast.UnaryOp):
        return -evaluate(e.operand, ctx)
    if isinstance(e, ast.Call):
        f = e.func
        if f == "contact":
            return ctx.contact(e.args[0].id)
        if f == "neighbours":
            return ctx.neighbours(e.args[0].id)
        if f == "total":
            return ctx.total()
        args = [evaluate(a, ctx) for a in e.args]
        if f == "min":
            return functools.reduce(np.minimum, args)
        if f == "max":
            return functools.reduce(np.maximum, args)
        if f == "step":
            x = args[0]
            return (1.0 if x >= 0 else 0.0) if np.isscalar(x) else np.where(x >= 0, 1.0, 0.0)
        return _FUNCS[f](args[0])
    raise TypeError(e)


def evaluate_constant(e: ast.Expr, env: Mapping[str, float]) -> float:
    return float(evaluate(e, EvalContext(env)))


# ---------------------------------------------------------------------------
# Structures du modèle
# ---------------------------------------------------------------------------
@dataclass
class Transition:
    label: str
    source: str | None
    target: str | None
    rate: ast.Expr
    drivers: tuple[str, ...] = ()        # compartiments (≠ source) dont dépend le taux
    pos: SourcePos | None = None

    @property
    def is_infection(self) -> bool:
        """Transition « par contact » : son taux dépend d'un autre compartiment."""
        return bool(self.drivers) and self.source is not None and self.target is not None

    def __str__(self) -> str:
        s = self.source or "*"
        d = self.target or "*"
        return f"{self.label}: {s} -> {d} : {ast.expr_to_str(self.rate)}"


@dataclass
class Intervention:
    name: str
    kind: str                                   # 'window' | 'pulse'
    start: float
    end: float                                  # math.inf si non borné ; = start pour 'pulse'
    param_changes: list[tuple[str, str, ast.Expr]] = field(default_factory=list)
    state_changes: list[tuple[str, str, ast.Expr]] = field(default_factory=list)
    transitions: list[Transition] = field(default_factory=list)

    def params_active(self, t: float) -> bool:
        """Les modifications de paramètres d'un 'pulse' sont permanentes après la date."""
        if self.kind == "pulse":
            return t >= self.start
        return self.start <= t < self.end

    def flows_active(self, t: float) -> bool:
        return self.kind == "window" and self.start <= t < self.end


@dataclass
class NetworkConfig:
    type: str = "erdos_renyi"
    nodes: int = 1000
    options: dict = field(default_factory=dict)
    seed: int | None = None
    file: str | None = None

    def mean_degree(self) -> float | None:
        o, n = self.options, self.nodes
        if "mean_degree" in o:
            return float(o["mean_degree"])
        if self.type == "erdos_renyi" and "p" in o:
            return float(o["p"]) * (n - 1)
        if self.type == "barabasi_albert":
            return 2.0 * float(o.get("m", 2))
        if self.type in ("watts_strogatz", "regular"):
            return float(o.get("k", 4))
        if self.type == "complete":
            return float(n - 1)
        return None


NETWORK_TYPES = ("erdos_renyi", "barabasi_albert", "watts_strogatz", "regular", "complete", "file")
SIM_METHODS = ("euler", "rk4", "rk45", "gillespie", "tau_leap", "network")


@dataclass
class SimulationConfig:
    t_start: float = 0.0
    t_end: float = 100.0
    dt: float = 0.1
    method: str = "rk4"
    seed: int | None = None
    output_every: int = 1
    replicates: int = 1


def setting_value(value, params: Mapping[str, float]):
    """Valeur d'un réglage : chaîne, symbole (ex. ``rk4``) ou nombre évalué."""
    if isinstance(value, str):
        return value
    if isinstance(value, ast.Name) and value.id not in params:
        return value.id
    return evaluate_constant(value, params)


# ---------------------------------------------------------------------------
# Modèle
# ---------------------------------------------------------------------------
class EpidemicModel:
    def __init__(self, decl: ast.ModelDecl, overrides: Mapping[str, float] | None = None):
        self.decl = decl
        self.name = decl.name
        self.overrides = dict(overrides or {})

        # Paramètres (évalués dans l'ordre de déclaration ; surcharges prioritaires)
        self.params: dict[str, float] = {}
        self.param_types: dict[str, str] = {}
        for p in decl.parameters:
            self.param_types[p.name] = p.type_name
            if p.name in self.overrides:
                self.params[p.name] = float(self.overrides[p.name])
            else:
                self.params[p.name] = evaluate_constant(p.value, self.params)
        unknown = set(self.overrides) - set(self.params)
        if unknown:
            raise EpiRuntimeError("paramètre(s) inconnu(s) : " + ", ".join(sorted(unknown)))

        self.compartments: list[str] = [c.name for c in decl.compartments]
        self.index = {c: i for i, c in enumerate(self.compartments)}
        self.initial = {c.name: evaluate_constant(c.initial, self.params) for c in decl.compartments}

        self.transitions = [self._transition(t, i) for i, t in enumerate(decl.transitions)]

        self.network: NetworkConfig | None = None
        if decl.network is not None:
            self.network = self._network(decl.network)

        self.simulation = self._simulation(decl.simulation)
        self.interventions = [self._intervention(iv) for iv in decl.interventions]

    # -- construction ---------------------------------------------------------
    def _transition(self, t: ast.TransitionDecl, i: int, prefix: str = "") -> Transition:
        refs = ast.names_in(t.rate) & set(self.compartments)
        drivers = tuple(sorted(refs - {t.source}))
        label = t.label or f"{prefix}{t.source or 'ext'}_{t.target or 'ext'}_{i}"
        return Transition(label, t.source, t.target, t.rate, drivers, t.pos)

    def _network(self, settings: list[ast.Setting]) -> NetworkConfig:
        cfg = NetworkConfig()
        for s in settings:
            v = setting_value(s.value, self.params)
            if s.key == "type":
                cfg.type = str(v)
            elif s.key == "nodes":
                cfg.nodes = int(v)
            elif s.key == "seed":
                cfg.seed = int(v)
            elif s.key == "file":
                cfg.file = str(v)
                cfg.type = "file"
            else:
                cfg.options[s.key] = v
        return cfg

    def _simulation(self, settings: list[ast.Setting]) -> SimulationConfig:
        cfg = SimulationConfig()
        if self.network is not None:
            cfg.method = "network"
        for s in settings:
            v = setting_value(s.value, self.params)
            if s.key in ("seed", "output_every", "replicates"):
                v = int(v)
            elif s.key in ("t_start", "t_end", "dt"):
                v = float(v)
            setattr(cfg, s.key, v)
        return cfg

    def _intervention(self, d: ast.InterventionDecl) -> Intervention:
        start = evaluate_constant(d.start, self.params)
        if d.kind == "pulse":
            end = start
        else:
            end = evaluate_constant(d.end, self.params) if d.end is not None else math.inf
        iv = Intervention(d.name, d.kind, start, end)
        for a in d.assigns:
            target = iv.param_changes if a.target in self.params else iv.state_changes
            target.append((a.target, a.op, a.value))
        iv.transitions = [self._transition(t, i, prefix=f"{d.name}_") for i, t in enumerate(d.transitions)]
        return iv

    # -- requêtes ------------------------------------------------------------
    def with_overrides(self, **overrides: float) -> "EpidemicModel":
        """Nouveau modèle où les paramètres dérivés sont recalculés."""
        merged = {**self.overrides, **overrides}
        return EpidemicModel(self.decl, merged)

    def initial_state(self, dtype=np.float64) -> np.ndarray:
        return np.array([self.initial[c] for c in self.compartments], dtype=dtype)

    def param_vector(self, params: Mapping[str, float] | None = None) -> np.ndarray:
        p = params or self.params
        return np.array([p[k] for k in self.params], dtype=np.float64)

    @property
    def total_population(self) -> float:
        return float(sum(self.initial.values()))

    @property
    def mean_degree(self) -> float | None:
        return self.network.mean_degree() if self.network else None

    @property
    def has_vital_dynamics(self) -> bool:
        trs = list(self.transitions) + [t for iv in self.interventions for t in iv.transitions]
        return any(t.source is None or t.target is None for t in trs)

    @property
    def conserves_population(self) -> bool:
        if self.has_vital_dynamics:
            return False
        return not any(iv.state_changes for iv in self.interventions)

    @property
    def infection_transitions(self) -> list[Transition]:
        return [t for t in self.transitions if t.is_infection]

    def context(self, t: float, y, params: Mapping[str, float]) -> EvalContext:
        env = dict(params)
        env.update(zip(self.compartments, y))
        env["t"] = t
        return EvalContext(env, total=float(np.sum(y)), mean_degree=self.mean_degree)

    def flows(self, t: float, y, params: Mapping[str, float] | None = None,
              transitions: list[Transition] | None = None) -> np.ndarray:
        """Valeur de chaque flux (interprété), dans l'ordre des transitions."""
        params = self.params if params is None else params
        trs = self.transitions if transitions is None else transitions
        ctx = self.context(t, y, params)
        return np.array([float(evaluate(tr.rate, ctx)) for tr in trs])

    def stoichiometry(self, transitions: list[Transition] | None = None) -> np.ndarray:
        trs = self.transitions if transitions is None else transitions
        m = np.zeros((len(self.compartments), len(trs)))
        for j, tr in enumerate(trs):
            if tr.source is not None:
                m[self.index[tr.source], j] -= 1
            if tr.target is not None:
                m[self.index[tr.target], j] += 1
        return m

    def rhs(self, t: float, y, params: Mapping[str, float] | None = None,
            transitions: list[Transition] | None = None) -> np.ndarray:
        trs = self.transitions if transitions is None else transitions
        return self.stoichiometry(trs) @ self.flows(t, y, params, trs)

    def describe(self) -> str:
        lines = [f"Modèle {self.name}",
                 f"  compartiments : {', '.join(f'{c}={self.initial[c]:g}' for c in self.compartments)}",
                 f"  paramètres    : {', '.join(f'{k}={v:g}' for k, v in self.params.items())}",
                 "  transitions   :"]
        for tr in self.transitions:
            tag = f"  [infection ← {', '.join(tr.drivers)}]" if tr.is_infection else ""
            lines.append(f"    {tr}{tag}")
        for iv in self.interventions:
            when = f"t = {iv.start:g}" if iv.kind == "pulse" else f"[{iv.start:g}, {iv.end:g})"
            lines.append(f"  intervention  : {iv.name} {when}")
        if self.network:
            lines.append(f"  réseau        : {self.network.type}, {self.network.nodes} nœuds, "
                         f"⟨k⟩ ≈ {self.mean_degree}")
        s = self.simulation
        lines.append(f"  simulation    : {s.method}, t ∈ [{s.t_start:g}, {s.t_end:g}], dt = {s.dt:g}")
        return "\n".join(lines)
