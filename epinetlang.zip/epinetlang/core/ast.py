"""Arbre de syntaxe abstraite (AST) d'EpiNetLang.

L'AST est produit par ``grammar.parser`` et consommé par le validateur
(``core.validator``) puis par le constructeur de modèle (``core.model``).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Iterator, Union

from .errors import SourcePos


@dataclass
class Node:
    pos: SourcePos | None = field(default=None, compare=False, repr=False, kw_only=True)


# --------------------------------------------------------------------------
# Expressions
# --------------------------------------------------------------------------
@dataclass
class Expr(Node):
    pass


@dataclass
class Number(Expr):
    value: float


@dataclass
class Name(Expr):
    id: str


@dataclass
class BinOp(Expr):
    op: str          # '+', '-', '*', '/', '^'
    left: Expr
    right: Expr


@dataclass
class UnaryOp(Expr):
    op: str          # '-'
    operand: Expr


@dataclass
class Call(Expr):
    func: str
    args: list[Expr]


# --------------------------------------------------------------------------
# Déclarations
# --------------------------------------------------------------------------
@dataclass
class ParamDecl(Node):
    name: str
    type_name: str
    value: Expr


@dataclass
class CompartmentDecl(Node):
    name: str
    initial: Expr


@dataclass
class TransitionDecl(Node):
    label: str | None
    source: str | None   # None = extérieur ('*') : naissances, importations
    target: str | None   # None = extérieur ('*') : décès, émigration
    rate: Expr


@dataclass
class Setting(Node):
    key: str
    value: Union[Expr, str]


@dataclass
class Assign(Node):
    """Instruction d'intervention : ``beta *= 0.5;`` ou ``I += 10;``."""
    target: str
    op: str              # '=', '+=', '-=', '*=', '/='
    value: Expr


@dataclass
class InterventionDecl(Node):
    name: str
    kind: str            # 'window' (from .. to ..) ou 'pulse' (at ..)
    start: Expr
    end: Expr | None
    assigns: list[Assign] = field(default_factory=list)
    transitions: list[TransitionDecl] = field(default_factory=list)


@dataclass
class ModelDecl(Node):
    name: str
    parameters: list[ParamDecl] = field(default_factory=list)
    compartments: list[CompartmentDecl] = field(default_factory=list)
    transitions: list[TransitionDecl] = field(default_factory=list)
    network: list[Setting] | None = None
    interventions: list[InterventionDecl] = field(default_factory=list)
    simulation: list[Setting] = field(default_factory=list)


@dataclass
class Program(Node):
    models: list[ModelDecl]


# --------------------------------------------------------------------------
# Utilitaires
# --------------------------------------------------------------------------
def walk(expr: Expr) -> Iterator[Expr]:
    """Parcours préfixe d'une expression."""
    yield expr
    if isinstance(expr, BinOp):
        yield from walk(expr.left)
        yield from walk(expr.right)
    elif isinstance(expr, UnaryOp):
        yield from walk(expr.operand)
    elif isinstance(expr, Call):
        for a in expr.args:
            yield from walk(a)


def names_in(expr: Expr) -> set[str]:
    """Identifiants référencés par une expression (hors noms de fonctions)."""
    return {e.id for e in walk(expr) if isinstance(e, Name)}


def calls_in(expr: Expr, func: str | None = None) -> list[Call]:
    return [e for e in walk(expr) if isinstance(e, Call) and (func is None or e.func == func)]


_PREC = {"+": 1, "-": 1, "*": 2, "/": 2, "^": 4}


def expr_to_str(expr: Expr, parent_prec: int = 0) -> str:
    """Réécrit une expression en syntaxe EpiNetLang (parenthèses minimales)."""
    if isinstance(expr, Number):
        v = expr.value
        return str(int(v)) if float(v).is_integer() and abs(v) < 1e15 else repr(v)
    if isinstance(expr, Name):
        return expr.id
    if isinstance(expr, Call):
        return f"{expr.func}({', '.join(expr_to_str(a) for a in expr.args)})"
    if isinstance(expr, UnaryOp):
        s = f"-{expr_to_str(expr.operand, 3)}"
        return f"({s})" if parent_prec > 3 else s
    if isinstance(expr, BinOp):
        p = _PREC[expr.op]
        if expr.op == "^":
            s = f"{expr_to_str(expr.left, p + 1)}^{expr_to_str(expr.right, p)}"
        else:
            s = f"{expr_to_str(expr.left, p)} {expr.op} {expr_to_str(expr.right, p + 1)}"
        return f"({s})" if p < parent_prec else s
    raise TypeError(f"nœud inconnu : {expr!r}")


def dump(node, indent: int = 0) -> str:
    """Affichage arborescent lisible de l'AST (commande ``epinetlang ast``)."""
    pad = "  " * indent
    if isinstance(node, Expr):
        return f"{pad}{expr_to_str(node)}"
    if isinstance(node, list):
        return "\n".join(dump(n, indent) for n in node)
    if not isinstance(node, Node):
        return f"{pad}{node!r}"
    lines = [f"{pad}{type(node).__name__}"]
    for name, value in node.__dict__.items():
        if name == "pos" or value is None or value == []:
            continue
        if isinstance(value, (Node, list)):
            lines.append(f"{pad}  {name}:")
            lines.append(dump(value, indent + 2))
        else:
            lines.append(f"{pad}  {name} = {value!r}")
    return "\n".join(lines)
