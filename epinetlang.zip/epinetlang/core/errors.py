"""Positions dans le source, diagnostics et exceptions d'EpiNetLang."""
from __future__ import annotations

from dataclasses import dataclass

ERROR = "erreur"
WARNING = "avertissement"
INFO = "info"


@dataclass(frozen=True)
class SourcePos:
    """Position (ligne, colonne) d'un élément dans le fichier source."""
    line: int = 0
    column: int = 0
    filename: str = "<source>"

    def __str__(self) -> str:
        return f"{self.filename}:{self.line}:{self.column}"


@dataclass
class Diagnostic:
    """Message produit par l'analyse (erreur, avertissement ou information)."""
    severity: str
    message: str
    pos: SourcePos | None = None
    hint: str | None = None
    code: str = ""

    @property
    def is_error(self) -> bool:
        return self.severity == ERROR

    def __str__(self) -> str:
        loc = f"{self.pos}: " if self.pos else ""
        code = f"[{self.code}]" if self.code else ""
        text = f"{loc}{self.severity}{code} : {self.message}"
        if self.hint:
            text += f"\n    → {self.hint}"
        return text


class EpiNetLangError(Exception):
    """Classe de base de toutes les erreurs du langage."""


class EpiSyntaxError(EpiNetLangError):
    """Erreur lexicale ou syntaxique."""

    def __init__(self, message: str, pos: SourcePos | None = None, hint: str | None = None):
        self.diagnostic = Diagnostic(ERROR, message, pos, hint, code="SYN")
        super().__init__(str(self.diagnostic))


class EpiSemanticError(EpiNetLangError):
    """Une ou plusieurs erreurs sémantiques (portée, types, cohérence)."""

    def __init__(self, diagnostics: list[Diagnostic]):
        self.diagnostics = list(diagnostics)
        errors = [d for d in self.diagnostics if d.is_error]
        super().__init__("\n".join(str(d) for d in errors) or "erreur sémantique")


class EpiRuntimeError(EpiNetLangError):
    """Erreur pendant la simulation ou l'analyse numérique."""
