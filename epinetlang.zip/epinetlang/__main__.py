"""Permet ``python -m epinetlang …``."""
import sys

from .cli import main

sys.exit(main())
