"""Interface en ligne de commande d'EpiNetLang.

    python -m epinetlang check   examples/sir_model.epi
    python -m epinetlang compile examples/sir_model.epi -t cpp -o sir.cpp
    python -m epinetlang run     examples/covid_cameroon.epi --csv covid.csv --plot covid.png
    python -m epinetlang r0      examples/seir_model.epi
    python -m epinetlang ir      examples/covid_cameroon.epi -O 2
    python -m epinetlang plan    examples/network_model.epi --profile minimal
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

from .core.errors import EpiNetLangError


def _overrides(pairs: list[str] | None) -> dict[str, float]:
    out = {}
    for item in pairs or []:
        if "=" not in item:
            raise SystemExit(f"--set attend nom=valeur (reçu « {item} »)")
        k, v = item.split("=", 1)
        out[k.strip()] = float(v)
    return out


def _load(args):
    from . import api
    m = api.load(args.file, getattr(args, "model", None))
    ov = _overrides(getattr(args, "set", None))
    return m.with_params(**ov) if ov else m


def cmd_check(args) -> int:
    from .core.validator import validate
    from .grammar.parser import parse
    program = parse(Path(args.file).read_text(encoding="utf-8"), args.file)
    status = 0
    for decl in program.models:
        report = validate(decl)
        print(report)
        status |= 0 if report.ok else 1
        if report.ok:
            from .core.model import EpidemicModel
            print(EpidemicModel(decl).describe())
    return status


def cmd_tokens(args) -> int:
    from .grammar.lexer import tokenize
    for tok in tokenize(Path(args.file).read_text(encoding="utf-8"), args.file):
        print(f"{tok.pos.line:>4}:{tok.pos.column:<3} {tok.type:<14} {tok.value!r}")
    return 0


def cmd_ast(args) -> int:
    from .core.ast import dump
    from .grammar.parser import parse
    print(dump(parse(Path(args.file).read_text(encoding="utf-8"), args.file)))
    return 0


def cmd_ir(args) -> int:
    m = _load(args)
    res = m.compile("python", args.opt)
    print((res.ir if args.raw else res.optimized).dump())
    print(f"\n; {res.stats}")
    return 0


def cmd_compile(args) -> int:
    m = _load(args)
    res = m.compile(args.target, args.opt)
    out = args.output or Path(args.file).with_suffix(res.extension).name
    if out == "-":
        sys.stdout.write(res.code)
    else:
        res.write(out)
        print(f"{res.summary()}\n→ {out}")
    return 0


def cmd_run(args) -> int:
    m = _load(args)
    kw = {k: v for k, v in (("t_end", args.t_end), ("dt", args.dt), ("seed", args.seed)) if v is not None}
    if args.replicates and args.replicates > 1:
        ens = m.ensemble(args.replicates, method=args.method or "tau_leap", seed=args.seed or 0,
                         **{k: v for k, v in kw.items() if k != "seed"})
        print(f"{args.replicates} réalisations — moyenne finale :")
        for c, v, lo, hi in zip(ens.compartments, ens.mean[-1], ens.quantile(0.05)[-1], ens.quantile(0.95)[-1]):
            print(f"  {c:<10} {v:>12.6g}   IC90 [{lo:.6g} ; {hi:.6g}]")
        return 0
    if args.adaptive or args.profile:
        result, plan, report = m.run_adaptive(args.profile, csv_path=args.csv)
        print(plan)
        if report:
            print(report)
    else:
        result = m.simulate(args.method, backend=args.backend, **kw)
        if args.csv:
            result.to_csv(args.csv)
    print(result.summary())
    for note in result.meta.get("notes", []):
        print(f"  note : {note}")
    if args.csv:
        print(f"→ {args.csv}")
    if args.plot and len(result.t):
        _plot(result, m.name, args.plot)
        print(f"→ {args.plot}")
    return 0


def _plot(result, title: str, path: str) -> None:
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        print("matplotlib absent : graphique non produit", file=sys.stderr)
        return
    fig, ax = plt.subplots(figsize=(8, 4.5))
    for c in result.compartments:
        ax.plot(result.t, result[c], label=c, linewidth=1.6)
    ax.set_xlabel("temps")
    ax.set_ylabel("effectif")
    ax.set_title(f"{title} — {result.meta.get('method')}")
    ax.grid(alpha=0.3)
    ax.legend()
    fig.tight_layout()
    fig.savefig(path, dpi=130)


def cmd_r0(args) -> int:
    print(_load(args).r0_report())
    return 0


def cmd_plan(args) -> int:
    print(_load(args).plan(args.profile))
    return 0


def build_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(prog="epinetlang",
                                 description="Compilateur du langage de modélisation épidémiologique EpiNetLang")
    sub = ap.add_subparsers(dest="command", required=True)

    def add(name, func, help_):
        p = sub.add_parser(name, help=help_)
        p.add_argument("file", help="fichier .epi")
        p.set_defaults(func=func)
        return p

    add("check", cmd_check, "analyse syntaxique et sémantique")
    add("tokens", cmd_tokens, "affiche les jetons (analyse lexicale)")
    add("ast", cmd_ast, "affiche l'arbre de syntaxe abstraite")
    for name, func, help_ in (("ir", cmd_ir, "affiche la représentation intermédiaire"),
                              ("compile", cmd_compile, "génère le code cible"),
                              ("run", cmd_run, "simule le modèle"),
                              ("r0", cmd_r0, "calcule R0 et Rc"),
                              ("plan", cmd_plan, "plan d'exécution basse ressource")):
        p = add(name, func, help_)
        p.add_argument("--model", help="nom du modèle (si le fichier en contient plusieurs)")
        p.add_argument("--set", nargs="*", metavar="NOM=VALEUR", help="surcharge de paramètres")
        if name in ("ir", "compile"):
            p.add_argument("-O", "--opt", type=int, default=2, choices=range(4), help="niveau d'optimisation")
        if name == "ir":
            p.add_argument("--raw", action="store_true", help="IR avant optimisation")
        if name == "compile":
            p.add_argument("-t", "--target", default="python", help="python | julia | cpp | mobile")
            p.add_argument("-o", "--output", help="fichier de sortie (« - » = sortie standard)")
        if name == "run":
            p.add_argument("--method", help="euler | rk4 | rk45 | gillespie | tau_leap | network")
            p.add_argument("--backend", default="compiled", choices=("compiled", "interpreted"))
            p.add_argument("--t-end", type=float)
            p.add_argument("--dt", type=float)
            p.add_argument("--seed", type=int)
            p.add_argument("--replicates", type=int, help="nombre de réalisations stochastiques")
            p.add_argument("--csv", help="exporter la trajectoire en CSV")
            p.add_argument("--plot", help="exporter un graphique PNG (matplotlib)")
            p.add_argument("--adaptive", action="store_true", help="appliquer les stratégies basse ressource")
            p.add_argument("--profile", choices=("minimal", "low", "standard", "high"))
        if name == "plan":
            p.add_argument("--profile", choices=("minimal", "low", "standard", "high"))
    return ap


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        return args.func(args)
    except EpiNetLangError as exc:
        print(exc, file=sys.stderr)
        return 1
    except FileNotFoundError as exc:
        print(f"fichier introuvable : {exc.filename}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
