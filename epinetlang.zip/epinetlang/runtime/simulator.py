"""Simulateur EpiNetLang.

Méthodes disponibles (réglage ``method`` du bloc ``simulation``) :

=============  ============================================================
``euler``      EDO, Euler explicite à pas fixe
``rk4``        EDO, Runge–Kutta d'ordre 4 à pas fixe (défaut)
``rk45``       EDO, pas adaptatif (scipy ``solve_ivp``) ; repli sur rk4
``gillespie``  stochastique exact (algorithme direct de Gillespie)
``tau_leap``   stochastique approché (tau-leaping de Poisson), grandes populations
``network``    stochastique individu-centré sur un graphe de contacts
=============  ============================================================

Les méthodes compartimentales utilisent par défaut le **code compilé** par le
backend Python (``backend="compiled"``) ; ``backend="interpreted"`` évalue
directement l'AST et sert de référence.
"""
from __future__ import annotations

import math
import time
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np

from ..core import ast
from ..core.errors import EpiRuntimeError
from ..core.model import EpidemicModel, EvalContext, NetworkConfig, evaluate
from .interventions import InterventionManager


# ---------------------------------------------------------------------------
# Enregistrement des résultats
# ---------------------------------------------------------------------------
class Recorder:
    """Reçoit les états enregistrés. Voir ``adaptation.memory_optimizer``
    pour un enregistreur en flux qui n'accumule rien en mémoire."""

    def start(self, compartments: list[str], dtype) -> None:
        self.compartments = compartments
        self.dtype = dtype

    def record(self, t: float, y: np.ndarray) -> None:
        raise NotImplementedError

    def finish(self) -> tuple[np.ndarray, np.ndarray]:
        raise NotImplementedError


class InMemoryRecorder(Recorder):
    def start(self, compartments, dtype):
        super().start(compartments, dtype)
        self.ts: list[float] = []
        self.ys: list[np.ndarray] = []

    def record(self, t, y):
        self.ts.append(float(t))
        self.ys.append(np.array(y, dtype=self.dtype, copy=True))

    def finish(self):
        y = np.array(self.ys, dtype=self.dtype) if self.ys else np.zeros((0, len(self.compartments)))
        return np.array(self.ts), y


@dataclass
class SimulationResult:
    t: np.ndarray
    y: np.ndarray
    compartments: list[str]
    meta: dict = field(default_factory=dict)

    def __getitem__(self, name: str) -> np.ndarray:
        return self.y[:, self.compartments.index(name)]

    def final(self) -> dict[str, float]:
        return {c: float(v) for c, v in zip(self.compartments, self.y[-1])}

    def peak(self, name: str) -> tuple[float, float]:
        s = self[name]
        k = int(np.argmax(s))
        return float(self.t[k]), float(s[k])

    def to_csv(self, path: str | Path) -> Path:
        path = Path(path)
        with path.open("w", encoding="utf-8") as fh:
            fh.write("t," + ",".join(self.compartments) + "\n")
            for ti, yi in zip(self.t, self.y):
                fh.write(f"{ti:g}," + ",".join(f"{v:.6g}" for v in yi) + "\n")
        return path

    def summary(self) -> str:
        if len(self.t) == 0:
            return f"(résultats écrits en flux : {self.meta.get('csv', '?')})"
        lines = [f"Méthode {self.meta.get('method')} — {len(self.t)} points enregistrés, "
                 f"{self.meta.get('wall_time', 0) * 1000:.0f} ms"]
        width = max(len(c) for c in self.compartments)
        for c in self.compartments:
            tp, vp = self.peak(c)
            lines.append(f"  {c:<{width}}  initial {self[c][0]:>12.6g}   final {self[c][-1]:>12.6g}"
                         f"   pic {vp:>12.6g} à t = {tp:g}")
        return "\n".join(lines)


@dataclass
class EnsembleResult:
    t: np.ndarray
    runs: np.ndarray            # (n_runs, n_t, n_c)
    compartments: list[str]

    @property
    def mean(self) -> np.ndarray:
        return self.runs.mean(axis=0)

    def quantile(self, q: float) -> np.ndarray:
        return np.quantile(self.runs, q, axis=0)

    def extinction_probability(self, compartment: str, threshold: float = 0.5) -> float:
        """Proportion de trajectoires où le compartiment s'éteint avant la fin."""
        i = self.compartments.index(compartment)
        return float(np.mean(self.runs[:, -1, i] < threshold))


# ---------------------------------------------------------------------------
# Noyaux de calcul : flux + stœchiométrie + événements
# ---------------------------------------------------------------------------
class Kernel:
    stoich: np.ndarray
    events: list
    sources: list[int | None]

    def flows(self, t: float, y: np.ndarray) -> np.ndarray:
        raise NotImplementedError

    def rhs(self, t: float, y: np.ndarray) -> np.ndarray:
        return self.stoich @ self.flows(t, y)


class CompiledKernel(Kernel):
    """Exécute le module Python produit par le compilateur."""

    def __init__(self, model: EpidemicModel, opt_level: int = 2):
        from ..compiler.codegen import CodeGenerator
        self.compilation = CodeGenerator("python", opt_level).compile_model(model)
        ns: dict = {"__name__": f"epinetlang_generated_{model.name}"}
        exec(compile(self.compilation.code, f"<{model.name}.py>", "exec"), ns)
        self.ns = ns
        self.p = np.array(ns["PARAMS"], dtype=np.float64)
        stoich = ns["STOICH"]
        nc = len(model.compartments)
        self.stoich = np.zeros((nc, len(stoich)))
        for j, (s, d) in enumerate(stoich):
            if s >= 0:
                self.stoich[s, j] -= 1
            if d >= 0:
                self.stoich[d, j] += 1
        self.sources = [s if s >= 0 else None for s, _ in stoich]
        self._flows, self._rhs = ns["flows"], ns["rhs"]
        self.events = [(t, (lambda fn: lambda tt, y: fn(tt, y.copy(), self.p))(fn)) for t, fn in ns["EVENTS"]]

    def flows(self, t, y):
        return np.asarray(self._flows(t, y, self.p), dtype=np.float64)

    def rhs(self, t, y):
        return self._rhs(t, y, self.p)


class InterpretedKernel(Kernel):
    """Évalue directement l'AST (référence pour valider le code compilé)."""

    def __init__(self, model: EpidemicModel):
        self.model = model
        self.manager = InterventionManager(model)
        self.window_trs = [(iv, tr) for iv in model.interventions if iv.kind == "window"
                           for tr in iv.transitions]
        self.trs = list(model.transitions) + [tr for _, tr in self.window_trs]
        self.stoich = model.stoichiometry(self.trs)
        self.sources = [None if tr.source is None else model.index[tr.source] for tr in self.trs]
        self.events = [(e.time, e.apply) for e in self.manager.events()]

    def flows(self, t, y):
        p = self.manager.params_at(t)
        ctx = self.model.context(t, y, p)
        n0 = len(self.model.transitions)
        out = np.empty(len(self.trs))
        for j, tr in enumerate(self.trs):
            if j >= n0 and not self.window_trs[j - n0][0].flows_active(t):
                out[j] = 0.0
            else:
                out[j] = float(evaluate(tr.rate, ctx))
        return out


# ---------------------------------------------------------------------------
# Réseaux de contacts
# ---------------------------------------------------------------------------
class Network:
    """Graphe non orienté stocké en liste d'arêtes compacte (2 × E entiers)."""

    def __init__(self, n: int, edges: np.ndarray, index_dtype=np.int32):
        self.n = int(n)
        self.edges = np.asarray(edges, dtype=index_dtype).reshape(-1, 2)
        self.degree = (np.bincount(self.edges[:, 0], minlength=n) +
                       np.bincount(self.edges[:, 1], minlength=n)).astype(np.int32)

    @property
    def mean_degree(self) -> float:
        return 2.0 * len(self.edges) / self.n if self.n else 0.0

    @property
    def nbytes(self) -> int:
        return self.edges.nbytes + self.degree.nbytes

    def neighbour_counts(self, indicator: np.ndarray) -> np.ndarray:
        u, v = self.edges[:, 0], self.edges[:, 1]
        return (np.bincount(u, weights=indicator[v], minlength=self.n) +
                np.bincount(v, weights=indicator[u], minlength=self.n))

    # -- générateurs ---------------------------------------------------------------
    @classmethod
    def build(cls, cfg: NetworkConfig, rng: np.random.Generator, index_dtype=np.int32) -> "Network":
        o, n = cfg.options, cfg.nodes
        if cfg.type == "file":
            return cls.from_file(cfg.file, index_dtype)
        if cfg.type == "erdos_renyi":
            p = float(o["p"]) if "p" in o else float(o["mean_degree"]) / (n - 1)
            return cls(n, cls._erdos_renyi(n, p, rng), index_dtype)
        if cfg.type == "barabasi_albert":
            return cls(n, cls._barabasi_albert(n, int(o.get("m", 2)), rng), index_dtype)
        if cfg.type in ("watts_strogatz", "regular"):
            rew = 0.0 if cfg.type == "regular" else float(o.get("rewiring", 0.1))
            return cls(n, cls._watts_strogatz(n, int(o.get("k", 4)), rew, rng), index_dtype)
        if cfg.type == "complete":
            iu = np.triu_indices(n, 1)
            return cls(n, np.column_stack(iu), index_dtype)
        raise EpiRuntimeError(f"type de réseau inconnu : {cfg.type}")

    @staticmethod
    def _erdos_renyi(n: int, p: float, rng) -> np.ndarray:
        total = n * (n - 1) // 2
        m = int(rng.binomial(total, p))
        keys = np.empty(0, dtype=np.int64)
        while len(keys) < m:
            need = m - len(keys)
            u = rng.integers(0, n, size=2 * need + 16)
            v = rng.integers(0, n, size=2 * need + 16)
            ok = u != v
            a, b = np.minimum(u[ok], v[ok]), np.maximum(u[ok], v[ok])
            keys = np.unique(np.concatenate([keys, a.astype(np.int64) * n + b]))
        if len(keys) > m:
            keys = rng.choice(keys, size=m, replace=False)
        return np.column_stack([keys // n, keys % n])

    @staticmethod
    def _barabasi_albert(n: int, m: int, rng) -> np.ndarray:
        edges = []
        targets = list(range(m))
        repeated: list[int] = []
        for source in range(m, n):
            edges.extend((source, t) for t in targets)
            repeated.extend(targets)
            repeated.extend([source] * m)
            chosen: set[int] = set()
            while len(chosen) < m:
                chosen.add(repeated[int(rng.integers(len(repeated)))])
            targets = list(chosen)
        return np.array(edges, dtype=np.int64)

    @staticmethod
    def _watts_strogatz(n: int, k: int, p: float, rng) -> np.ndarray:
        edges = [(i, (i + j) % n) for j in range(1, k // 2 + 1) for i in range(n)]
        present = {(min(a, b), max(a, b)) for a, b in edges}
        out = []
        for a, b in edges:
            if p > 0 and rng.random() < p:
                for _ in range(20):
                    w = int(rng.integers(n))
                    key = (min(a, w), max(a, w))
                    if w != a and key not in present:
                        present.discard((min(a, b), max(a, b)))
                        present.add(key)
                        b = w
                        break
            out.append((a, b))
        return np.array(out, dtype=np.int64)

    @classmethod
    def from_file(cls, path: str, index_dtype=np.int32) -> "Network":
        labels: dict[str, int] = {}
        edges = []
        for line in Path(path).read_text(encoding="utf-8").splitlines():
            line = line.split("#")[0].replace(",", " ").replace(";", " ").strip()
            if not line:
                continue
            a, b = line.split()[:2]
            if a == b:
                continue
            edges.append((labels.setdefault(a, len(labels)), labels.setdefault(b, len(labels))))
        if not edges:
            raise EpiRuntimeError(f"aucune arête lue dans {path}")
        und = {(min(a, b), max(a, b)) for a, b in edges}
        return cls(len(labels), np.array(sorted(und)), index_dtype)


def scale_counts(initial: np.ndarray, n: int) -> np.ndarray:
    """Répartit n nœuds proportionnellement aux effectifs initiaux (somme exacte = n,
    au moins un nœud pour tout compartiment initialement non vide)."""
    total = initial.sum()
    raw = initial / total * n
    counts = np.floor(raw).astype(np.int64)
    counts[(initial > 0) & (counts == 0)] = 1
    diff = n - counts.sum()
    order = np.argsort(-(raw - np.floor(raw)) if diff > 0 else -counts)
    i = 0
    while diff != 0:
        j = order[i % len(order)]
        step = 1 if diff > 0 else -1
        if counts[j] + step >= (1 if initial[j] > 0 else 0):
            counts[j] += step
            diff -= step
        i += 1
    return counts


# ---------------------------------------------------------------------------
# Simulateur
# ---------------------------------------------------------------------------
class Simulator:
    def __init__(self, model: EpidemicModel, backend: str = "compiled", dtype=np.float64,
                 recorder_factory=InMemoryRecorder, clamp: bool = True, index_dtype=np.int32):
        if backend not in ("compiled", "interpreted"):
            raise ValueError("backend : 'compiled' ou 'interpreted'")
        self.model = model
        self.backend = backend
        self.dtype = dtype
        self.recorder_factory = recorder_factory
        self.clamp = clamp
        self.index_dtype = index_dtype
        self._kernel: Kernel | None = None
        self.network: Network | None = None

    @property
    def kernel(self) -> Kernel:
        if self._kernel is None:
            self._kernel = (CompiledKernel(self.model) if self.backend == "compiled"
                            else InterpretedKernel(self.model))
        return self._kernel

    # -- API ---------------------------------------------------------------------
    def run(self, method: str | None = None, t_end: float | None = None, dt: float | None = None,
            seed: int | None = None, output_every: int | None = None,
            t_start: float | None = None) -> SimulationResult:
        cfg = self.model.simulation
        method = method or cfg.method
        t0 = cfg.t_start if t_start is None else t_start
        t1 = cfg.t_end if t_end is None else t_end
        dt = cfg.dt if dt is None else dt
        stride = cfg.output_every if output_every is None else output_every
        seed = cfg.seed if seed is None else seed
        rec = self.recorder_factory()
        rec.start(self.model.compartments, self.dtype)
        meta = {"method": method, "dt": dt, "dtype": np.dtype(self.dtype).name, "backend": self.backend}
        start = time.perf_counter()
        if method in ("euler", "rk4"):
            meta["steps"] = self._fixed_step(method, t0, t1, dt, stride, rec)
        elif method == "rk45":
            meta.update(self._rk45(t0, t1, dt, stride, rec))
        elif method == "gillespie":
            meta["events"] = self._gillespie(t0, t1, dt * stride, seed, rec)
        elif method == "tau_leap":
            meta["steps"] = self._tau_leap(t0, t1, dt, stride, seed, rec)
        elif method == "network":
            meta.update(self._network(t0, t1, dt, stride, seed, rec))
        else:
            raise EpiRuntimeError(f"méthode de simulation inconnue : {method}")
        meta["wall_time"] = time.perf_counter() - start
        t, y = rec.finish()
        if hasattr(rec, "path"):
            meta["csv"] = str(rec.path)
        return SimulationResult(t, y, list(self.model.compartments), meta)

    def run_ensemble(self, n_runs: int, method: str = "tau_leap", seed: int = 0, **kw) -> EnsembleResult:
        """Répète une simulation stochastique (graines successives)."""
        if self.recorder_factory is not InMemoryRecorder:
            raise EpiRuntimeError("run_ensemble exige un enregistrement en mémoire")
        runs = [self.run(method=method, seed=seed + i, **kw) for i in range(n_runs)]
        return EnsembleResult(runs[0].t, np.stack([r.y for r in runs]), list(self.model.compartments))

    # -- EDO à pas fixe ------------------------------------------------------------
    def _fixed_step(self, method, t0, t1, dt, stride, rec) -> int:
        k = self.kernel
        f = k.rhs
        y = self.model.initial_state(self.dtype)
        events = sorted(k.events, key=lambda e: e[0])
        ke = 0
        n = max(1, int(math.ceil((t1 - t0) / dt - 1e-9)))
        rec.record(t0, y)
        t = t0
        for step in range(n):
            while ke < len(events) and events[ke][0] <= t + 1e-9:
                y = np.asarray(events[ke][1](t, y), dtype=self.dtype)
                ke += 1
            h = min(dt, t1 - t)
            if method == "euler":
                y = y + h * f(t, y)
            else:
                k1 = f(t, y)
                k2 = f(t + h / 2, y + (h / 2) * k1)
                k3 = f(t + h / 2, y + (h / 2) * k2)
                k4 = f(t + h, y + h * k3)
                y = y + (h / 6) * (k1 + 2 * k2 + 2 * k3 + k4)
            y = np.asarray(y, dtype=self.dtype)
            if self.clamp:
                np.maximum(y, 0, out=y)
            t = t1 if step == n - 1 else t0 + (step + 1) * dt
            if (step + 1) % stride == 0 or step == n - 1:
                rec.record(t, y)
        return n

    def _rk45(self, t0, t1, dt, stride, rec) -> dict:
        try:
            from scipy.integrate import solve_ivp
        except ImportError:
            self._fixed_step("rk4", t0, t1, dt, stride, rec)
            return {"note": "scipy absent : repli sur rk4"}
        k = self.kernel
        mgr = InterventionManager(self.model)
        events = sorted(k.events, key=lambda e: e[0])
        cuts = sorted({t0, t1, *mgr.breakpoints(t0, t1), *(e[0] for e in events if t0 < e[0] < t1)})
        grid = np.arange(t0, t1 + 1e-9, dt * stride)
        if grid[-1] < t1 - 1e-9:
            grid = np.append(grid, t1)
        y = self.model.initial_state(np.float64)
        scale = max(1.0, float(np.sum(y)))
        nfev = 0
        ke = 0
        for i, (a, b) in enumerate(zip(cuts[:-1], cuts[1:])):
            while ke < len(events) and events[ke][0] <= a + 1e-9:
                y = np.asarray(events[ke][1](a, y), dtype=np.float64)
                ke += 1
            last = i == len(cuts) - 2
            pts = grid[(grid >= a - 1e-12) & ((grid <= b + 1e-12) if last else (grid < b - 1e-12))]
            t_eval = np.unique(np.append(pts, b))
            sol = solve_ivp(lambda tt, yy: k.rhs(tt, yy), (a, b), y, method="RK45", t_eval=t_eval,
                            rtol=1e-6, atol=1e-9 * scale)
            if not sol.success:
                raise EpiRuntimeError(f"rk45 : {sol.message}")
            nfev += sol.nfev
            for tt, yy in zip(sol.t, sol.y.T):
                if np.any(np.isclose(tt, pts)):
                    rec.record(tt, np.maximum(yy, 0) if self.clamp else yy)
            y = sol.y[:, -1]
        return {"nfev": nfev}

    # -- stochastique ----------------------------------------------------------------
    def _gillespie(self, t0, t1, out_dt, seed, rec, max_events: int = 20_000_000) -> int:
        k = self.kernel
        rng = np.random.default_rng(seed)
        y = np.round(self.model.initial_state(np.float64))
        events = sorted(k.events, key=lambda e: e[0])
        mgr = InterventionManager(self.model)
        bps = sorted(set(mgr.breakpoints(t0, t1)) | {e[0] for e in events if t0 < e[0] < t1} | {t1})
        grid = np.arange(t0, t1 + 1e-9, out_dt)
        ko, ke, n_ev, t = 0, 0, 0, t0
        while True:
            while ke < len(events) and events[ke][0] <= t + 1e-12:
                y = np.round(events[ke][1](t, y))
                ke += 1
            a = np.maximum(k.flows(t, y), 0.0)
            a0 = a.sum()
            nxt = next(b for b in bps if b > t + 1e-12)
            tau = rng.exponential(1.0 / a0) if a0 > 0 else math.inf
            if t + tau >= nxt:                  # aucune réaction avant la discontinuité
                while ko < len(grid) and grid[ko] < nxt - 1e-12:
                    rec.record(grid[ko], y)
                    ko += 1
                t = nxt
                if t >= t1 - 1e-12:
                    break
                continue
            t += tau
            while ko < len(grid) and grid[ko] < t:      # état constant sur [t_prec, t)
                rec.record(grid[ko], y)
                ko += 1
            j = int(np.searchsorted(np.cumsum(a), rng.random() * a0, side="right"))
            j = min(j, len(a) - 1)
            y = np.maximum(y + k.stoich[:, j], 0)
            n_ev += 1
            if n_ev > max_events:
                raise EpiRuntimeError("trop d'événements pour Gillespie : utiliser method = tau_leap")
        while ko < len(grid):
            rec.record(grid[ko], y)
            ko += 1
        return n_ev

    def _tau_leap(self, t0, t1, dt, stride, seed, rec) -> int:
        k = self.kernel
        rng = np.random.default_rng(seed)
        y = np.round(self.model.initial_state(np.float64))
        events = sorted(k.events, key=lambda e: e[0])
        ke = 0
        n = max(1, int(math.ceil((t1 - t0) / dt - 1e-9)))
        rec.record(t0, y)
        t = t0
        for step in range(n):
            while ke < len(events) and events[ke][0] <= t + 1e-9:
                y = np.round(events[ke][1](t, y))
                ke += 1
            h = min(dt, t1 - t)
            a = np.maximum(k.flows(t, y), 0.0)
            fired = rng.poisson(a * h).astype(np.float64)
            for j in rng.permutation(len(a)):
                src = k.sources[j]
                if src is not None:
                    fired[j] = min(fired[j], y[src])
                y = y + k.stoich[:, j] * fired[j]
            t = t1 if step == n - 1 else t0 + (step + 1) * dt
            if (step + 1) % stride == 0 or step == n - 1:
                rec.record(t, y)
        return n

    # -- réseau ----------------------------------------------------------------------
    def _network(self, t0, t1, dt, stride, seed, rec) -> dict:
        m = self.model
        if m.network is None:
            raise EpiRuntimeError("method = network exige un bloc network")
        rng = np.random.default_rng(seed)
        net_seed = m.network.seed if m.network.seed is not None else seed
        net = Network.build(m.network, np.random.default_rng(net_seed), self.index_dtype)
        self.network = net
        nc, n = len(m.compartments), net.n
        dead = nc
        state_dtype = np.int8 if nc < 127 else np.int16
        counts0 = scale_counts(m.initial_state(np.float64), n)
        states = np.repeat(np.arange(nc), counts0).astype(state_dtype)
        rng.shuffle(states)

        mgr = InterventionManager(m)
        all_trs = list(m.transitions) + [tr for iv in m.interventions for tr in iv.transitions
                                         if iv.kind == "window"]
        drivers = set()
        for tr in all_trs:
            for call in ast.calls_in(tr.rate):
                if call.func in ("contact", "neighbours"):
                    drivers.add(call.args[0].id)
        notes = []
        if any(tr.source is None for tr in all_trs):
            notes.append("entrées extérieures (* -> X) ignorées sur réseau")
        deg = np.maximum(net.degree, 1).astype(np.float64)
        susceptible = m.infection_transitions[0].source if m.infection_transitions else None
        pulses = sorted([iv for iv in m.interventions if iv.kind == "pulse"], key=lambda i: i.start)
        kp = 0

        def counts_of(st):
            return np.bincount(st, minlength=nc + 1)[:nc].astype(np.float64)

        n_steps = max(1, int(math.ceil((t1 - t0) / dt - 1e-9)))
        rec.record(t0, counts_of(states))
        t = t0
        for step in range(n_steps):
            while kp < len(pulses) and pulses[kp].start <= t + 1e-9:
                notes += self._network_pulse(pulses[kp], states, susceptible, mgr, t, rng, counts_of)
                kp += 1
            h = min(dt, t1 - t)
            p = mgr.params_at(t)
            counts = counts_of(states)
            alive = float(counts.sum())
            nb = {c: net.neighbour_counts((states == m.index[c]).astype(np.float64)) for c in drivers}
            frac = {c: nb[c] / deg for c in drivers}
            by_source = defaultdict(list)
            for tr in m.transitions + mgr.active_transitions(t):
                if tr.source is not None:
                    by_source[tr.source].append(tr)
            new_states = states.copy()
            for src, trs in by_source.items():
                nodes = np.flatnonzero(states == m.index[src])
                if len(nodes) == 0:
                    continue
                env = dict(p)
                env.update(zip(m.compartments, counts))
                env[src] = 1.0
                env["t"] = t
                ctx = EvalContext(env, total=alive, mean_degree=net.mean_degree,
                                  contact=lambda c, nd=nodes: frac[c][nd],
                                  neighbours=lambda c, nd=nodes: nb[c][nd])
                H = np.stack([np.broadcast_to(np.asarray(evaluate(tr.rate, ctx), dtype=np.float64),
                                              nodes.shape) for tr in trs])
                H = np.maximum(H, 0.0)
                tot = H.sum(axis=0)
                leave = rng.random(len(nodes)) < -np.expm1(-tot * h)
                if not leave.any():
                    continue
                cum = np.cumsum(H[:, leave], axis=0) / tot[leave]
                choice = (rng.random(int(leave.sum())) > cum).sum(axis=0)
                choice = np.minimum(choice, len(trs) - 1)
                targets = np.array([dead if tr.target is None else m.index[tr.target] for tr in trs])
                new_states[nodes[leave]] = targets[choice]
            states = new_states
            t = t1 if step == n_steps - 1 else t0 + (step + 1) * dt
            if (step + 1) % stride == 0 or step == n_steps - 1:
                rec.record(t, counts_of(states))
        return {"nodes": n, "edges": int(len(net.edges)), "mean_degree": round(net.mean_degree, 3),
                "network_bytes": net.nbytes, "steps": n_steps, "notes": sorted(set(notes))}

    def _network_pulse(self, iv, states, susceptible, mgr, t, rng, counts_of) -> list[str]:
        m = self.model
        ctx = m.context(t, counts_of(states), mgr.params_at(t))
        notes = []

        def move(src_i, dst_i, amount):
            pool = np.flatnonzero(states == src_i)
            k = int(min(round(amount), len(pool)))
            if k > 0:
                states[rng.choice(pool, size=k, replace=False)] = dst_i

        for comp, op, expr in iv.state_changes:
            a = float(evaluate(expr, ctx))
            if op == "+=" and susceptible is not None and comp != susceptible:
                move(m.index[susceptible], m.index[comp], a)
            else:
                notes.append(f"« {iv.name} » : « {comp} {op} … » non applicable sur réseau (ignoré)")
        for tr in iv.transitions:
            a = float(evaluate(tr.rate, ctx))
            if tr.source is not None and tr.target is not None:
                move(m.index[tr.source], m.index[tr.target], a)
            else:
                notes.append(f"« {iv.name} » : transfert avec l'extérieur ignoré sur réseau")
        return notes


def simulate(model: EpidemicModel, method: str | None = None, **kw) -> SimulationResult:
    backend = kw.pop("backend", "compiled")
    dtype = kw.pop("dtype", np.float64)
    return Simulator(model, backend=backend, dtype=dtype).run(method=method, **kw)
