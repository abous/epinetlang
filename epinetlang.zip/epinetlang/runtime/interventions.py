"""Gestion des interventions à l'exécution (mode interprété et simulateurs
stochastiques / réseau).

* fenêtre ``from a to b`` : paramètres modifiés et transitions supplémentaires
  actifs pour a ≤ t < b ;
* ponctuelle ``at a`` : modifications de compartiments appliquées une fois,
  modifications de paramètres permanentes à partir de a.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Callable

import numpy as np

from ..core.model import EpidemicModel, EvalContext, Intervention, Transition, evaluate


def apply_op(current: float, op: str, value: float) -> float:
    if op == "=":
        return value
    if op == "+=":
        return current + value
    if op == "-=":
        return current - value
    if op == "*=":
        return current * value
    if op == "/=":
        return current / value
    raise ValueError(op)


@dataclass
class Event:
    time: float
    name: str
    apply: Callable[[float, np.ndarray], np.ndarray]


class InterventionManager:
    def __init__(self, model: EpidemicModel, base_params: dict | None = None):
        self.model = model
        self.base = dict(base_params or model.params)
        self.interventions: list[Intervention] = list(model.interventions)

    def params_at(self, t: float) -> dict[str, float]:
        p = dict(self.base)
        for iv in self.interventions:
            if iv.param_changes and iv.params_active(t):
                for name, op, expr in iv.param_changes:
                    v = float(evaluate(expr, EvalContext({**p, "t": t})))
                    p[name] = apply_op(p[name], op, v)
        return p

    def active_transitions(self, t: float) -> list[Transition]:
        return [tr for iv in self.interventions if iv.flows_active(t) for tr in iv.transitions]

    def all_transitions(self, t: float) -> list[Transition]:
        return list(self.model.transitions) + self.active_transitions(t)

    def breakpoints(self, t0: float, t1: float) -> list[float]:
        """Dates de discontinuité (début/fin de fenêtre, impulsions) dans ]t0, t1[."""
        pts = set()
        for iv in self.interventions:
            for x in (iv.start, iv.end):
                if t0 < x < t1 and math.isfinite(x):
                    pts.add(x)
        return sorted(pts)

    def events(self) -> list[Event]:
        out = []
        for iv in self.interventions:
            if iv.kind == "pulse" and (iv.state_changes or iv.transitions):
                out.append(Event(iv.start, iv.name, self._make_pulse(iv)))
        return sorted(out, key=lambda e: e.time)

    def _make_pulse(self, iv: Intervention):
        m = self.model

        def apply(t: float, y: np.ndarray) -> np.ndarray:
            y = np.array(y, dtype=y.dtype, copy=True)
            ctx = m.context(t, y, self.params_at(t))
            amounts = [float(evaluate(e, ctx)) for _, _, e in iv.state_changes]
            transfers = [float(evaluate(tr.rate, ctx)) for tr in iv.transitions]
            for (comp, op, _), a in zip(iv.state_changes, amounts):
                i = m.index[comp]
                y[i] = max(apply_op(float(y[i]), op, a), 0.0)
            for tr, a in zip(iv.transitions, transfers):
                if tr.source is None:
                    y[m.index[tr.target]] += max(a, 0.0)
                    continue
                s = m.index[tr.source]
                amount = min(max(a, 0.0), float(y[s]))
                y[s] -= amount
                if tr.target is not None:
                    y[m.index[tr.target]] += amount
            return y

        return apply

    def schedule(self) -> str:
        lines = []
        for iv in sorted(self.interventions, key=lambda i: i.start):
            when = f"t = {iv.start:g}" if iv.kind == "pulse" else f"{iv.start:g} ≤ t < {iv.end:g}"
            acts = [f"{n} {op} …" for n, op, _ in iv.param_changes + iv.state_changes]
            acts += [f"{tr.source or '*'} -> {tr.target or '*'}" for tr in iv.transitions]
            lines.append(f"  {iv.name:<22} {when:<22} {'; '.join(acts)}")
        return "\n".join(lines) or "  (aucune)"
