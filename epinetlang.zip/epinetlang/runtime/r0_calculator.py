"""Calcul du nombre de reproduction par la méthode de la matrice de nouvelle
génération (Diekmann, Heesterbeek & Metz 1990 ; van den Driessche & Watmough 2002).

Pour les compartiments infectés x_I, on écrit dx_I/dt = F(x) − V(x) où
F regroupe les **nouvelles infections** et V les autres transferts.
Avec F = ∂F/∂x_I et V = ∂V/∂x_I évalués à l'équilibre sans maladie,
R0 = ρ(F V⁻¹) (rayon spectral).

Les compartiments infectés sont déterminés automatiquement : ceux qu'on atteint
depuis la cible d'une transition d'infection **et** depuis lesquels on peut
atteindre un compartiment infectieux (qui apparaît dans un taux d'infection).
Pour un SEIR : E et I (R est exclu car il ne mène plus à I).

Les jacobiennes sont calculées par différences finies sur l'interpréteur :
la méthode s'applique donc à tout modèle écrit dans le langage.
"""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass

import numpy as np

from ..core.errors import EpiRuntimeError
from ..core.model import EpidemicModel, Transition
from .interventions import InterventionManager


@dataclass
class NGMResult:
    value: float
    infected: list[str]
    F: np.ndarray
    V: np.ndarray
    K: np.ndarray

    def __str__(self) -> str:
        return f"{self.value:.4f}"


class R0Calculator:
    def __init__(self, model: EpidemicModel):
        self.model = model
        self.manager = InterventionManager(model)
        if not model.infection_transitions:
            raise EpiRuntimeError("aucune transition d'infection : R0 non défini pour ce modèle")

    # -- structure ---------------------------------------------------------------
    def infected_compartments(self, transitions: list[Transition] | None = None) -> list[str]:
        trs = transitions or self.model.transitions
        inf_trs = [t for t in trs if t.is_infection]
        succ: dict[str, set[str]] = {c: set() for c in self.model.compartments}
        pred: dict[str, set[str]] = {c: set() for c in self.model.compartments}
        for t in trs:
            if t.source and t.target:
                succ[t.source].add(t.target)
                pred[t.target].add(t.source)

        def closure(start: set[str], graph) -> set[str]:
            seen, queue = set(start), deque(start)
            while queue:
                for nxt in graph[queue.popleft()]:
                    if nxt not in seen:
                        seen.add(nxt)
                        queue.append(nxt)
            return seen

        downstream = closure({t.target for t in inf_trs}, succ)
        infectious = {d for t in inf_trs for d in t.drivers}
        upstream = closure(infectious, pred)
        return [c for c in self.model.compartments if c in downstream and c in upstream]

    def disease_free_state(self, infected: list[str] | None = None) -> np.ndarray:
        m = self.model
        infected = infected or self.infected_compartments()
        x = m.initial_state(np.float64)
        susceptible = m.infection_transitions[0].source
        for c in infected:
            x[m.index[susceptible]] += x[m.index[c]]
            x[m.index[c]] = 0.0
        return x

    def equilibrium_dfe(self, x0: np.ndarray, infected_idx: list[int], params: dict,
                        transitions: list[Transition], t: float = 0.0) -> np.ndarray:
        """Équilibre sans maladie : f(x) = 0 sur les compartiments non infectés
        (infectés fixés à 0), résolu par la méthode de Newton (jacobienne par
        différences finies). Exact en une itération si le sous-système est linéaire."""
        m = self.model
        free = [i for i in range(len(x0)) if i not in set(infected_idx)]
        x = x0.copy()
        scale = max(1.0, float(x.sum()))

        def f(v):
            return m.rhs(t, v, params, transitions)[free]

        for _ in range(50):
            fx = f(x)
            if np.max(np.abs(fx)) < 1e-9 * scale:
                return x
            J = np.zeros((len(free), len(free)))
            for j, i in enumerate(free):
                h = 1e-6 * max(1.0, abs(x[i]))
                y = x.copy()
                y[i] += h
                J[:, j] = (f(y) - fx) / h
            # compartiments « compteurs » (ex. décès cumulés) : ligne et colonne nulles, figés
            rows, cols = np.abs(J).sum(axis=1) > 0, np.abs(J).sum(axis=0) > 0
            if np.any(rows & ~cols):
                # un compartiment absorbant reçoit un flux : l'équilibre dépend de
                # l'histoire (population fermée, ex. vaccination S -> R)
                raise EpiRuntimeError("équilibre sans maladie non unique : utiliser dfe='initial'")
            act = rows & cols
            Ja = J[np.ix_(act, act)]
            if not act.any() or np.linalg.cond(Ja) > 1e12:
                raise EpiRuntimeError("équilibre sans maladie non unique (population fermée ?) : "
                                      "utiliser dfe='initial'")
            sel = np.array(free)[act]
            x[sel] = np.maximum(x[sel] - np.linalg.solve(Ja, fx[act]), 0.0)
            if np.max(np.abs(fx[act])) < 1e-9 * scale:
                return x
        raise EpiRuntimeError("équilibre sans maladie : la méthode de Newton n'a pas convergé")

    # -- matrice de nouvelle génération ---------------------------------------------
    def next_generation(self, state: np.ndarray | None = None, t: float = 0.0,
                        with_interventions: bool = False, dfe: str = "initial") -> NGMResult:
        """``dfe`` : 'initial' (population initiale entièrement susceptible) ou
        'equilibrium' (équilibre sans maladie du système *contrôlé*, nécessaire
        quand une intervention redistribue les non-infectés, ex. PrEP)."""
        m = self.model
        trs = self.manager.all_transitions(t) if with_interventions else list(m.transitions)
        params = self.manager.params_at(t) if with_interventions else dict(m.params)
        infected = self.infected_compartments(trs)
        idx = [m.index[c] for c in infected]
        pos = {c: k for k, c in enumerate(infected)}
        x0 = self.disease_free_state(infected) if state is None else np.array(state, dtype=np.float64)
        if state is not None:
            x0[idx] = 0.0
        elif dfe == "equilibrium":
            x0 = self.equilibrium_dfe(x0, idx, params, trs, t)

        def FV(x: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
            fl = m.flows(t, x, params, trs)
            F = np.zeros(len(infected))
            V = np.zeros(len(infected))
            for tr, f in zip(trs, fl):
                new_infection = tr.is_infection and tr.source not in pos and tr.target in pos
                if new_infection:
                    F[pos[tr.target]] += f
                    continue
                if tr.source in pos:
                    V[pos[tr.source]] += f
                if tr.target in pos:
                    V[pos[tr.target]] -= f
            return F, V

        # différences centrées (erreur O(h²)) ; un état infecté légèrement négatif
        # est sans conséquence ici : seules les dérivées en x0 importent.
        h = max(1e-6, 1e-5 * float(x0.sum()))
        Fm = np.zeros((len(idx), len(idx)))
        Vm = np.zeros((len(idx), len(idx)))
        for j, i in enumerate(idx):
            xp, xm = x0.copy(), x0.copy()
            xp[i] += h
            xm[i] -= h
            Fp, Vp = FV(xp)
            Fn, Vn = FV(xm)
            Fm[:, j] = (Fp - Fn) / (2 * h)
            Vm[:, j] = (Vp - Vn) / (2 * h)
        try:
            K = Fm @ np.linalg.inv(Vm)
        except np.linalg.LinAlgError:
            raise EpiRuntimeError("matrice V singulière : un compartiment infecté n'a pas de sortie") from None
        value = float(np.max(np.abs(np.linalg.eigvals(K)))) if K.size else 0.0
        return NGMResult(value, infected, Fm, Vm, K)

    def r0(self) -> float:
        """Nombre de reproduction de base (sans intervention)."""
        return self.next_generation().value

    def rc(self, t: float, dfe: str = "initial") -> float:
        """Nombre de reproduction *contrôlé* : interventions actives à la date t.
        dfe='initial' : population initiale entièrement susceptible ;
        dfe='equilibrium' : équilibre sans maladie sous les interventions."""
        return self.next_generation(t=t, with_interventions=True, dfe=dfe).value

    def rt(self, t: np.ndarray, y: np.ndarray, every: int = 1) -> tuple[np.ndarray, np.ndarray]:
        """Nombre de reproduction effectif R(t) le long d'une trajectoire."""
        ts = t[::every]
        vals = np.array([self.next_generation(state=yy, t=tt, with_interventions=True).value
                         for tt, yy in zip(ts, y[::every])])
        return ts, vals

    def report(self) -> str:
        res = self.next_generation()
        lines = [f"R0 = {res.value:.4f}  (matrice de nouvelle génération)",
                 f"compartiments infectés : {', '.join(res.infected)}",
                 "K = F V⁻¹ =", np.array2string(res.K, precision=4, suppress_small=True)]
        dates = sorted({iv.start for iv in self.model.interventions if iv.param_changes or iv.transitions})
        for d in dates:
            line = f"Rc(t = {d:g}) = {self.rc(d):.4f}"
            try:
                eq = self.rc(d, dfe="equilibrium")
                if abs(eq - self.rc(d)) > 1e-6 * max(1.0, eq):
                    line += f"   (à l'équilibre sans maladie contrôlé : {eq:.4f})"
            except EpiRuntimeError:
                pass
            lines.append(line)
        return "\n".join(lines)


def compute_r0(model: EpidemicModel) -> float:
    return R0Calculator(model).r0()
