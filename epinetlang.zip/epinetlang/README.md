# EpiNetLang

Langage dédié (DSL) et compilateur pour la modélisation épidémiologique
compartimentale, stochastique et sur réseaux, conçu pour fonctionner aussi
sur des machines à faibles ressources.

## Installation

```bash
pip install -r requirements.txt      # seul numpy est obligatoire
# lancer depuis le dossier PARENT d'epinetlang/ :
python -m epinetlang check epinetlang/examples/sir_model.epi
```

## Chaîne de compilation

```
source .epi ─► lexer ─► parser ─► AST ─► validateur (portée, types, dimensions)
           ─► modèle ─► IR (3 adresses) ─► optimiseur ─► backend
                                                         ├─ Python/NumPy
                                                         ├─ Julia
                                                         ├─ C++17
                                                         └─ Kotlin (mobile, float32)
```

| Dossier        | Rôle |
|----------------|------|
| `grammar/`     | `EpiNetLang.g4` (grammaire formelle ANTLR), `lexer.py`, `parser.py` (descente récursive, sans dépendance) |
| `core/`        | `ast.py`, `types.py` (types + analyse dimensionnelle), `validator.py`, `model.py` (modèle + interpréteur), `errors.py` |
| `compiler/`    | `ir.py`, `optimizer.py` (niveaux 0–3), `backends/`, `codegen.py` |
| `runtime/`     | `simulator.py` (euler, rk4, rk45, gillespie, tau_leap, network), `r0_calculator.py`, `interventions.py` |
| `adaptation/`  | `strategies.py` (profils, plan d'exécution), `memory_optimizer.py`, `precision_manager.py` |
| `benchmarks/`  | modèles VIH-SIDA (`models/`), formes fermées de R0, `run_benchmarks.py` (tables MD/LaTeX/CSV, figures) — voir `benchmarks/README.md` |

## Le langage en bref

```
model SIR {
    parameters {
        N     : count = 1000;
        R0    : real  = 3;
        gamma : rate  = 1 / 10;
        beta  : rate  = R0 * gamma;          // paramètre dérivé
    }
    compartments { S = N - 10; I = 10; R = 0; }
    transitions {
        infection : S -> I : beta * S * I / N;
        guerison  : I -> R : gamma * I;
    }
    interventions {
        confinement : from 20 to 60 { beta *= 0.5; }
        importation : at 50 { I += 5; }
    }
    simulation { t_end = 160; dt = 0.1; method = rk4; }
}
```

* Types : `rate` (temps⁻¹), `probability`, `count` (individus), `time`, `real`.
  Un flux doit avoir la dimension individus·temps⁻¹ : `beta * S * I` sans `/ N`
  est rejeté avec une suggestion de correction.
* `*` désigne l'extérieur : `* -> S` (naissances), `S -> *` (décès).
* Fonctions : `exp log log10 sqrt abs sin cos tanh min max step`,
  `contact(C)` (proportion de C parmi les contacts), `neighbours(C)` (nombre de
  voisins dans C), `total()` (population vivante).
* Bloc `network { type = erdos_renyi | barabasi_albert | watts_strogatz | regular | complete; nodes = …; file = "aretes.csv"; }`.

## Ligne de commande

```bash
python -m epinetlang check   fichier.epi                # erreurs, avertissements, résumé
python -m epinetlang tokens  fichier.epi                # jetons
python -m epinetlang ast     fichier.epi                # arbre syntaxique
python -m epinetlang ir      fichier.epi -O 2 [--raw]   # IR optimisée (ou brute)
python -m epinetlang compile fichier.epi -t cpp -o m.cpp
python -m epinetlang run     fichier.epi [--method gillespie] [--csv out.csv] [--plot out.png]
python -m epinetlang run     fichier.epi --set beta=0.4 gamma=0.2
python -m epinetlang run     fichier.epi --replicates 100 --method tau_leap
python -m epinetlang run     fichier.epi --profile minimal   # stratégies basse ressource
python -m epinetlang r0      fichier.epi                # R0 et Rc par intervention
python -m epinetlang plan    fichier.epi --profile low
```

## API Python

```python
from epinetlang import api
m = api.load("epinetlang/examples/covid_cameroon.epi")
m.r0()                      # 3.277 (matrice de nouvelle génération)
m.rc(30)                    # 1.475 pendant les mesures barrières
m.rc(2019, dfe="equilibrium")  # Rc à l'équilibre sans maladie contrôlé (ex. PrEP)
res = m.simulate()          # code compilé ; res["I"], res.peak("I"), res.to_csv(...)
m.with_params(beta=0.3).simulate("tau_leap", seed=1)
m.compile("mobile").write("CovidModel.kt")
result, plan, report = m.run_adaptive("minimal")
```

## Tests

```bash
python -m pytest epinetlang/tests -q        # 149 tests
python -m epinetlang.benchmarks.run_benchmarks   # benchmarks (tables + figures)
```

Les tests vérifient notamment : R0 calculé = formules analytiques (SIR, SEIR avec
démographie, SEIARD), code compilé = interpréteur (écart < 10⁻¹⁰) à tous les
niveaux d'optimisation, compilation et exécution du C++ généré (`-Wall -Werror`),
taille finale du SIR conforme à l'équation ln s∞ = R0 (s∞ − 1), et pour les
modèles VIH : R0/Rc = formes fermées, effet de la PrEP sur Rc, effet de la PTME.
