"""Optimisation de la mémoire.

* estimation a priori de l'empreinte d'une simulation (trajectoire, réseau) ;
* choix du pas d'enregistrement (``output_every``) pour tenir dans un budget ;
* enregistrement **en flux** dans un CSV : la trajectoire n'est jamais
  conservée en mémoire (utile sur téléphone ou micro-ordinateur) ;
* choix d'entiers 32 bits pour les indices de nœuds du réseau.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from pathlib import Path

import numpy as np

from ..runtime.simulator import Recorder


@dataclass
class MemoryEstimate:
    trajectory_bytes: int
    network_bytes: int
    working_bytes: int

    @property
    def total_bytes(self) -> int:
        return self.trajectory_bytes + self.network_bytes + self.working_bytes

    @property
    def total_mb(self) -> float:
        return self.total_bytes / 2 ** 20

    def __str__(self) -> str:
        mb = lambda b: f"{b / 2 ** 20:.2f} Mo"
        return (f"trajectoire {mb(self.trajectory_bytes)}, réseau {mb(self.network_bytes)}, "
                f"travail {mb(self.working_bytes)} — total {mb(self.total_bytes)}")


class MemoryOptimizer:
    # surcoût d'une liste Python de petits tableaux numpy (en-têtes d'objets)
    ROW_OVERHEAD = 112

    def n_steps(self, t_start: float, t_end: float, dt: float) -> int:
        return max(1, int(math.ceil((t_end - t_start) / dt - 1e-9)))

    def trajectory_bytes(self, n_steps: int, n_comp: int, dtype=np.float64, output_every: int = 1) -> int:
        rows = n_steps // max(output_every, 1) + 2
        return rows * (n_comp * np.dtype(dtype).itemsize + self.ROW_OVERHEAD)

    def network_bytes(self, nodes: int, mean_degree: float, index_dtype=np.int32) -> int:
        edges = nodes * mean_degree / 2
        isz = np.dtype(index_dtype).itemsize
        # arêtes (2 indices) + degrés + états (int8) + 2 tableaux de travail float64 par nœud
        return int(edges * 2 * isz + nodes * (4 + 1 + 2 * 8))

    def choose_index_dtype(self, nodes: int):
        return np.int32 if nodes < 2 ** 31 - 1 else np.int64

    def choose_output_every(self, n_steps: int, n_comp: int, dtype, budget_bytes: int,
                            requested: int = 1, max_points: int | None = None) -> int:
        """Plus petit pas d'enregistrement ≥ requested qui respecte le budget."""
        every = max(1, requested)
        while (self.trajectory_bytes(n_steps, n_comp, dtype, every) > budget_bytes
               or (max_points and n_steps // every > max_points)):
            every *= 2
            if every > n_steps:
                return n_steps
        return every

    def estimate(self, model, dtype=np.float64, output_every: int = 1, dt: float | None = None,
                 method: str | None = None) -> MemoryEstimate:
        cfg = model.simulation
        n = self.n_steps(cfg.t_start, cfg.t_end, dt or cfg.dt)
        nc = len(model.compartments)
        traj = self.trajectory_bytes(n, nc, dtype, output_every)
        net = 0
        if (method or cfg.method) == "network" and model.network is not None:
            net = self.network_bytes(model.network.nodes, model.mean_degree or 4.0,
                                     self.choose_index_dtype(model.network.nodes))
        working = 8 * nc * np.dtype(dtype).itemsize + 8 * len(model.transitions) * 8
        return MemoryEstimate(traj, net, working)


class StreamingCSVRecorder(Recorder):
    """Écrit chaque état directement dans un fichier CSV (mémoire O(1))."""

    def __init__(self, path: str | Path, flush_every: int = 256, precision: int = 6):
        self.path = Path(path)
        self.flush_every = flush_every
        self.precision = precision
        self.rows = 0

    def start(self, compartments, dtype):
        super().start(compartments, dtype)
        self.fh = self.path.open("w", encoding="utf-8", buffering=1 << 16)
        self.fh.write("t," + ",".join(compartments) + "\n")

    def record(self, t, y):
        p = self.precision
        self.fh.write(f"{t:g}," + ",".join(f"{v:.{p}g}" for v in y) + "\n")
        self.rows += 1
        if self.rows % self.flush_every == 0:
            self.fh.flush()

    def finish(self):
        self.fh.close()
        return np.zeros(0), np.zeros((0, len(self.compartments)))


class DecimatingRecorder(Recorder):
    """Conserve au plus ``max_points`` états : quand la limite est atteinte,
    un point sur deux est supprimé (mémoire bornée quelle que soit la durée)."""

    def __init__(self, max_points: int = 2000):
        self.max_points = max(4, max_points)

    def start(self, compartments, dtype):
        super().start(compartments, dtype)
        self.ts: list[float] = []
        self.ys: list[np.ndarray] = []
        self.keep_every = 1
        self.count = 0

    def record(self, t, y):
        if self.count % self.keep_every == 0:
            self.ts.append(float(t))
            self.ys.append(np.array(y, dtype=self.dtype, copy=True))
            if len(self.ts) > self.max_points:
                last_t, last_y = self.ts[-1], self.ys[-1]
                self.ts, self.ys = self.ts[::2], self.ys[::2]
                if self.ts[-1] != last_t:
                    self.ts.append(last_t)
                    self.ys.append(last_y)
                self.keep_every *= 2
        self.count += 1
        self._last = (float(t), np.array(y, dtype=self.dtype, copy=True))

    def finish(self):
        if self.ts and self.ts[-1] != self._last[0]:
            self.ts.append(self._last[0])
            self.ys.append(self._last[1])
        return np.array(self.ts), np.array(self.ys, dtype=self.dtype)
