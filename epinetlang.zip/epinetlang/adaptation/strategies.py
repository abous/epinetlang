"""Stratégies d'adaptation aux environnements à faibles ressources.

À partir d'un **profil matériel** (détecté ou imposé par la variable
d'environnement ``EPINET_PROFILE``) et du modèle, ``AdaptationStrategy.plan``
produit un ``ExecutionPlan`` :

* méthode : Gillespie → tau-leaping si le nombre d'événements attendu est trop
  grand ; réseau → champ moyen si le graphe ne tient pas en mémoire ;
  rk45 → rk4 si scipy est absent ;
* pas de temps : réduit si le pas demandé dépasse la limite de stabilité de
  l'intégrateur (valeur propre dominante de la jacobienne) ;
* précision : float32 sur profil contraint quand la population le permet ;
* mémoire : pas d'enregistrement, décimation ou écriture en flux.
"""
from __future__ import annotations

import importlib.util
import os
from dataclasses import dataclass, field

import numpy as np

from ..core.model import EpidemicModel
from ..runtime.simulator import InMemoryRecorder, Simulator
from .memory_optimizer import DecimatingRecorder, MemoryEstimate, MemoryOptimizer, StreamingCSVRecorder
from .precision_manager import PrecisionManager

# mémoire disponible (Mo) → profil ; budget = part de la mémoire allouée à la simulation
PROFILE_PRESETS = {
    "minimal":  {"memory_mb": 256,    "cpus": 1, "budget_mb": 16,   "max_points": 2_000},
    "low":      {"memory_mb": 1_024,  "cpus": 2, "budget_mb": 64,   "max_points": 10_000},
    "standard": {"memory_mb": 4_096,  "cpus": 4, "budget_mb": 512,  "max_points": None},
    "high":     {"memory_mb": 16_384, "cpus": 8, "budget_mb": 4096, "max_points": None},
}

STABILITY_LIMIT = {"euler": 2.0, "rk4": 2.78, "tau_leap": 1.0}  # |λ| · dt max (axe réel)


def _available_memory_mb() -> tuple[float, float]:
    try:
        import psutil  # type: ignore
        vm = psutil.virtual_memory()
        return vm.total / 2 ** 20, vm.available / 2 ** 20
    except ImportError:
        pass
    try:
        info = {}
        with open("/proc/meminfo", encoding="ascii") as fh:
            for line in fh:
                k, v = line.split(":")
                info[k] = float(v.split()[0]) / 1024
        return info["MemTotal"], info.get("MemAvailable", info["MemFree"])
    except (OSError, KeyError, ValueError):
        pass
    try:
        total = os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES") / 2 ** 20
        return total, total / 2
    except (ValueError, OSError, AttributeError):
        return 1024.0, 512.0


@dataclass
class ResourceProfile:
    name: str
    total_memory_mb: float
    available_memory_mb: float
    cpu_count: int
    budget_mb: float
    max_points: int | None = None

    @classmethod
    def preset(cls, name: str) -> "ResourceProfile":
        if name not in PROFILE_PRESETS:
            raise ValueError(f"profil inconnu « {name} » ({', '.join(PROFILE_PRESETS)})")
        p = PROFILE_PRESETS[name]
        return cls(name, p["memory_mb"], p["memory_mb"] * 0.6, p["cpus"], p["budget_mb"], p["max_points"])

    @classmethod
    def detect(cls) -> "ResourceProfile":
        forced = os.environ.get("EPINET_PROFILE")
        if forced:
            return cls.preset(forced)
        total, avail = _available_memory_mb()
        cpus = os.cpu_count() or 1
        name = ("minimal" if avail < 512 else "low" if avail < 2048 or cpus <= 1
                else "standard" if avail < 8192 else "high")
        p = PROFILE_PRESETS[name]
        return cls(name, total, avail, cpus, min(p["budget_mb"], avail * 0.25), p["max_points"])

    def __str__(self) -> str:
        return (f"profil « {self.name} » : {self.available_memory_mb:.0f}/{self.total_memory_mb:.0f} Mo "
                f"disponibles, {self.cpu_count} cœur(s), budget simulation {self.budget_mb:.0f} Mo")


@dataclass
class ExecutionPlan:
    method: str
    dt: float
    dtype: type
    output_every: int
    recorder: str                    # 'memory' | 'decimate' | 'stream'
    index_dtype: type
    estimate: MemoryEstimate
    profile: ResourceProfile
    notes: list[str] = field(default_factory=list)
    max_points: int | None = None

    def __str__(self) -> str:
        lines = [f"Plan d'exécution ({self.profile})",
                 f"  méthode {self.method}, dt = {self.dt:g}, précision {np.dtype(self.dtype).name}, "
                 f"enregistrement 1 pas sur {self.output_every} ({self.recorder})",
                 f"  mémoire estimée : {self.estimate}"]
        lines += [f"  • {n}" for n in self.notes]
        return "\n".join(lines)


class AdaptationStrategy:
    def __init__(self, profile: ResourceProfile | str | None = None,
                 memory: MemoryOptimizer | None = None, precision: PrecisionManager | None = None):
        if isinstance(profile, str):
            profile = ResourceProfile.preset(profile)
        self.profile = profile or ResourceProfile.detect()
        self.memory = memory or MemoryOptimizer()
        self.precision = precision or PrecisionManager()

    # -- analyses -------------------------------------------------------------------
    @staticmethod
    def spectral_radius(model: EpidemicModel) -> float:
        """Valeur propre dominante de la jacobienne au point initial (différences finies)."""
        y0 = model.initial_state(np.float64)
        n = len(y0)
        f0 = model.rhs(0.0, y0)
        J = np.zeros((n, n))
        for j in range(n):
            h = 1e-6 * max(1.0, abs(y0[j]))
            y = y0.copy()
            y[j] += h
            J[:, j] = (model.rhs(0.0, y) - f0) / h
        return float(np.max(np.abs(np.linalg.eigvals(J)))) if n else 0.0

    # -- planification ------------------------------------------------------------------
    def plan(self, model: EpidemicModel, method: str | None = None,
             streaming_possible: bool = False) -> ExecutionPlan:
        cfg = model.simulation
        prof = self.profile
        method = method or cfg.method
        notes: list[str] = []
        budget = prof.budget_mb * 2 ** 20
        dt = cfg.dt

        if method == "rk45" and importlib.util.find_spec("scipy") is None:
            method = "rk4"
            notes.append("scipy indisponible : rk45 remplacé par rk4")

        if method == "gillespie":
            expected = model.total_population * max(1, len(model.compartments) - 1)
            limit = 2e5 if prof.name in ("minimal", "low") else 2e6
            if expected > limit:
                method = "tau_leap"
                notes.append(f"≈{expected:.1e} événements attendus : Gillespie exact remplacé par "
                             f"tau-leaping (dt = {dt:g})")

        index_dtype = np.int32
        if method == "network" and model.network is not None:
            index_dtype = self.memory.choose_index_dtype(model.network.nodes)
            need = self.memory.network_bytes(model.network.nodes, model.mean_degree or 4.0, index_dtype)
            if need > 0.8 * budget:
                method = "rk4"
                notes.append(f"réseau estimé à {need / 2 ** 20:.0f} Mo > budget : approximation de "
                             f"champ moyen (neighbours(C) = ⟨k⟩·C/N), même R0")

        dtype = self.precision.choose_dtype(model, prof.name)
        if dtype == np.float32:
            notes.append("simple précision (float32) : mémoire divisée par 2, contrôle a posteriori")
        elif prof.name in ("minimal", "low"):
            notes.append(f"population {model.total_population:.3g} trop grande pour float32 : float64 conservé")

        if method in STABILITY_LIMIT:
            lam = self.spectral_radius(model)
            if lam > 0:
                dt_max = 0.9 * STABILITY_LIMIT[method] / lam
                if dt > dt_max:
                    new_dt = dt / int(np.ceil(dt / dt_max))   # sous-multiple : grille de sortie inchangée
                    notes.append(f"dt = {dt:g} instable (|λ|max = {lam:.3g}) : réduit à {new_dt:.3g}")
                    dt = new_dt

        n_steps = self.memory.n_steps(cfg.t_start, cfg.t_end, dt)
        nc = len(model.compartments)
        requested = cfg.output_every
        if dt != cfg.dt:   # garder la même résolution temporelle de sortie
            requested = max(1, int(round(cfg.dt * cfg.output_every / dt)))
        every = self.memory.choose_output_every(n_steps, nc, dtype, int(0.5 * budget), requested,
                                                prof.max_points)
        if every != requested:
            notes.append(f"enregistrement allégé : 1 pas sur {every} (au lieu de {requested})")

        recorder = "memory"
        est = self.memory.estimate(model, dtype, every, dt, method)
        if est.total_bytes > budget:
            recorder = "stream" if streaming_possible else "decimate"
            notes.append("trajectoire trop volumineuse : " +
                         ("écriture en flux dans le CSV" if streaming_possible else
                          f"décimation à {prof.max_points or 2000} points"))
        return ExecutionPlan(method, dt, dtype, every, recorder, index_dtype, est, prof, notes,
                             prof.max_points)

    # -- exécution ----------------------------------------------------------------------
    def execute(self, model: EpidemicModel, method: str | None = None, csv_path: str | None = None,
                seed: int | None = None):
        plan = self.plan(model, method, streaming_possible=csv_path is not None)
        if plan.recorder == "stream":
            factory = lambda: StreamingCSVRecorder(csv_path)
        elif plan.recorder == "decimate":
            factory = lambda: DecimatingRecorder(plan.max_points or 2000)
        else:
            factory = InMemoryRecorder

        def run(dtype):
            sim = Simulator(model, dtype=dtype, recorder_factory=factory, index_dtype=plan.index_dtype)
            return sim.run(method=plan.method, dt=plan.dt, output_every=plan.output_every, seed=seed)

        if plan.recorder == "stream":
            result, report = run(plan.dtype), None
        else:
            result, report = self.precision.run_with_fallback(run, model, plan.dtype)
            if csv_path:
                result.to_csv(csv_path)
        result.meta["plan"] = str(plan)
        return result, plan, report
