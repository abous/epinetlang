"""Gestion de la précision numérique.

Sur machine contrainte, la simple précision (float32) divise par deux la
mémoire et accélère les calculs vectoriels. Elle a cependant 7 chiffres
significatifs : avec N = 28 millions, un individu représente 3,6·10⁻⁸ de N,
en dessous de l'epsilon de float32 (6·10⁻⁸). Le gestionnaire :

1. choisit la précision a priori selon la taille de la population et le profil ;
2. vérifie a posteriori la qualité (conservation de la population, valeurs
   négatives ou non finies) ;
3. relance automatiquement en double précision si le contrôle échoue.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Callable

import numpy as np

EPS32 = float(np.finfo(np.float32).eps)


@dataclass
class PrecisionReport:
    dtype: str
    conservation_error: float | None
    negatives: bool
    non_finite: bool
    tolerance: float

    @property
    def ok(self) -> bool:
        bad_conservation = self.conservation_error is not None and self.conservation_error > self.tolerance
        return not (bad_conservation or self.non_finite)

    def __str__(self) -> str:
        cons = "n/a" if self.conservation_error is None else f"{self.conservation_error:.2e}"
        return (f"précision {self.dtype} : dérive de population {cons} "
                f"(tolérance {self.tolerance:.0e}), valeurs non finies : "
                f"{'oui' if self.non_finite else 'non'} → {'OK' if self.ok else 'ÉCHEC'}")


class PrecisionManager:
    def __init__(self, tolerance: float = 1e-4):
        self.tolerance = tolerance

    def choose_dtype(self, model, profile_name: str = "standard"):
        """float32 seulement si le profil est contraint ET si un individu reste
        représentable (N · eps32 < 0,5)."""
        if profile_name not in ("minimal", "low"):
            return np.float64
        return np.float32 if model.total_population * EPS32 < 0.5 else np.float64

    def conservation_error(self, result, model) -> float | None:
        if not model.conserves_population or len(result.t) == 0:
            return None
        totals = result.y.astype(np.float64).sum(axis=1)
        ref = totals[0] if totals[0] else 1.0
        return float(np.max(np.abs(totals - totals[0])) / ref)

    def check(self, result, model) -> PrecisionReport:
        y = result.y
        return PrecisionReport(
            dtype=str(y.dtype) if len(y) else result.meta.get("dtype", "?"),
            conservation_error=self.conservation_error(result, model),
            negatives=bool(len(y) and np.any(y < 0)),
            non_finite=bool(len(y) and not np.all(np.isfinite(y))),
            tolerance=self.tolerance,
        )

    def run_with_fallback(self, run: Callable[[object], object], model, dtype=np.float32):
        """Exécute ``run(dtype)`` ; repasse en float64 si le contrôle échoue."""
        result = run(dtype)
        report = self.check(result, model)
        if not report.ok and np.dtype(dtype) != np.float64:
            result = run(np.float64)
            result.meta["precision_fallback"] = f"{np.dtype(dtype).name} → float64 ({report})"
            report = self.check(result, model)
        return result, report

    @staticmethod
    def kahan_sum(values) -> float:
        """Somme compensée de Kahan (cumuls d'incidence sur de longues périodes)."""
        s = 0.0
        c = 0.0
        for v in values:
            y = float(v) - c
            t = s + y
            c = (t - s) - y
            s = t
        return s

    @staticmethod
    def significant_digits(dtype) -> int:
        return int(math.floor(-math.log10(np.finfo(dtype).eps)))
