"""Formes fermées de R0 / Rc des modèles de référence et des modèles VIH.

Elles servent d'oracle : le benchmark compare la valeur calculée
numériquement par la matrice de nouvelle génération (``runtime/r0_calculator``)
à ces expressions analytiques.

Chaque fonction reçoit le dictionnaire des paramètres *effectifs* (ceux
renvoyés par ``InterventionManager.params_at(t)`` pour un Rc).
"""
from __future__ import annotations


def phi_hiv(p: dict) -> float:
    """Durée infectieuse pondérée Φ d'un individu infecté (stades I1, I2, I3, T).

    Le cycle T ⇄ I3 (échec thérapeutique puis reprise du traitement) est
    traité par les nombres moyens de passages E3 (par I3) et ET (par T).
    """
    mu = p.get("mu", 0.0)
    tau2, tau3 = p.get("tau2", 0.0), p.get("tau3", 0.0)
    a1 = p["sigma1"] + mu
    a2 = p["sigma2"] + tau2 + mu
    a3 = p["alpha"] + tau3 + mu
    if "omega" in p:
        aT = p["omega"] + p.get("alpha_T", 0.0) + mu
        q3, qT = tau3 / a3, p["omega"] / aT
        e3 = (p["sigma2"] / a2 + (tau2 / a2) * qT) / (1 - q3 * qT)
        eT = tau2 / a2 + q3 * e3
        treated = p.get("eps_T", 0.0) * eT / aT
    else:
        e3, treated = p["sigma2"] / a2, 0.0
    return p["eta1"] / a1 + (p["sigma1"] / a1) * (1 / a2 + p["eta3"] * e3 / a3 + treated)


def heterogeneity_factor(p: dict, prep_fraction_effective: float = 1.0) -> float:
    """(cH² f_H s_H + cL² f_L) / (cH f_H + cL f_L) : mélange proportionnel.
    s_H = part « effectivement susceptible » du groupe H (1 sans PrEP)."""
    num = p["cH"] ** 2 * p["f_H"] * prep_fraction_effective + p["cL"] ** 2 * p["f_L"]
    return num / (p["cH"] * p["f_H"] + p["cL"] * p["f_L"])


def hiv_two_groups(p: dict) -> float:
    return p["beta"] * phi_hiv(p) * heterogeneity_factor(p)


def hiv_prevention(p: dict) -> float:
    """Équilibre sans maladie sous PrEP : P_H*/S_H* = rho / (rho_out + mu)."""
    rho, out, mu = p.get("rho", 0.0), p["rho_out"], p["mu"]
    s_frac = (out + mu) / (rho + out + mu)
    eff = s_frac + (1 - p["e_prep"]) * (1 - s_frac)
    return p["beta"] * phi_hiv(p) * heterogeneity_factor(p, eff)


def hiv_network_mean_field(p: dict, mean_degree: float) -> float:
    return p["beta_p"] * mean_degree * phi_hiv(p)


def hiv_network_heterogeneous(p: dict, k1: float, k2: float) -> float:
    """Approximation linéaire sur graphe : beta_p Φ (<k²> - <k>) / <k>."""
    return p["beta_p"] * phi_hiv(p) * (k2 - k1) / k1


def sir(p: dict) -> float:
    return p["beta"] / p["gamma"]


def seir_vital(p: dict) -> float:
    return p["beta"] * p["sigma"] / ((p["sigma"] + p["mu"]) * (p["gamma"] + p["mu"]))


def seiard(p: dict) -> float:
    return p["beta"] * ((1 - p["p_a"]) / (p["gamma_i"] + p["delta"]) + p["kappa"] * p["p_a"] / p["gamma_a"])


def sir_network_mean_field(p: dict, mean_degree: float) -> float:
    return p["tau"] * mean_degree / p["gamma"]


# nom du fichier (sans extension) -> (fonction, besoin du degré moyen, dfe pour Rc)
CLOSED_FORMS = {
    "sir_model": (sir, False, "initial"),
    "seir_model": (seir_vital, False, "initial"),
    "covid_cameroon": (seiard, False, "initial"),
    "network_model": (sir_network_mean_field, True, "initial"),
    "hiv_base": (hiv_two_groups, False, "equilibrium"),
    "hiv_tarv": (hiv_two_groups, False, "equilibrium"),
    "hiv_prevention": (hiv_prevention, False, "equilibrium"),
    "hiv_reseau": (hiv_network_mean_field, True, "initial"),
}


def closed_form(name: str, params: dict, mean_degree: float | None = None) -> float | None:
    entry = CLOSED_FORMS.get(name)
    if entry is None:
        return None
    fn, needs_k, _ = entry
    return fn(params, mean_degree) if needs_k else fn(params)
