"""Banc d'essai d'EpiNetLang.

    python -m epinetlang.benchmarks.run_benchmarks              # complet
    python -m epinetlang.benchmarks.run_benchmarks --quick      # rapide (tests)
    python -m epinetlang.benchmarks.run_benchmarks --only hiv   # modèles VIH seuls

Tables produites (Markdown, LaTeX booktabs et CSV dans ``--out``) :

B1  compilation : taille des modèles, temps d'analyse, IR avant/après optimisation ;
B2  exécution : interpréteur vs code compilé (Python, C++), float32 vs float64,
    mémoire de pointe ;
B3  exactitude de R0 / Rc : matrice de nouvelle génération vs forme fermée ;
B4  VIH-SIDA : prévalence, décès cumulés, transmission verticale par scénario ;
B5  réseau vs champ moyen (réalisations stochastiques) ;
B6  stratégies basse ressource (profil « minimal »).
"""
from __future__ import annotations

import argparse
import csv
import platform
import shutil
import statistics
import subprocess
import tempfile
import time
import tracemalloc
from datetime import datetime
from pathlib import Path

import numpy as np

from .. import api
from ..adaptation.strategies import AdaptationStrategy
from ..compiler.backends import BACKEND_NAMES
from ..compiler.codegen import CodeGenerator
from ..compiler.ir import lower
from ..compiler.optimizer import Optimizer
from ..core.validator import validate
from ..grammar.parser import parse
from ..runtime.r0_calculator import R0Calculator
from ..runtime.simulator import Network, Simulator
from .closed_forms import CLOSED_FORMS, closed_form, phi_hiv

ROOT = Path(__file__).resolve().parent.parent
MODEL_DIRS = [ROOT / "examples", Path(__file__).resolve().parent / "models"]
HIV_YEARS = [1990, 2000, 2005, 2010, 2020, 2030, 2040]
HIV_ORDER = ["hiv_base", "hiv_tarv", "hiv_prevention", "hiv_reseau"]   # progression des scénarios


# ---------------------------------------------------------------------------
# Utilitaires
# ---------------------------------------------------------------------------
def timed(fn, reps: int):
    """Médiane du temps d'exécution (s) sur ``reps`` répétitions, et dernier résultat."""
    times, out = [], None
    for _ in range(max(1, reps)):
        t0 = time.perf_counter()
        out = fn()
        times.append(time.perf_counter() - t0)
    return statistics.median(times), out


def peak_memory(fn) -> tuple[float, object]:
    tracemalloc.start()
    out = fn()
    _, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    return peak / 2 ** 20, out


def rel_err(a, b) -> float:
    a, b = np.asarray(a, float), np.asarray(b, float)
    return float(np.max(np.abs(a - b) / np.maximum(np.abs(b), 1.0)))


def code_lines(text: str) -> int:
    return sum(1 for l in text.splitlines() if l.strip() and not l.strip().startswith(("//", "#")))


class Table:
    def __init__(self, key: str, title: str, columns: list[tuple[str, str]], note: str = ""):
        self.key, self.title, self.columns, self.note = key, title, columns, note
        self.rows: list[dict] = []

    def add(self, **row) -> None:
        self.rows.append(row)

    @staticmethod
    def fmt(v) -> str:
        if v is None:
            return "—"
        if isinstance(v, float):
            if v == 0:
                return "0"
            if abs(v) < 1e-3 or abs(v) >= 1e6:
                return f"{v:.2e}"
            return f"{v:.4g}" if abs(v) < 100 else f"{v:,.0f}".replace(",", " ")
        return str(v)

    def markdown(self) -> str:
        head = "| " + " | ".join(h for _, h in self.columns) + " |"
        sep = "|" + "|".join("---" for _ in self.columns) + "|"
        body = ["| " + " | ".join(self.fmt(r.get(k)) for k, _ in self.columns) + " |" for r in self.rows]
        note = f"\n\n*{self.note}*" if self.note else ""
        return f"### {self.key} — {self.title}\n\n" + "\n".join([head, sep] + body) + note

    def latex(self) -> str:
        esc = lambda s: (str(s).replace("\\", r"\textbackslash{}").replace("_", r"\_").replace("%", r"\%")
                         .replace("&", r"\&").replace("#", r"\#"))
        cols = "l" + "r" * (len(self.columns) - 1)
        lines = [r"\begin{table}[htbp]", r"\centering", r"\small",
                 rf"\caption{{{esc(self.title)}}}", rf"\label{{tab:bench-{self.key.lower()}}}",
                 rf"\begin{{tabular}}{{{cols}}}", r"\toprule",
                 " & ".join(esc(h) for _, h in self.columns) + r" \\", r"\midrule"]
        lines += [" & ".join(esc(self.fmt(r.get(k))) for k, _ in self.columns) + r" \\" for r in self.rows]
        lines += [r"\bottomrule", r"\end{tabular}"]
        if self.note:
            lines.append(rf"\par\smallskip\footnotesize {esc(self.note)}")
        lines.append(r"\end{table}")
        return "\n".join(lines)

    def write_csv(self, path: Path) -> None:
        with path.open("w", newline="", encoding="utf-8") as fh:
            w = csv.writer(fh)
            w.writerow([h for _, h in self.columns])
            for r in self.rows:
                w.writerow([r.get(k) for k, _ in self.columns])


def model_files(only: str | None) -> list[Path]:
    order = lambda p: (HIV_ORDER.index(p.stem) if p.stem in HIV_ORDER else len(HIV_ORDER), p.stem)
    files = [p for d in MODEL_DIRS for p in sorted(d.glob("*.epi"), key=order)]
    if only == "hiv":
        files = [p for p in files if p.stem.startswith("hiv_")]
    elif only == "ref":
        files = [p for p in files if not p.stem.startswith("hiv_")]
    return files


def hiv_prevalence(m: api.Model, res, groups: tuple[str, ...] | None = None) -> np.ndarray:
    """Prévalence (%) parmi les adultes vivants (hors compteur D et enfants Ce)."""
    alive = [c for c in m.compartments if c not in ("D", "Ce")]
    if groups:
        alive = [c for c in alive if c.split("_")[-1] in groups]
    infected = [c for c in alive if c.split("_")[0] in ("I1", "I2", "I3", "T")]
    tot = sum(res[c] for c in alive)
    return 100 * sum(res[c] for c in infected) / tot


def at_year(res, series, year: float) -> float:
    return float(series[int(np.argmin(np.abs(res.t - year)))])


# ---------------------------------------------------------------------------
# B1 — compilation
# ---------------------------------------------------------------------------
def bench_compilation(files, reps) -> Table:
    tab = Table("B1", "Compilation : taille des modèles et coût de la chaîne", [
        ("model", "Modèle"), ("comp", "Comp."), ("trans", "Trans."), ("interv", "Interv."),
        ("lines", "Lignes .epi"), ("front_ms", "Analyse (ms)"), ("ir0", "IR brute"),
        ("ir1", "IR -O1"), ("ir2", "IR -O2"), ("ir3", "IR -O3"), ("cse", "Sous-expr. communes"),
        ("gen_ms", "Génération 4 cibles (ms)"), ("py_lines", "Lignes Python")],
        note="IR : nombre d'instructions à trois adresses ; -O3 spécialise les paramètres.")
    for f in files:
        src = f.read_text(encoding="utf-8")
        t_front, model = timed(lambda: api.loads(src, str(f)).model, reps)
        raw = lower(model)
        counts, cse = {}, 0
        for lvl in (1, 2, 3):
            opt = Optimizer(lvl)
            counts[lvl] = opt.optimize(raw).n_instructions
            if lvl == 2:
                cse = opt.stats.cse
        t_gen, codes = timed(lambda: [CodeGenerator(t).compile_model(model).code for t in BACKEND_NAMES], reps)
        tab.add(model=f.stem, comp=len(model.compartments), trans=len(model.transitions),
                interv=len(model.interventions), lines=code_lines(src), front_ms=1000 * t_front,
                ir0=raw.n_instructions, ir1=counts[1], ir2=counts[2], ir3=counts[3], cse=cse,
                gen_ms=1000 * t_gen, py_lines=code_lines(codes[0]))
    return tab


# ---------------------------------------------------------------------------
# B2 — exécution
# ---------------------------------------------------------------------------
def run_cpp(model: api.Model, workdir: Path, reps: int):
    if shutil.which("g++") is None:
        return None, None, None
    src = workdir / f"{model.name}.cpp"
    exe = workdir / model.name
    model.compile("cpp").write(src)
    t0 = time.perf_counter()
    subprocess.run(["g++", "-O2", "-std=c++17", str(src), "-o", str(exe)], check=True)
    t_build = time.perf_counter() - t0
    t_run, out = timed(lambda: subprocess.run([str(exe)], check=True, capture_output=True, text=True).stdout, reps)
    last = np.array([float(v) for v in out.strip().splitlines()[-1].split(",")[1:]])
    return t_build, t_run, last


def bench_execution(files, reps, use_cpp: bool) -> Table:
    tab = Table("B2", "Exécution (RK4) : interpréteur, code compilé, précision et mémoire", [
        ("model", "Modèle"), ("steps", "Pas"), ("interp_ms", "Interprété (ms)"),
        ("comp_ms", "Compilé Python (ms)"), ("speedup", "Accélération"),
        ("cpp_ms", "C++ (ms)"), ("err_comp", "Écart compilé/interp."), ("err_cpp", "Écart C++/Python"),
        ("err_f32", "Écart float32/float64"), ("mem64", "Mémoire f64 (Mo)"), ("mem32", "Mémoire f32 (Mo)")],
        note="Temps médians ; C++ : exécution du binaire -O2 (écriture CSV comprise). "
             "Écarts : erreur relative maximale sur la trajectoire (état final pour C++).")
    work = Path(tempfile.mkdtemp(prefix="epinet_bench_"))
    try:
        for f in files:
            m = api.load(f)
            cfg = m.model.simulation
            steps = int(round((cfg.t_end - cfg.t_start) / cfg.dt))
            sim_i = Simulator(m.model, backend="interpreted")
            sim_c = Simulator(m.model, backend="compiled")
            _ = sim_c.kernel                       # compilation hors chronométrage
            t_i, r_i = timed(lambda: sim_i.run(method="rk4"), max(1, reps // 2))
            t_c, r_c = timed(lambda: sim_c.run(method="rk4"), reps)
            s64, s32 = Simulator(m.model, dtype=np.float64), Simulator(m.model, dtype=np.float32)
            _ = s64.kernel, s32.kernel             # mémoire de la simulation seule
            mem64, _ = peak_memory(lambda: s64.run(method="rk4"))
            mem32, r32 = peak_memory(lambda: s32.run(method="rk4"))
            cpp = run_cpp(m, work, reps) if use_cpp else (None, None, None)
            tab.add(model=f.stem, steps=steps, interp_ms=1000 * t_i, comp_ms=1000 * t_c,
                    speedup=f"×{t_i / t_c:.1f}", cpp_ms=None if cpp[1] is None else 1000 * cpp[1],
                    err_comp=rel_err(r_c.y, r_i.y),
                    err_cpp=None if cpp[2] is None else rel_err(cpp[2], r_c.y[-1]),
                    err_f32=rel_err(r32.y, r_c.y), mem64=mem64, mem32=mem32)
    finally:
        shutil.rmtree(work, ignore_errors=True)
    return tab


# ---------------------------------------------------------------------------
# B3 — R0 / Rc
# ---------------------------------------------------------------------------
def bench_r0(files) -> Table:
    tab = Table("B3", "Nombre de reproduction : matrice de nouvelle génération vs forme fermée", [
        ("model", "Modèle"), ("quantity", "Grandeur"), ("ngm", "NGM (numérique)"),
        ("closed", "Forme fermée"), ("err", "Erreur relative"), ("ms", "Temps NGM (ms)")],
        note="Rc(t) : interventions actives à la date t ; DFE = équilibre sans maladie "
             "(contrôlé pour les modèles VIH, ce qui capte l'effet de la PrEP).")
    for f in files:
        if f.stem not in CLOSED_FORMS:
            continue
        m = api.load(f)
        calc = R0Calculator(m.model)
        k = m.model.mean_degree
        dfe = CLOSED_FORMS[f.stem][2]
        t, ngm = timed(calc.r0, 3)
        exact = closed_form(f.stem, m.params, k)
        tab.add(model=f.stem, quantity="R0", ngm=ngm, closed=exact, err=abs(ngm - exact) / exact, ms=1000 * t)
        for d in sorted({iv.start for iv in m.model.interventions}):
            p = calc.manager.params_at(d)
            try:
                v = calc.rc(d, dfe)
            except Exception:
                v = calc.rc(d)
            exact = closed_form(f.stem, p, k)
            tab.add(model=f.stem, quantity=f"Rc({d:g})", ngm=v, closed=exact, err=abs(v - exact) / exact)
    return tab


# ---------------------------------------------------------------------------
# B4 — VIH-SIDA : scénarios
# ---------------------------------------------------------------------------
def bench_hiv(files, out: Path | None) -> Table:
    hiv = [f for f in files if f.stem in ("hiv_base", "hiv_tarv", "hiv_prevention")]
    cols = [("model", "Scénario")] + [(f"p{y}", f"Prév. {y} (%)") for y in HIV_YEARS] + [
        ("pH", "Prév. H 2005 (%)"), ("pL", "Prév. L 2005 (%)"), ("deaths", "Décès SIDA cumulés 2040"),
        ("averted", "Décès évités vs base"), ("ce", "Enfants infectés (stock 2040)")]
    tab = Table("B4", "VIH-SIDA : prévalence chez les 15-49 ans et décès selon le scénario", cols,
                note="Valeurs illustratives (paramètres non calibrés) : la table montre ce que "
                     "le langage permet de comparer, pas une projection pour le Cameroun.")
    curves, base_deaths = {}, None
    for f in hiv:
        m = api.load(f)
        res = m.simulate()
        prev = hiv_prevalence(m, res)
        curves[f.stem] = (res.t, prev, m)
        deaths = at_year(res, res["D"], 2040)
        if f.stem == "hiv_base":
            base_deaths = deaths
        row = {f"p{y}": at_year(res, prev, y) for y in HIV_YEARS}
        row.update(model=f.stem, pH=at_year(res, hiv_prevalence(m, res, ("H",)), 2005),
                   pL=at_year(res, hiv_prevalence(m, res, ("L",)), 2005), deaths=deaths,
                   averted=None if base_deaths is None or f.stem == "hiv_base" else base_deaths - deaths,
                   ce=at_year(res, res["Ce"], 2040) if "Ce" in m.compartments else None)
        tab.add(**row)
    if out is not None and curves:
        plot_hiv(curves, out)
    return tab


def plot_hiv(curves: dict, out: Path) -> None:
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        return
    labels = {"hiv_base": "Sans traitement", "hiv_tarv": "TARV", "hiv_prevention": "TARV + PTME + PrEP"}
    styles = {"hiv_base": "-", "hiv_tarv": "--", "hiv_prevention": ":"}
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(11, 4.2))
    for name, (t, prev, m) in curves.items():
        ls = styles.get(name, "-")
        ax1.plot(t, prev, ls, label=labels.get(name, name), linewidth=2)
        calc = R0Calculator(m.model)
        ts = np.arange(1980, 2040.01, 0.5)
        dfe = CLOSED_FORMS[name][2]
        ax2.step(ts, [calc.rc(x, dfe) for x in ts], where="post", linestyle=ls,
                 label=labels.get(name, name), linewidth=2)
    ax1.set(xlabel="année", ylabel="prévalence 15-49 ans (%)", title="Prévalence du VIH (illustratif)")
    ax2.axhline(1, color="grey", linestyle="--", linewidth=1)
    ax2.set(xlabel="année", ylabel="Rc(t)", title="Nombre de reproduction contrôlé")
    for ax in (ax1, ax2):
        ax.grid(alpha=0.3)
        ax.legend()
    fig.tight_layout()
    fig.savefig(out / "fig_vih_scenarios.png", dpi=140)
    plt.close(fig)


# ---------------------------------------------------------------------------
# B5 — réseau vs champ moyen
# ---------------------------------------------------------------------------
def bench_network(files, n_runs: int, out: Path | None) -> Table:
    tab = Table("B5", "Simulation sur réseau vs approximation de champ moyen", [
        ("model", "Modèle"), ("nodes", "Nœuds"), ("k", "⟨k⟩"), ("k2", "⟨k²⟩"),
        ("r0_mf", "R0 champ moyen"), ("r0_net", "R0 réseau (approx.)"),
        ("final_mf", "Atteints, champ moyen (%)"), ("final_net", "Atteints, réseau (%)"),
        ("ci", "IC 90 % réseau"), ("ms", "Temps / réalisation (ms)"), ("net_mb", "Graphe (Mo)")],
        note="« Atteints » : part des nœuds sortis de S à la fin de la simulation. "
             "R0 réseau : beta Φ (⟨k²⟩ − ⟨k⟩)/⟨k⟩ (graphe de configuration, approximation linéaire).")
    figs = {}
    for f in files:
        m = api.load(f)
        if m.model.network is None:
            continue
        sim = Simulator(m.model)
        susceptible = m.model.infection_transitions[0].source
        n0 = m.model.total_population
        mf = sim.run(method="rk4")
        att_mf = 100 * (1 - mf[susceptible][-1] / n0)
        t_run, _ = timed(lambda: sim.run(method="network", seed=0), 1)
        ens = sim.run_ensemble(n_runs, method="network", seed=100)
        i = ens.compartments.index(susceptible)
        nodes = sim.network.n
        att = 100 * (1 - ens.runs[:, -1, i] / nodes)
        deg = sim.network.degree.astype(float)
        k1, k2 = deg.mean(), (deg ** 2).mean()
        p = m.params
        if f.stem == "hiv_reseau":
            r0_net = p["beta_p"] * phi_hiv(p) * (k2 - k1) / k1
        else:
            r0_net = p["tau"] / p["gamma"] * (k2 - k1) / k1
        tab.add(model=f.stem, nodes=nodes, k=k1, k2=k2, r0_mf=m.r0(), r0_net=r0_net, final_mf=att_mf,
                final_net=float(att.mean()), ci=f"[{np.quantile(att, 0.05):.1f} ; {np.quantile(att, 0.95):.1f}]",
                ms=1000 * t_run, net_mb=sim.network.nbytes / 2 ** 20)
        figs[f.stem] = (mf, ens, susceptible, n0, nodes)
    if out is not None and figs:
        plot_network(figs, out)
    return tab


def plot_network(figs: dict, out: Path) -> None:
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        return
    fig, axes = plt.subplots(1, len(figs), figsize=(5.5 * len(figs), 4), squeeze=False)
    for ax, (name, (mf, ens, s, n0, nodes)) in zip(axes[0], figs.items()):
        i = ens.compartments.index(s)
        att = 100 * (1 - ens.runs[:, :, i] / nodes)
        ax.fill_between(ens.t, np.quantile(att, 0.05, axis=0), np.quantile(att, 0.95, axis=0),
                        alpha=0.25, label="réseau (IC 90 %)")
        ax.plot(ens.t, att.mean(axis=0), linewidth=1.8, label="réseau (moyenne)")
        ax.plot(mf.t, 100 * (1 - mf[s] / n0), "--", linewidth=1.8, label="champ moyen")
        ax.set(title=name, xlabel="temps", ylabel="part atteinte (%)")
        ax.grid(alpha=0.3)
        ax.legend()
    fig.tight_layout()
    fig.savefig(out / "fig_reseau_vs_champ_moyen.png", dpi=140)
    plt.close(fig)


# ---------------------------------------------------------------------------
# B6 — basse ressource
# ---------------------------------------------------------------------------
def bench_low_resource(files) -> Table:
    tab = Table("B6", "Stratégies d'adaptation : profil « minimal » (256 Mo, 1 cœur)", [
        ("model", "Modèle"), ("method", "Méthode"), ("dtype", "Précision"), ("dt", "dt"),
        ("every", "Enregistrement"), ("est_mb", "Mémoire estimée (Mo)"), ("ms", "Temps (ms)"),
        ("check", "Contrôle précision"), ("notes", "Adaptations")])
    strat = AdaptationStrategy("minimal")
    for f in files:
        m = api.load(f)
        t, (res, plan, report) = timed(lambda: strat.execute(m.model), 1)
        notes = "; ".join(n.split(":")[0] for n in plan.notes) or "aucune"
        tab.add(model=f.stem, method=plan.method, dtype=np.dtype(plan.dtype).name, dt=plan.dt,
                every=f"1/{plan.output_every}", est_mb=plan.estimate.total_mb, ms=1000 * t,
                check="—" if report is None else ("OK" if report.ok else "repli f64"), notes=notes)
    return tab


# ---------------------------------------------------------------------------
# Programme principal
# ---------------------------------------------------------------------------
def environment() -> str:
    import numpy
    return (f"{datetime.now():%d/%m/%Y %H:%M} — Python {platform.python_version()}, NumPy {numpy.__version__}, "
            f"{platform.system()} {platform.machine()}, {platform.processor() or 'CPU ?'}, "
            f"g++ {'oui' if shutil.which('g++') else 'non'}")


def run(out: Path | None = None, quick: bool = False, only: str | None = None,
        use_cpp: bool = True, verbose: bool = True) -> list[Table]:
    reps = 1 if quick else 5
    n_runs = 4 if quick else 30
    files = model_files(only)
    for f in files:                                     # tous les modèles doivent être valides
        validate(parse(f.read_text(encoding="utf-8"), str(f)).models[0], raise_on_error=True)
    if out is not None:
        out.mkdir(parents=True, exist_ok=True)
    steps = [("B1", lambda: bench_compilation(files, reps)),
             ("B2", lambda: bench_execution(files, reps, use_cpp)),
             ("B3", lambda: bench_r0(files)),
             ("B4", lambda: bench_hiv(files, out)),
             ("B5", lambda: bench_network(files, n_runs, out)),
             ("B6", lambda: bench_low_resource(files))]
    tables = []
    for key, fn in steps:
        t0 = time.perf_counter()
        tab = fn()
        if tab.rows:
            tables.append(tab)
        if verbose:
            print(f"  {key} terminé ({time.perf_counter() - t0:.1f} s)", flush=True)
    if out is not None:
        env = environment()
        md = [f"# Benchmarks EpiNetLang\n\n{env}\n"] + [t.markdown() for t in tables]
        (out / "benchmarks.md").write_text("\n\n".join(md) + "\n", encoding="utf-8")
        tex = [f"% Benchmarks EpiNetLang — {env}", "% Nécessite \\usepackage{booktabs}"] + [t.latex() for t in tables]
        (out / "benchmarks.tex").write_text("\n\n".join(tex) + "\n", encoding="utf-8")
        for t in tables:
            t.write_csv(out / f"{t.key}.csv")
    return tables


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Benchmarks EpiNetLang")
    ap.add_argument("--out", default=str(Path(__file__).resolve().parent / "results"),
                    help="dossier des résultats (défaut : benchmarks/results)")
    ap.add_argument("--quick", action="store_true", help="1 répétition, 4 réalisations stochastiques")
    ap.add_argument("--only", choices=("hiv", "ref"), help="seulement les modèles VIH ou de référence")
    ap.add_argument("--no-cpp", action="store_true", help="ne pas compiler le C++ généré")
    args = ap.parse_args(argv)
    out = Path(args.out)
    print(f"Benchmarks EpiNetLang → {out}")
    tables = run(out, args.quick, args.only, not args.no_cpp)
    print()
    for t in tables:
        print(t.markdown(), "\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
