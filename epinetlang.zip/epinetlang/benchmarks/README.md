# Benchmarks EpiNetLang

```bash
# depuis le dossier PARENT d'epinetlang/
python -m epinetlang.benchmarks.run_benchmarks            # complet (~40 s)
python -m epinetlang.benchmarks.run_benchmarks --quick    # rapide
python -m epinetlang.benchmarks.run_benchmarks --only hiv # modèles VIH seuls
```

Résultats dans `benchmarks/results/` : `benchmarks.md`, `benchmarks.tex`
(tables `booktabs` prêtes à `\input{}` dans la thèse), un CSV par table,
`fig_vih_scenarios.png` et `fig_reseau_vs_champ_moyen.png`.

## Modèles

Les 4 exemples de `examples/` plus 4 modèles VIH-SIDA (`benchmarks/models/`) :

| Fichier | Contenu | Comp. | Trans. |
|---|---|---|---|
| `hiv_base.epi` | sans traitement ; stades I1 (primo-infection), I2 (chronique), I3 (SIDA) ; 2 groupes de risque en mélange proportionnel | 9 | 18 |
| `hiv_tarv.epi` | + traitement antirétroviral (T), échec thérapeutique ; accès au TARV 2004, « traiter tous » 2016 | 11 | 28 |
| `hiv_prevention.epi` | + PrEP ciblée sur le groupe H (2019) + PTME (2008), transmission verticale vers Ce | 13 | 34 |
| `hiv_reseau.epi` | même histoire naturelle sur un réseau sexuel de Barabási–Albert (5 000 nœuds) | 6 | 7 |

**Les paramètres sont illustratifs** (prévalence ≈ 1 % en 1990, pic ≈ 5 % vers
2005–2010). Ils ne sont pas calibrés et doivent être remplacés par ceux du
chapitre 5 avant toute interprétation épidémiologique.

### R0 et Rc

* Les taux de mise sous traitement valent 0 dans les paramètres de base :
  `r0()` est le R0 **sans** traitement, `rc(t)` le nombre de reproduction
  **contrôlé** par les interventions actives à la date t.
* Avec la PrEP, l'équilibre sans maladie lui-même change (une partie du groupe
  H passe dans P_H) : il faut `rc(t, dfe="equilibrium")`, qui recalcule cet
  équilibre (méthode de Newton). Avec la DFE initiale, l'effet de la PrEP serait
  invisible (test `test_prep_needs_controlled_equilibrium`).
* Chaque modèle a une **forme fermée** (`closed_forms.py`) ; avec le mélange
  proportionnel, la matrice de nouvelle génération est de rang 1 et
  R0 = β Φ (c_H² f_H + c_L² f_L)/(c_H f_H + c_L f_L) (Anderson–May), où Φ
  traite le cycle T ⇄ I3 par les nombres moyens de passages.

## Tables

| Table | Mesure |
|---|---|
| B1 | taille des modèles, temps d'analyse, instructions IR aux niveaux -O0 à -O3, sous-expressions communes éliminées |
| B2 | temps RK4 interprété / compilé Python / C++, écarts numériques, float32 vs float64, mémoire de pointe |
| B3 | R0 et Rc(t) : matrice de nouvelle génération vs forme fermée (écart ≤ 3·10⁻⁸) |
| B4 | VIH : prévalence 1990–2040, prévalence par groupe, décès SIDA cumulés et évités, enfants infectés |
| B5 | réseau vs champ moyen : 30 réalisations, IC 90 %, R0 hétérogène ⟨k²⟩ |
| B6 | plan d'exécution et résultat sous le profil « minimal » (256 Mo, 1 cœur) |

Les temps dépendent de la machine : relancer le script sur la machine
de référence de la thèse avant de citer des chiffres.
