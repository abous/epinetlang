"""Optimisations de l'IR.

Niveaux :

* ``0`` : aucune optimisation ;
* ``1`` : propagation/pliage de constantes, simplifications algébriques
          (x·1, x+0, x·0, x^1…), propagation de copies, élimination de code mort ;
* ``2`` : + élimination des sous-expressions communes (CSE), en tenant compte
          de la commutativité (``S*I`` et ``I*S`` sont reconnus identiques) ;
* ``3`` : + spécialisation : les paramètres sont remplacés par leur valeur
          numérique (code plus rapide, mais paramètres figés à la compilation).
"""
from __future__ import annotations

import copy
import math
from dataclasses import dataclass

from .ir import COMMUTATIVE, Const, Instr, IRProgram, Operand

_FOLD = {
    "add": lambda a, b: a + b, "sub": lambda a, b: a - b, "mul": lambda a, b: a * b,
    "div": lambda a, b: a / b, "pow": lambda a, b: a ** b, "neg": lambda a: -a,
    "sum": lambda *a: math.fsum(a), "min": min, "max": max, "copy": lambda a: a,
    "step": lambda a: 1.0 if a >= 0 else 0.0,
    "exp": math.exp, "log": math.log, "log10": math.log10, "sqrt": math.sqrt, "abs": abs,
    "sin": math.sin, "cos": math.cos, "tanh": math.tanh,
}


def _is(o: Operand, v: float) -> bool:
    return o.kind == "const" and o.value == v


@dataclass
class OptimizationStats:
    instructions_before: int = 0
    instructions_after: int = 0
    folded: int = 0
    simplified: int = 0
    cse: int = 0
    dead: int = 0
    inlined_params: int = 0

    def __str__(self) -> str:
        gain = self.instructions_before - self.instructions_after
        pct = 100 * gain / self.instructions_before if self.instructions_before else 0
        return (f"instructions : {self.instructions_before} → {self.instructions_after} (−{pct:.0f} %) | "
                f"constantes pliées {self.folded}, simplifiées {self.simplified}, "
                f"sous-expr. communes {self.cse}, code mort {self.dead}"
                + (f", paramètres spécialisés {self.inlined_params}" if self.inlined_params else ""))


class Optimizer:
    def __init__(self, level: int = 2):
        if level not in (0, 1, 2, 3):
            raise ValueError("niveau d'optimisation : 0, 1, 2 ou 3")
        self.level = level
        self.stats = OptimizationStats()

    # -- règles locales -------------------------------------------------------
    def _fold(self, op: str, args: tuple[Operand, ...]) -> Operand | None:
        if op == "window" or not args or any(a.kind != "const" for a in args):
            return None
        try:
            v = _FOLD[op](*(a.value for a in args))
        except (ZeroDivisionError, ValueError, OverflowError):
            return None
        if isinstance(v, complex) or math.isnan(v):
            return None
        self.stats.folded += 1
        return Const(v)

    def _simplify(self, op: str, a: tuple[Operand, ...]) -> Operand | None:
        r = None
        if op == "copy":
            r = a[0]
        elif op == "add":
            r = a[1] if _is(a[0], 0) else a[0] if _is(a[1], 0) else None
        elif op == "sub":
            r = a[0] if _is(a[1], 0) else Const(0) if a[0] == a[1] else None
        elif op == "mul":
            if _is(a[0], 0) or _is(a[1], 0):
                r = Const(0)
            else:
                r = a[1] if _is(a[0], 1) else a[0] if _is(a[1], 1) else None
        elif op == "div":
            r = a[0] if _is(a[1], 1) else Const(1) if (a[0] == a[1] and a[0].kind != "const") else None
        elif op == "pow":
            r = a[0] if _is(a[1], 1) else Const(1) if _is(a[1], 0) else None
        elif op in ("sum", "min", "max") and len(a) == 1:
            r = a[0]
        if r is not None:
            self.stats.simplified += 1
        return r

    # -- passes sur un bloc ------------------------------------------------------
    def _forward(self, block: list[Instr], subst: dict[int, Operand]) -> list[Instr]:
        def res(o: Operand) -> Operand:
            while o.kind == "temp" and o.value in subst:
                o = subst[o.value]
            return o

        seen: dict[tuple, Operand] = {}
        out: list[Instr] = []
        for ins in block:
            args = tuple(res(x) for x in ins.args)
            if ins.op == "sum":                         # retirer les zéros d'une somme
                nz = tuple(x for x in args if not _is(x, 0))
                if len(nz) != len(args):
                    args = nz or (Const(0),)
            r = self._fold(ins.op, args)
            if r is None:
                r = self._simplify(ins.op, args)
            if r is not None:
                subst[ins.dest] = r
                continue
            if self.level >= 2:
                key_args = tuple(sorted(args, key=repr)) if ins.op in COMMUTATIVE else args
                key = (ins.op, key_args)
                if key in seen:
                    subst[ins.dest] = seen[key]
                    self.stats.cse += 1
                    continue
                seen[key] = Operand("temp", ins.dest)
            out.append(Instr(ins.dest, ins.op, args))
        return out

    def _dce(self, block: list[Instr], roots: list[Operand]) -> list[Instr]:
        live = {o.value for o in roots if o.kind == "temp"}
        kept = []
        for ins in reversed(block):
            if ins.dest in live:
                kept.append(ins)
                live.update(a.value for a in ins.args if a.kind == "temp")
            else:
                self.stats.dead += 1
        return kept[::-1]

    @staticmethod
    def _resolve(o: Operand, subst: dict[int, Operand]) -> Operand:
        while o.kind == "temp" and o.value in subst:
            o = subst[o.value]
        return o

    def _inline(self, prog: IRProgram, block: list[Instr]) -> list[Instr]:
        def f(o: Operand) -> Operand:
            if o.kind == "param":
                self.stats.inlined_params += 1
                return Const(prog.param_values[o.value])
            return o
        return [Instr(i.dest, i.op, tuple(f(a) for a in i.args)) for i in block]

    # -- point d'entrée -------------------------------------------------------------
    def optimize(self, prog: IRProgram) -> IRProgram:
        prog = copy.deepcopy(prog)
        self.stats = OptimizationStats(instructions_before=prog.n_instructions)
        if self.level == 0:
            self.stats.instructions_after = prog.n_instructions
            return prog

        if self.level >= 3:
            prog.body = self._inline(prog, prog.body)
            for ev in prog.events:
                ev.block = self._inline(prog, ev.block)
            for fl in prog.flows:
                if fl.value.kind == "param":
                    fl.value = Const(prog.param_values[fl.value.value])
            for ev in prog.events:
                for a in ev.actions:
                    if a.value.kind == "param":
                        a.value = Const(prog.param_values[a.value.value])

        for _ in range(8):     # jusqu'au point fixe
            before = prog.n_instructions
            subst: dict[int, Operand] = {}
            prog.body = self._forward(prog.body, subst)
            for fl in prog.flows:
                fl.value = self._resolve(fl.value, subst)
            prog.body = self._dce(prog.body, [fl.value for fl in prog.flows])
            for ev in prog.events:
                esub: dict[int, Operand] = {}
                ev.block = self._forward(ev.block, esub)
                for a in ev.actions:
                    a.value = self._resolve(a.value, esub)
                ev.block = self._dce(ev.block, [a.value for a in ev.actions])
            if prog.n_instructions == before:
                break

        self._renumber(prog)
        self.stats.instructions_after = prog.n_instructions
        return prog

    @staticmethod
    def _renumber(prog: IRProgram) -> None:
        """Renumérote les temporaires de façon contiguë (code généré plus lisible)."""
        mapping: dict[int, int] = {}

        def m(o: Operand) -> Operand:
            return Operand("temp", mapping[o.value]) if o.kind == "temp" else o

        def block(b: list[Instr]) -> list[Instr]:
            out = []
            for ins in b:
                args = tuple(m(a) for a in ins.args)
                mapping[ins.dest] = len(mapping)
                out.append(Instr(mapping[ins.dest], ins.op, args))
            return out

        prog.body = block(prog.body)
        for fl in prog.flows:
            fl.value = m(fl.value)
        for ev in prog.events:
            ev.block = block(ev.block)
            for a in ev.actions:
                a.value = m(a.value)
        prog.n_temps = len(mapping)


def optimize(prog: IRProgram, level: int = 2) -> tuple[IRProgram, OptimizationStats]:
    opt = Optimizer(level)
    return opt.optimize(prog), opt.stats
