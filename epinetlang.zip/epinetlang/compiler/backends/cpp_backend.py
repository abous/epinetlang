"""Backend C++17 : programme autonome sans dépendance (RK4, sortie CSV).

    g++ -O2 -std=c++17 sir.cpp -o sir && ./sir [t_end] [dt] > sir.csv
"""
from __future__ import annotations

from . import Backend, quote_list


class CppBackend(Backend):
    name = "cpp"
    extension = ".cpp"
    comment = "//"
    real = "double"
    suffix = ""

    def num(self, v: float) -> str:
        if self.is_inf(v):
            return "INFINITY" if v > 0 else "-INFINITY"
        s = repr(float(v))
        return s + self.suffix

    def pow(self, a: str, b: str) -> str:
        return f"std::pow({a}, {b})"

    def window(self, t: str, a: str, b: str) -> str:
        return f"(({t} >= {a} && {t} < {b}) ? {self.num(1)} : {self.num(0)})"

    def step(self, a: str) -> str:
        return f"(({a}) >= 0 ? {self.num(1)} : {self.num(0)})"

    def minmax(self, op: str, args: list[str]) -> str:
        out = args[0]
        for x in args[1:]:
            out = f"std::{op}<real>({out}, {x})"
        return out

    def func(self, op: str, a: str) -> str:
        return f"std::{op}({a})"

    def _block(self, block, indent="    ") -> list[str]:
        return [f"{indent}const real {self.temp(i.dest)} = {self.expr(i)};" for i in block]

    def generate(self) -> str:
        p = self.prog
        nc, nf, npar = len(p.compartments), len(p.flows), len(p.param_names)
        arr = lambda xs: ", ".join(self.num(float(x)) for x in xs) or self.num(0)
        L = self.header() + ["",
             "#include <algorithm>", "#include <cmath>", "#include <cstdio>", "#include <cstdlib>", "",
             f"using real = {self.real};",
             f"constexpr int NC = {nc};   // compartiments",
             f"constexpr int NF = {max(nf, 1)};   // flux",
             f"constexpr int NP = {max(npar, 1)};   // paramètres",
             f"static const char* NAMES[NC] = {{{quote_list(p.compartments)}}};",
             f"static real P[NP] = {{{arr(p.param_values)}}};  // {', '.join(p.param_names)}",
             f"static const real Y0[NC] = {{{arr(p.initial)}}};",
             "", "void flows(real t, const real* y, const real* p, real* f) {",
             "    (void)t; (void)y; (void)p;"]
        L += self._block(p.body)
        for j, fl in enumerate(p.flows):
            L.append(f"    f[{j}] = {self.operand(fl.value)};  // {fl.label}")
        L += ["}", "", "void rhs(real t, const real* y, const real* p, real* dy) {",
              "    real f[NF];", "    flows(t, y, p, f);"]
        for i, terms in enumerate(p.derivative_terms()):
            expr = " ".join(("+ " if s > 0 else "- ") + f"f[{j}]" for s, j in terms) or "+ 0"
            expr = expr[2:] if expr.startswith("+ ") else "-" + expr[2:]
            L.append(f"    dy[{i}] = {expr};  // d{p.compartments[i]}/dt")
        L += ["}", ""]
        for k, ev in enumerate(p.events):
            L += [f"// Intervention ponctuelle « {ev.name} » (t = {ev.time:g})",
                  f"void event_{k}(real* y, const real* p) {{", "    (void)p;"]
            L += self._block(ev.block)
            for j, a in enumerate(ev.actions):
                L.append(f"    const real a{j} = {self.operand(a.value)};")
            for j, a in enumerate(ev.actions):
                s = self.state(a.src) if a.src is not None else None
                z = self.num(0)
                if a.kind == "add":
                    L.append(f"    {s} += a{j};")
                elif a.kind == "sub":
                    L.append(f"    {s} = std::max<real>({s} - a{j}, {z});")
                elif a.kind == "set":
                    L.append(f"    {s} = std::max<real>(a{j}, {z});")
                elif a.kind == "mul":
                    L.append(f"    {s} = std::max<real>({s} * a{j}, {z});")
                elif a.kind == "div":
                    L.append(f"    {s} = std::max<real>({s} / a{j}, {z});")
                else:
                    L.append(f"    const real m{j} = std::min<real>(std::max<real>(a{j}, {z}), {s});")
                    L.append(f"    {s} -= m{j}; {self.state(a.dst)} += m{j};")
            L += ["}", ""]
        ev_times = arr([e.time for e in p.events]) if p.events else self.num(0)
        L += [f"constexpr int NE = {len(p.events)};",
              f"static const real EVENT_T[{max(len(p.events), 1)}] = {{{ev_times}}};",
              "static void apply_event(int k, real* y, const real* p) {",
              "    switch (k) {"]
        L += [f"        case {k}: event_{k}(y, p); break;" for k in range(len(p.events))]
        L += ["        default: (void)y; (void)p; break;", "    }", "}", "",
              "int main(int argc, char** argv) {",
              f"    const real t0 = {self.num(p.sim.t_start)};",
              f"    const real t_end = argc > 1 ? (real)std::atof(argv[1]) : {self.num(p.sim.t_end)};",
              f"    const real dt = argc > 2 ? (real)std::atof(argv[2]) : {self.num(p.sim.dt)};",
              f"    const int every = {p.sim.output_every};",
              _CPP_LOOP, "}"]
        return "\n".join(L) + "\n"


_CPP_LOOP = r'''    real y[NC], k1[NC], k2[NC], k3[NC], k4[NC], tmp[NC];
    for (int i = 0; i < NC; ++i) y[i] = Y0[i];
    const long n = std::max(1L, (long)std::ceil((t_end - t0) / dt - 1e-9));
    int ke = 0;
    std::printf("t");
    for (int i = 0; i < NC; ++i) std::printf(",%s", NAMES[i]);
    std::printf("\n%g", (double)t0);
    for (int i = 0; i < NC; ++i) std::printf(",%.6g", (double)y[i]);
    std::printf("\n");
    real t = t0;
    for (long k = 0; k < n; ++k) {
        while (ke < NE && EVENT_T[ke] <= t + 1e-9) apply_event(ke++, y, P);
        const real h = std::min<real>(dt, t_end - t);
        rhs(t, y, P, k1);
        for (int i = 0; i < NC; ++i) tmp[i] = y[i] + h / 2 * k1[i];
        rhs(t + h / 2, tmp, P, k2);
        for (int i = 0; i < NC; ++i) tmp[i] = y[i] + h / 2 * k2[i];
        rhs(t + h / 2, tmp, P, k3);
        for (int i = 0; i < NC; ++i) tmp[i] = y[i] + h * k3[i];
        rhs(t + h, tmp, P, k4);
        for (int i = 0; i < NC; ++i) {
            y[i] += h / 6 * (k1[i] + 2 * k2[i] + 2 * k3[i] + k4[i]);
            if (y[i] < 0) y[i] = 0;
        }
        t = (k == n - 1) ? t_end : t0 + (k + 1) * dt;
        if ((k + 1) % every == 0 || k == n - 1) {
            std::printf("%g", (double)t);
            for (int i = 0; i < NC; ++i) std::printf(",%.6g", (double)y[i]);
            std::printf("\n");
        }
    }
    return 0;'''
