"""Backends de génération de code.

Chaque backend traduit un ``IRProgram`` optimisé en un programme autonome
(second membre ``rhs``, flux, événements, intégrateur RK4, sortie CSV).
"""
from __future__ import annotations

import math
from datetime import date

from ..ir import Instr, IRProgram, Operand

_SYM = {"add": "+", "sub": "-", "mul": "*", "div": "/"}


def quote_list(names) -> str:
    """'"S", "I", "R"' — compatible avec toutes les versions de Python ≥ 3.9."""
    return ", ".join('"' + n + '"' for n in names)


class Backend:
    name = "abstract"
    extension = ".txt"
    comment = "#"

    def __init__(self, prog: IRProgram):
        self.prog = prog

    # -- à spécialiser -----------------------------------------------------------
    def num(self, v: float) -> str:
        raise NotImplementedError

    def param(self, i: int) -> str:
        return f"p[{i}]"

    def state(self, i: int) -> str:
        return f"y[{i}]"

    def temp(self, i: int) -> str:
        return f"_t{i}"

    def pow(self, a: str, b: str) -> str:
        return f"{a} ** {b}"

    def window(self, t: str, a: str, b: str) -> str:
        raise NotImplementedError

    def step(self, a: str) -> str:
        raise NotImplementedError

    def minmax(self, op: str, args: list[str]) -> str:
        out = args[0]
        for x in args[1:]:
            out = f"{op}({out}, {x})"
        return out

    def func(self, op: str, a: str) -> str:
        return f"{op}({a})"

    # -- commun --------------------------------------------------------------------
    def _num(self, v: float) -> str:
        s = self.num(v)
        return f"({s})" if (v < 0 or s.startswith("-")) else s

    def operand(self, o: Operand) -> str:
        if o.kind == "const":
            return self._num(o.value)
        if o.kind == "param":
            return self.param(o.value)
        if o.kind == "state":
            return self.state(o.value)
        if o.kind == "temp":
            return self.temp(o.value)
        return "t"

    def expr(self, ins: Instr) -> str:
        a = [self.operand(x) for x in ins.args]
        op = ins.op
        if op in _SYM:
            return f"{a[0]} {_SYM[op]} {a[1]}"
        if op == "neg":
            return f"-{a[0]}"
        if op == "copy":
            return a[0]
        if op == "pow":
            return self.pow(a[0], a[1])
        if op == "window":
            return self.window(*a)
        if op == "sum":
            return " + ".join(a)
        if op in ("min", "max"):
            return self.minmax(op, a)
        if op == "step":
            return self.step(a[0])
        return self.func(op, a[0])

    def header(self) -> list[str]:
        p = self.prog
        c = self.comment
        lines = [f"{c} Généré par le compilateur EpiNetLang (backend {self.name}) le {date.today():%d/%m/%Y}",
                 f"{c} Modèle : {p.name}",
                 f"{c} Compartiments : {', '.join(p.compartments)}",
                 f"{c} Flux :"]
        for f in p.flows:
            src = "*" if f.src is None else p.compartments[f.src]
            dst = "*" if f.dst is None else p.compartments[f.dst]
            lines.append(f"{c}   {f.label} : {src} -> {dst}")
        if p.events:
            lines.append(f"{c} Événements : " + ", ".join(f"{e.name} (t={e.time:g})" for e in p.events))
        return lines

    def generate(self) -> str:
        raise NotImplementedError

    @staticmethod
    def is_inf(v: float) -> bool:
        return math.isinf(v)


def get_backend(name: str):
    from .cpp_backend import CppBackend
    from .julia_backend import JuliaBackend
    from .mobile_backend import MobileBackend
    from .python_backend import PythonBackend
    table = {"python": PythonBackend, "julia": JuliaBackend, "cpp": CppBackend, "c++": CppBackend,
             "mobile": MobileBackend, "kotlin": MobileBackend}
    try:
        return table[name.lower()]
    except KeyError:
        raise ValueError(f"backend inconnu « {name} » (python, julia, cpp, mobile)") from None


BACKEND_NAMES = ("python", "julia", "cpp", "mobile")
