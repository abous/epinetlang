"""Backend Python/NumPy : module autonome importable ou exécutable.

    python sir.py --t-end 200 --out sir.csv
"""
from __future__ import annotations

from . import Backend


class PythonBackend(Backend):
    name = "python"
    extension = ".py"
    comment = "#"

    def num(self, v: float) -> str:
        if self.is_inf(v):
            return "math.inf" if v > 0 else "-math.inf"
        return repr(float(v))

    def window(self, t: str, a: str, b: str) -> str:
        return f"(1.0 if {a} <= {t} < {b} else 0.0)"

    def step(self, a: str) -> str:
        return f"(1.0 if {a} >= 0 else 0.0)"

    def func(self, op: str, a: str) -> str:
        return f"abs({a})" if op == "abs" else f"math.{op}({a})"

    def _block(self, block, indent="    ") -> list[str]:
        return [f"{indent}{self.temp(i.dest)} = {self.expr(i)}" for i in block]

    def generate(self) -> str:
        p = self.prog
        L = ['"""'] + [l.lstrip("# ") for l in self.header()] + ['"""', "import math", "", "import numpy as np", ""]
        L += [f"MODEL_NAME = {p.name!r}",
              f"COMPARTMENTS = {p.compartments!r}",
              f"PARAM_NAMES = {p.param_names!r}",
              f"PARAMS = np.array({[float(v) for v in p.param_values]!r}, dtype=np.float64)",
              f"Y0 = np.array({[float(v) for v in p.initial]!r}, dtype=np.float64)",
              "# (source, cible) de chaque flux ; -1 = extérieur du système",
              f"STOICH = {[(-1 if f.src is None else f.src, -1 if f.dst is None else f.dst) for f in p.flows]!r}",
              f"FLOW_LABELS = {[f.label for f in p.flows]!r}",
              f"T_START, T_END, DT, OUTPUT_EVERY = {p.sim.t_start!r}, {p.sim.t_end!r}, {p.sim.dt!r}, {p.sim.output_every!r}",
              "", ""]
        # flux
        L.append("def flows(t, y, p):")
        L.append('    """Valeur de chaque flux (individus / unité de temps)."""')
        L += self._block(p.body)
        L.append(f"    return [{', '.join(self.operand(f.value) for f in p.flows)}]")
        L += ["", ""]
        # second membre
        L.append("def rhs(t, y, p):")
        L.append('    """Second membre dy/dt du système d\'EDO."""')
        L.append("    f = flows(t, y, p)")
        L.append("    dy = np.zeros_like(y)")
        for i, terms in enumerate(p.derivative_terms()):
            if terms:
                expr = " ".join(("+ " if s > 0 else "- ") + f"f[{j}]" for s, j in terms)
                expr = expr[2:] if expr.startswith("+ ") else "-" + expr[2:]
                L.append(f"    dy[{i}] = {expr}  # d{p.compartments[i]}/dt")
        L.append("    return dy")
        L += ["", ""]
        # événements
        names = []
        for k, ev in enumerate(p.events):
            fname = f"_event_{k}"
            names.append((ev.time, fname))
            L.append(f"def {fname}(t, y, p):")
            L.append(f'    """Intervention ponctuelle « {ev.name} » (t = {ev.time:g})."""')
            L += self._block(ev.block)
            for j, a in enumerate(ev.actions):
                L.append(f"    _a{j} = {self.operand(a.value)}")
            for j, a in enumerate(ev.actions):
                s = self.state(a.src) if a.src is not None else None
                if a.kind == "add":
                    L.append(f"    {s} = {s} + _a{j}")
                elif a.kind == "sub":
                    L.append(f"    {s} = max({s} - _a{j}, 0.0)")
                elif a.kind == "set":
                    L.append(f"    {s} = max(_a{j}, 0.0)")
                elif a.kind == "mul":
                    L.append(f"    {s} = max({s} * _a{j}, 0.0)")
                elif a.kind == "div":
                    L.append(f"    {s} = max({s} / _a{j}, 0.0)")
                else:
                    d = self.state(a.dst)
                    L.append(f"    _m{j} = min(max(_a{j}, 0.0), {s})")
                    L.append(f"    {s} = {s} - _m{j}")
                    L.append(f"    {d} = {d} + _m{j}")
            L.append("    return y")
            L += ["", ""]
        L.append(f"EVENTS = [{', '.join(f'({t!r}, {n})' for t, n in names)}]")
        L += ["", "", _SIMULATE, "", "", _MAIN]
        return "\n".join(L) + "\n"


_SIMULATE = '''def simulate(t_end=None, dt=None, y0=None, p=None, output_every=None,
             dtype=np.float64, t_start=None, clamp=True):
    """Intégration RK4 à pas fixe, avec interventions ponctuelles.

    Renvoie (t, y) : vecteur des temps et matrice (n_temps × n_compartiments).
    """
    t_start = T_START if t_start is None else t_start
    t_end = T_END if t_end is None else t_end
    dt = DT if dt is None else dt
    output_every = OUTPUT_EVERY if output_every is None else output_every
    y = np.array(Y0 if y0 is None else y0, dtype=dtype)
    p = PARAMS if p is None else np.asarray(p, dtype=np.float64)
    n = max(1, int(math.ceil((t_end - t_start) / dt - 1e-9)))
    events = sorted(EVENTS, key=lambda e: e[0])
    ke = 0
    ts, ys = [t_start], [y.copy()]
    t = t_start
    for k in range(n):
        while ke < len(events) and events[ke][0] <= t + 1e-9:
            y = events[ke][1](t, y.copy(), p)
            ke += 1
        h = min(dt, t_end - t)
        k1 = rhs(t, y, p)
        k2 = rhs(t + h / 2, y + (h / 2) * k1, p)
        k3 = rhs(t + h / 2, y + (h / 2) * k2, p)
        k4 = rhs(t + h, y + h * k3, p)
        y = y + (h / 6) * (k1 + 2 * k2 + 2 * k3 + k4)
        if clamp:
            np.maximum(y, 0, out=y)
        t = t_end if k == n - 1 else t_start + (k + 1) * dt
        if (k + 1) % output_every == 0 or k == n - 1:
            ts.append(t)
            ys.append(y.copy())
    return np.array(ts), np.array(ys)'''

_MAIN = '''def main(argv=None):
    import argparse
    import sys
    ap = argparse.ArgumentParser(description=f"Simulation du modèle {MODEL_NAME}")
    ap.add_argument("--t-end", type=float, default=T_END)
    ap.add_argument("--dt", type=float, default=DT)
    ap.add_argument("--out", help="fichier CSV (défaut : sortie standard)")
    args = ap.parse_args(argv)
    t, y = simulate(args.t_end, args.dt)
    out = open(args.out, "w", encoding="utf-8") if args.out else sys.stdout
    out.write("t," + ",".join(COMPARTMENTS) + "\\n")
    for ti, yi in zip(t, y):
        out.write(f"{ti:g}," + ",".join(f"{v:.6g}" for v in yi) + "\\n")
    if args.out:
        out.close()


if __name__ == "__main__":
    main()'''
