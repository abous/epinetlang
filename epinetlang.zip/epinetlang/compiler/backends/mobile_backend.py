"""Backend mobile : Kotlin (Android), simple précision, sortie en flux.

Choix adaptés aux téléphones d'entrée de gamme :

* ``Float`` (32 bits) au lieu de ``Double`` : moitié moins de mémoire ;
* tableaux de travail alloués **une seule fois** (aucune allocation dans la boucle,
  donc pas de pression sur le ramasse-miettes) ;
* résultats transmis par *callback* ligne par ligne : la trajectoire complète
  n'est jamais stockée en mémoire.

Utilisation côté Android :

    SirModel.simulate { t, y -> graphique.ajouterPoint(t, y[1]) }
"""
from __future__ import annotations

from . import Backend, quote_list


def _class_name(name: str) -> str:
    parts = [p for p in name.replace("-", "_").split("_") if p]
    return "".join(p[:1].upper() + p[1:] for p in parts) + "Model"


class MobileBackend(Backend):
    name = "mobile"
    extension = ".kt"
    comment = "//"

    def num(self, v: float) -> str:
        if self.is_inf(v):
            return "Float.POSITIVE_INFINITY" if v > 0 else "Float.NEGATIVE_INFINITY"
        return f"{float(v)!r}f"

    def pow(self, a: str, b: str) -> str:
        return f"({a}).pow({b})"

    def window(self, t: str, a: str, b: str) -> str:
        return f"(if ({t} >= {a} && {t} < {b}) 1f else 0f)"

    def step(self, a: str) -> str:
        return f"(if ({a} >= 0f) 1f else 0f)"

    def func(self, op: str, a: str) -> str:
        return f"{'ln' if op == 'log' else op}({a})"   # kotlin.math.ln = logarithme népérien

    def _block(self, block, indent="        ") -> list[str]:
        return [f"{indent}val {self.temp(i.dest)} = {self.expr(i)}" for i in block]

    def generate(self) -> str:
        p = self.prog
        cls = _class_name(p.name)
        arr = lambda xs: "floatArrayOf(" + ", ".join(self.num(float(x)) for x in xs) + ")"
        nf = max(len(p.flows), 1)
        L = self.header() + ["",
             "package epinetlang.generated", "",
             "import kotlin.math.*", "",
             f"object {cls} {{",
             f"    val COMPARTMENTS = arrayOf({quote_list(p.compartments)})",
             f"    val PARAM_NAMES = arrayOf({quote_list(p.param_names)})",
             f"    val PARAMS = {arr(p.param_values)}",
             f"    val Y0 = {arr(p.initial)}",
             f"    const val T_START = {self.num(p.sim.t_start)}",
             f"    const val T_END = {self.num(p.sim.t_end)}",
             f"    const val DT = {self.num(p.sim.dt)}",
             f"    const val OUTPUT_EVERY = {p.sim.output_every}",
             f"    private const val NC = {len(p.compartments)}",
             f"    private const val NF = {nf}", "",
             "    fun flows(t: Float, y: FloatArray, p: FloatArray, f: FloatArray) {"]
        L += self._block(p.body)
        for j, fl in enumerate(p.flows):
            L.append(f"        f[{j}] = {self.operand(fl.value)}  // {fl.label}")
        L += ["    }", "",
              "    fun rhs(t: Float, y: FloatArray, p: FloatArray, f: FloatArray, dy: FloatArray) {",
              "        flows(t, y, p, f)"]
        for i, terms in enumerate(p.derivative_terms()):
            expr = " ".join(("+ " if s > 0 else "- ") + f"f[{j}]" for s, j in terms) or "+ 0f"
            expr = expr[2:] if expr.startswith("+ ") else "-" + expr[2:]
            L.append(f"        dy[{i}] = {expr}  // d{p.compartments[i]}/dt")
        L += ["    }", ""]
        for k, ev in enumerate(p.events):
            L += [f"    // Intervention ponctuelle « {ev.name} » (t = {ev.time:g})",
                  f"    private fun event{k}(y: FloatArray, p: FloatArray) {{"]
            L += self._block(ev.block)
            for j, a in enumerate(ev.actions):
                L.append(f"        val a{j} = {self.operand(a.value)}")
            for j, a in enumerate(ev.actions):
                s = self.state(a.src) if a.src is not None else None
                if a.kind == "add":
                    L.append(f"        {s} += a{j}")
                elif a.kind == "sub":
                    L.append(f"        {s} = max({s} - a{j}, 0f)")
                elif a.kind == "set":
                    L.append(f"        {s} = max(a{j}, 0f)")
                elif a.kind == "mul":
                    L.append(f"        {s} = max({s} * a{j}, 0f)")
                elif a.kind == "div":
                    L.append(f"        {s} = max({s} / a{j}, 0f)")
                else:
                    L.append(f"        val m{j} = min(max(a{j}, 0f), {s})")
                    L.append(f"        {s} -= m{j}; {self.state(a.dst)} += m{j}")
            L += ["    }", ""]
        times = ", ".join(self.num(e.time) for e in p.events)
        L += [f"    private val EVENT_T = floatArrayOf({times})",
              "    private fun applyEvent(k: Int, y: FloatArray, p: FloatArray) {",
              "        when (k) {"]
        L += [f"            {k} -> event{k}(y, p)" for k in range(len(p.events))]
        L += ["            else -> {}", "        }", "    }", "", _KT_SIM, "}", "",
              "/** Point d'entrée JVM pour tester hors Android : imprime un CSV. */",
              "fun main() {",
              f"    println(\"t,\" + {cls}.COMPARTMENTS.joinToString(\",\"))",
              f"    {cls}.simulate {{ t, y -> println(\"$t,\" + y.joinToString(\",\")) }}",
              "}"]
        return "\n".join(L) + "\n"


_KT_SIM = '''    /**
     * Intégration RK4 à pas fixe. [onRow] reçoit (t, état) toutes les [outputEvery]
     * itérations ; le tableau d'état est réutilisé : le copier si on le conserve.
     */
    fun simulate(
        tEnd: Float = T_END, dt: Float = DT, outputEvery: Int = OUTPUT_EVERY,
        p: FloatArray = PARAMS, onRow: (Float, FloatArray) -> Unit
    ) {
        val y = Y0.copyOf()
        val f = FloatArray(NF)
        val k1 = FloatArray(NC); val k2 = FloatArray(NC); val k3 = FloatArray(NC); val k4 = FloatArray(NC)
        val tmp = FloatArray(NC)
        val n = max(1, ceil((tEnd - T_START) / dt - 1e-6f).toInt())
        var ke = 0
        var t = T_START
        onRow(t, y)
        for (k in 0 until n) {
            while (ke < EVENT_T.size && EVENT_T[ke] <= t + 1e-6f) applyEvent(ke++, y, p)
            val h = min(dt, tEnd - t)
            rhs(t, y, p, f, k1)
            for (i in 0 until NC) tmp[i] = y[i] + h / 2 * k1[i]
            rhs(t + h / 2, tmp, p, f, k2)
            for (i in 0 until NC) tmp[i] = y[i] + h / 2 * k2[i]
            rhs(t + h / 2, tmp, p, f, k3)
            for (i in 0 until NC) tmp[i] = y[i] + h * k3[i]
            rhs(t + h, tmp, p, f, k4)
            for (i in 0 until NC) y[i] = max(y[i] + h / 6 * (k1[i] + 2 * k2[i] + 2 * k3[i] + k4[i]), 0f)
            t = if (k == n - 1) tEnd else T_START + (k + 1) * dt
            if ((k + 1) % outputEvery == 0 || k == n - 1) onRow(t, y)
        }
    }'''
