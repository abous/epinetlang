"""Backend Julia : script autonome (RK4 intégré).

La fonction ``rhs!(dy, y, p, t)`` a la signature attendue par
DifferentialEquations.jl ; on peut donc aussi écrire
``solve(ODEProblem(rhs!, Y0, (T_START, T_END), P))``.

    julia sir.jl > sir.csv
"""
from __future__ import annotations

from . import Backend, quote_list


class JuliaBackend(Backend):
    name = "julia"
    extension = ".jl"
    comment = "#"

    def num(self, v: float) -> str:
        if self.is_inf(v):
            return "Inf" if v > 0 else "-Inf"
        return repr(float(v))

    def param(self, i: int) -> str:
        return f"p[{i + 1}]"

    def state(self, i: int) -> str:
        return f"y[{i + 1}]"

    def pow(self, a: str, b: str) -> str:
        return f"{a} ^ {b}"

    def window(self, t: str, a: str, b: str) -> str:
        return f"ifelse({a} <= {t} < {b}, 1.0, 0.0)"

    def step(self, a: str) -> str:
        return f"ifelse({a} >= 0, 1.0, 0.0)"

    def _block(self, block, indent="    ") -> list[str]:
        return [f"{indent}{self.temp(i.dest)} = {self.expr(i)}" for i in block]

    def generate(self) -> str:
        p = self.prog
        vec = lambda xs: "[" + ", ".join(self.num(float(x)) for x in xs) + "]"
        L = self.header() + ["",
             f'const MODEL_NAME = "{p.name}"',
             f"const COMPARTMENTS = [{quote_list(p.compartments)}]",
             f"const PARAM_NAMES = [{quote_list(p.param_names)}]",
             f"const P = {vec(p.param_values) if p.param_values else 'Float64[]'}",
             f"const Y0 = {vec(p.initial)}",
             f"const T_START, T_END, DT, OUTPUT_EVERY = {self.num(p.sim.t_start)}, {self.num(p.sim.t_end)}, "
             f"{self.num(p.sim.dt)}, {p.sim.output_every}",
             "", "function flows!(f, t, y, p)"]
        L += self._block(p.body)
        for j, fl in enumerate(p.flows):
            L.append(f"    f[{j + 1}] = {self.operand(fl.value)}  # {fl.label}")
        L += ["    return f", "end", "",
              "function rhs!(dy, y, p, t)",
              f"    f = zeros(eltype(y), {max(len(p.flows), 1)})",
              "    flows!(f, t, y, p)"]
        for i, terms in enumerate(p.derivative_terms()):
            expr = " ".join(("+ " if s > 0 else "- ") + f"f[{j + 1}]" for s, j in terms) or "+ zero(eltype(y))"
            expr = expr[2:] if expr.startswith("+ ") else "-" + expr[2:]
            L.append(f"    dy[{i + 1}] = {expr}  # d{p.compartments[i]}/dt")
        L += ["    return dy", "end", ""]
        names = []
        for k, ev in enumerate(p.events):
            names.append(f"({self.num(ev.time)}, event_{k}!)")
            L += [f"# Intervention ponctuelle « {ev.name} » (t = {ev.time:g})", f"function event_{k}!(y, p)"]
            L += self._block(ev.block)
            for j, a in enumerate(ev.actions):
                L.append(f"    a{j} = {self.operand(a.value)}")
            for j, a in enumerate(ev.actions):
                s = self.state(a.src) if a.src is not None else None
                if a.kind == "add":
                    L.append(f"    {s} += a{j}")
                elif a.kind == "sub":
                    L.append(f"    {s} = max({s} - a{j}, 0.0)")
                elif a.kind == "set":
                    L.append(f"    {s} = max(a{j}, 0.0)")
                elif a.kind == "mul":
                    L.append(f"    {s} = max({s} * a{j}, 0.0)")
                elif a.kind == "div":
                    L.append(f"    {s} = max({s} / a{j}, 0.0)")
                else:
                    L.append(f"    m{j} = min(max(a{j}, 0.0), {s})")
                    L.append(f"    {s} -= m{j}; {self.state(a.dst)} += m{j}")
            L += ["    return y", "end", ""]
        L.append(f"const EVENTS = [{', '.join(names)}]" if names else "const EVENTS = Tuple{Float64,Function}[]")
        L += ["", _JL_SIM]
        return "\n".join(L) + "\n"


_JL_SIM = '''"""Intégration RK4 à pas fixe ; renvoie (t, Y) avec Y de taille n_temps × n_compartiments."""
function simulate(; t_end=T_END, dt=DT, y0=Y0, p=P, output_every=OUTPUT_EVERY)
    y = copy(y0)
    n = max(1, ceil(Int, (t_end - T_START) / dt - 1e-9))
    ts = [T_START]; ys = [copy(y)]
    ke = 1; t = T_START
    k1 = similar(y); k2 = similar(y); k3 = similar(y); k4 = similar(y)
    for k in 1:n
        while ke <= length(EVENTS) && EVENTS[ke][1] <= t + 1e-9
            EVENTS[ke][2](y, p); ke += 1
        end
        h = min(dt, t_end - t)
        rhs!(k1, y, p, t)
        rhs!(k2, y .+ (h / 2) .* k1, p, t + h / 2)
        rhs!(k3, y .+ (h / 2) .* k2, p, t + h / 2)
        rhs!(k4, y .+ h .* k3, p, t + h)
        @. y = max(y + (h / 6) * (k1 + 2k2 + 2k3 + k4), 0.0)
        t = k == n ? t_end : T_START + k * dt
        if k % output_every == 0 || k == n
            push!(ts, t); push!(ys, copy(y))
        end
    end
    return ts, reduce(vcat, permutedims.(ys))
end

if abspath(PROGRAM_FILE) == @__FILE__
    ts, Y = simulate()
    println("t,", join(COMPARTMENTS, ","))
    for i in eachindex(ts)
        println(ts[i], ",", join(Y[i, :], ","))
    end
end'''
