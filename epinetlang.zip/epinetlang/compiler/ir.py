"""Représentation intermédiaire (IR) d'EpiNetLang : code à trois adresses.

Un modèle est abaissé en :

* ``body``   : liste d'instructions ``_tK = op(a, b, …)`` évaluées à chaque appel
               du second membre (paramètres effectifs + taux des flux) ;
* ``flows``  : pour chaque transition, (source, cible, opérande du taux) ;
* ``events`` : interventions ponctuelles (« at t »), chacune avec son propre
               bloc d'instructions et ses actions sur l'état.

Les interventions de type fenêtre sont *intégrées* dans le corps grâce à
l'opération ``window(t, a, b)`` (1 si a ≤ t < b, 0 sinon), ce qui rend le code
généré autonome dans tous les backends.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field

from ..core import ast
from ..core.model import EpidemicModel, SimulationConfig, Transition


# ---------------------------------------------------------------------------
# Opérandes
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class Operand:
    kind: str        # 'const' | 'param' | 'state' | 'temp' | 'time'
    value: float | int = 0

    def __str__(self) -> str:
        if self.kind == "const":
            return f"{self.value:g}"
        if self.kind == "time":
            return "t"
        prefix = {"param": "p", "state": "y", "temp": "%"}[self.kind]
        return f"{prefix}{self.value}"


def Const(v: float) -> Operand:
    return Operand("const", float(v))


TIME = Operand("time", 0)

# Opérations : arité (-1 = variable)
OPS = {"add": 2, "sub": 2, "mul": 2, "div": 2, "pow": 2, "neg": 1, "copy": 1,
       "window": 3, "sum": -1, "min": -1, "max": -1, "step": 1,
       "exp": 1, "log": 1, "log10": 1, "sqrt": 1, "abs": 1, "sin": 1, "cos": 1, "tanh": 1}
COMMUTATIVE = {"add", "mul", "sum", "min", "max"}
_BIN = {"+": "add", "-": "sub", "*": "mul", "/": "div", "^": "pow"}


@dataclass
class Instr:
    dest: int
    op: str
    args: tuple[Operand, ...]

    def __str__(self) -> str:
        return f"%{self.dest} = {self.op}({', '.join(map(str, self.args))})"


@dataclass
class IRFlow:
    label: str
    src: int | None
    dst: int | None
    value: Operand


@dataclass
class IREventAction:
    kind: str            # 'add' | 'sub' | 'set' | 'mul' | 'div' | 'move'
    src: int | None      # compartiment visé (ou source du transfert)
    dst: int | None      # cible du transfert ('move')
    value: Operand


@dataclass
class IREvent:
    name: str
    time: float
    block: list[Instr] = field(default_factory=list)
    actions: list[IREventAction] = field(default_factory=list)
    param_updates: list[tuple[int, str, Operand]] = field(default_factory=list)


@dataclass
class IRProgram:
    name: str
    compartments: list[str]
    initial: list[float]
    param_names: list[str]
    param_values: list[float]
    body: list[Instr]
    flows: list[IRFlow]
    events: list[IREvent]
    sim: SimulationConfig
    n_temps: int = 0
    meta: dict = field(default_factory=dict)

    @property
    def n_instructions(self) -> int:
        return len(self.body) + sum(len(e.block) for e in self.events)

    def derivative_terms(self) -> list[list[tuple[int, int]]]:
        """Pour chaque compartiment : liste de (signe, indice du flux)."""
        terms: list[list[tuple[int, int]]] = [[] for _ in self.compartments]
        for j, f in enumerate(self.flows):
            if f.src is not None:
                terms[f.src].append((-1, j))
            if f.dst is not None:
                terms[f.dst].append((+1, j))
        return terms

    def dump(self) -> str:
        out = [f"; IR du modèle {self.name}",
               "; état      : " + ", ".join(f"y{i}={c}" for i, c in enumerate(self.compartments)),
               "; paramètres : " + ", ".join(f"p{i}={n}" for i, n in enumerate(self.param_names)),
               "body:"]
        out += [f"  {ins}" for ins in self.body]
        out.append("flows:")
        for f in self.flows:
            src = "*" if f.src is None else self.compartments[f.src]
            dst = "*" if f.dst is None else self.compartments[f.dst]
            out.append(f"  {f.label}: {src} -> {dst} = {f.value}")
        for ev in self.events:
            out.append(f"event {ev.name} @ t={ev.time:g}:")
            out += [f"  {ins}" for ins in ev.block]
            for a in ev.actions:
                tgt = self.compartments[a.src] if a.src is not None else "*"
                extra = f" -> {self.compartments[a.dst]}" if a.dst is not None else ""
                out.append(f"  {a.kind} {tgt}{extra}, {a.value}")
            for pi, op, v in ev.param_updates:
                out.append(f"  param {self.param_names[pi]} {op} {v}")
        return "\n".join(out)


# ---------------------------------------------------------------------------
# Abaissement AST → IR
# ---------------------------------------------------------------------------
class IRBuilder:
    def __init__(self, model: EpidemicModel):
        self.model = model
        self.n_temps = 0

    def _emit(self, block: list[Instr], op: str, *args: Operand) -> Operand:
        dest = self.n_temps
        self.n_temps += 1
        block.append(Instr(dest, op, tuple(args)))
        return Operand("temp", dest)

    def _lower(self, e: ast.Expr, env: dict[str, Operand], block: list[Instr], cache: dict) -> Operand:
        if isinstance(e, ast.Number):
            return Const(e.value)
        if isinstance(e, ast.Name):
            return TIME if e.id == "t" else env[e.id]
        if isinstance(e, ast.UnaryOp):
            return self._emit(block, "neg", self._lower(e.operand, env, block, cache))
        if isinstance(e, ast.BinOp):
            a = self._lower(e.left, env, block, cache)
            b = self._lower(e.right, env, block, cache)
            return self._emit(block, _BIN[e.op], a, b)
        if isinstance(e, ast.Call):
            if e.func == "total":
                return self._total(block, cache)
            if e.func in ("contact", "neighbours"):
                frac = self._emit(block, "div", env[e.args[0].id], self._total(block, cache))
                if e.func == "contact":
                    return frac
                return self._emit(block, "mul", Const(self.model.mean_degree or 0.0), frac)
            args = [self._lower(a, env, block, cache) for a in e.args]
            return self._emit(block, e.func, *args)
        raise TypeError(e)

    def _total(self, block: list[Instr], cache: dict) -> Operand:
        if "total" not in cache:
            states = [Operand("state", i) for i in range(len(self.model.compartments))]
            cache["total"] = self._emit(block, "sum", *states)
        return cache["total"]

    def _apply_param_op(self, block, base: Operand, op: str, v: Operand, w: Operand) -> Operand:
        """Paramètre effectif = base modifié quand la fenêtre w vaut 1."""
        if op == "*=":       # base * (1 + (v - 1) w)
            k = self._emit(block, "add", Const(1), self._emit(block, "mul", self._emit(block, "sub", v, Const(1)), w))
            return self._emit(block, "mul", base, k)
        if op == "/=":       # base * (1 + (1/v - 1) w)
            inv = self._emit(block, "div", Const(1), v)
            k = self._emit(block, "add", Const(1), self._emit(block, "mul", self._emit(block, "sub", inv, Const(1)), w))
            return self._emit(block, "mul", base, k)
        if op == "+=":
            return self._emit(block, "add", base, self._emit(block, "mul", v, w))
        if op == "-=":
            return self._emit(block, "sub", base, self._emit(block, "mul", v, w))
        # '=' : base + (v - base) w
        return self._emit(block, "add", base, self._emit(block, "mul", self._emit(block, "sub", v, base), w))

    def build(self) -> IRProgram:
        m = self.model
        idx = m.index
        body: list[Instr] = []
        cache: dict = {}
        env: dict[str, Operand] = {name: Operand("param", i) for i, name in enumerate(m.params)}
        env.update({c: Operand("state", i) for i, c in enumerate(m.compartments)})

        # 1. paramètres modifiés par les interventions
        for iv in m.interventions:
            if not iv.param_changes:
                continue
            end = Const(math.inf if iv.kind == "pulse" else iv.end)
            w = self._emit(body, "window", TIME, Const(iv.start), end)
            for name, op, value in iv.param_changes:
                v = self._lower(value, env, body, cache)
                env[name] = self._apply_param_op(body, env[name], op, v, w)

        # 2. flux des transitions du modèle
        flows: list[IRFlow] = []

        def add_flow(tr: Transition, gate: Operand | None = None):
            val = self._lower(tr.rate, env, body, cache)
            if gate is not None:
                val = self._emit(body, "mul", val, gate)
            flows.append(IRFlow(tr.label,
                                None if tr.source is None else idx[tr.source],
                                None if tr.target is None else idx[tr.target], val))

        for tr in m.transitions:
            add_flow(tr)
        # 3. transitions actives seulement pendant une fenêtre d'intervention
        for iv in m.interventions:
            if iv.kind == "window" and iv.transitions:
                w = self._emit(body, "window", TIME, Const(iv.start), Const(iv.end))
                for tr in iv.transitions:
                    add_flow(tr, w)

        # 4. événements ponctuels
        events: list[IREvent] = []
        base_env = {name: Operand("param", i) for i, name in enumerate(m.params)}
        base_env.update({c: Operand("state", i) for i, c in enumerate(m.compartments)})
        kinds = {"+=": "add", "-=": "sub", "=": "set", "*=": "mul", "/=": "div"}
        for iv in m.interventions:
            if iv.kind != "pulse" or not (iv.state_changes or iv.transitions):
                continue
            ev = IREvent(iv.name, iv.start)
            ecache: dict = {}
            for comp, op, value in iv.state_changes:
                v = self._lower(value, base_env, ev.block, ecache)
                ev.actions.append(IREventAction(kinds[op], idx[comp], None, v))
            for tr in iv.transitions:
                v = self._lower(tr.rate, base_env, ev.block, ecache)
                src = None if tr.source is None else idx[tr.source]
                dst = None if tr.target is None else idx[tr.target]
                if src is None:
                    ev.actions.append(IREventAction("add", dst, None, v))
                elif dst is None:
                    ev.actions.append(IREventAction("sub", src, None, v))
                else:
                    ev.actions.append(IREventAction("move", src, dst, v))
            events.append(ev)
        events.sort(key=lambda e: e.time)

        return IRProgram(
            name=m.name, compartments=list(m.compartments),
            initial=[m.initial[c] for c in m.compartments],
            param_names=list(m.params), param_values=list(m.params.values()),
            body=body, flows=flows, events=events, sim=m.simulation, n_temps=self.n_temps,
            meta={"mean_degree": m.mean_degree},
        )


def lower(model: EpidemicModel) -> IRProgram:
    return IRBuilder(model).build()
