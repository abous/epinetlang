"""Générateur de code principal : orchestre toute la chaîne de compilation.

    source .epi ─► lexer ─► parser ─► AST ─► validateur ─► modèle
                ─► IR ─► optimiseur ─► backend ─► code cible
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from pathlib import Path

from ..core import ast
from ..core.errors import EpiNetLangError
from ..core.model import EpidemicModel
from ..core.validator import ValidationReport, validate
from ..grammar.parser import parse
from .backends import get_backend
from .ir import IRProgram, lower
from .optimizer import OptimizationStats, Optimizer


@dataclass
class CompilationResult:
    model: EpidemicModel
    report: ValidationReport
    ir: IRProgram
    optimized: IRProgram
    stats: OptimizationStats
    target: str
    code: str
    extension: str
    timings: dict = field(default_factory=dict)

    def write(self, path: str | Path | None = None) -> Path:
        path = Path(path) if path else Path(self.model.name.lower() + self.extension)
        path.write_text(self.code, encoding="utf-8")
        return path

    def summary(self) -> str:
        ms = " | ".join(f"{k} {v * 1000:.1f} ms" for k, v in self.timings.items())
        return f"[{self.target}] {self.model.name} — {self.stats}\n  temps : {ms}"


def select_model(program: ast.Program, name: str | None = None) -> ast.ModelDecl:
    if name is None:
        return program.models[0]
    for m in program.models:
        if m.name == name:
            return m
    raise EpiNetLangError(f"modèle « {name} » introuvable (modèles : "
                          f"{', '.join(m.name for m in program.models)})")


def load_model(source: str, filename: str = "<source>", model_name: str | None = None,
               overrides: dict | None = None) -> tuple[EpidemicModel, ValidationReport]:
    """Analyse et valide un source ; lève une exception en cas d'erreur."""
    program = parse(source, filename)
    decl = select_model(program, model_name)
    report = validate(decl)
    report.raise_if_errors()
    return EpidemicModel(decl, overrides), report


class CodeGenerator:
    def __init__(self, target: str = "python", opt_level: int = 2):
        self.target = target
        self.backend_cls = get_backend(target)
        self.opt_level = opt_level

    def compile_model(self, model: EpidemicModel, report: ValidationReport | None = None,
                      timings: dict | None = None) -> CompilationResult:
        timings = dict(timings or {})
        t0 = time.perf_counter()
        ir = lower(model)
        t1 = time.perf_counter()
        opt = Optimizer(self.opt_level)
        optimized = opt.optimize(ir)
        t2 = time.perf_counter()
        backend = self.backend_cls(optimized)
        code = backend.generate()
        t3 = time.perf_counter()
        timings.update({"IR": t1 - t0, "optimisation": t2 - t1, "génération": t3 - t2})
        return CompilationResult(model, report or validate(model.decl), ir, optimized, opt.stats,
                                 backend.name, code, backend.extension, timings)

    def compile(self, source: str, filename: str = "<source>", model_name: str | None = None,
                overrides: dict | None = None) -> CompilationResult:
        t0 = time.perf_counter()
        program = parse(source, filename)
        t1 = time.perf_counter()
        decl = select_model(program, model_name)
        report = validate(decl)
        report.raise_if_errors()
        model = EpidemicModel(decl, overrides)
        t2 = time.perf_counter()
        return self.compile_model(model, report, {"analyse": t1 - t0, "sémantique": t2 - t1})

    def compile_file(self, path: str | Path, **kw) -> CompilationResult:
        path = Path(path)
        return self.compile(path.read_text(encoding="utf-8"), str(path), **kw)


def compile_source(source: str, target: str = "python", opt_level: int = 2, **kw) -> CompilationResult:
    return CodeGenerator(target, opt_level).compile(source, **kw)
