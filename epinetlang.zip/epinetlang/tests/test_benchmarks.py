"""Tests des modèles VIH-SIDA et du banc d'essai."""
import math
from pathlib import Path

import numpy as np
import pytest

from epinetlang import api
from epinetlang.benchmarks import run_benchmarks as rb
from epinetlang.benchmarks.closed_forms import CLOSED_FORMS, closed_form
from epinetlang.runtime.r0_calculator import R0Calculator

MODELS = Path(__file__).resolve().parent.parent / "benchmarks" / "models"
HIV = ["hiv_base", "hiv_tarv", "hiv_prevention", "hiv_reseau"]


def hiv(name):
    return api.load(MODELS / f"{name}.epi")


@pytest.mark.parametrize("name", HIV)
def test_hiv_models_are_valid_without_warnings(name):
    m = hiv(name)
    assert m.report.ok and not m.warnings


@pytest.mark.parametrize("name", HIV)
def test_r0_matches_closed_form(name):
    m = hiv(name)
    assert math.isclose(m.r0(), closed_form(name, m.params, m.model.mean_degree), rel_tol=1e-6)


@pytest.mark.parametrize("name", ["hiv_tarv", "hiv_prevention", "hiv_reseau"])
def test_rc_matches_closed_form(name):
    m = hiv(name)
    calc = R0Calculator(m.model)
    dfe = CLOSED_FORMS[name][2]
    for iv in m.model.interventions:
        expected = closed_form(name, calc.manager.params_at(iv.start), m.model.mean_degree)
        assert math.isclose(calc.rc(iv.start, dfe), expected, rel_tol=1e-6)


def test_r0_is_without_treatment_and_rc_decreases():
    m = hiv("hiv_tarv")
    r0 = m.r0()
    assert m.with_params(tau2=0.25, tau3=0.6).r0() < r0       # le traitement dans les paramètres de base → Rc
    assert r0 > m.rc(2004) > m.rc(2016) > 1


def test_prep_needs_controlled_equilibrium():
    m = hiv("hiv_prevention")
    assert math.isclose(m.rc(2019), m.rc(2016), rel_tol=1e-9)            # DFE initiale : PrEP invisible
    assert m.rc(2019, dfe="equilibrium") < 1 < m.rc(2016, dfe="equilibrium")


def test_ptme_and_children_do_not_change_r0():
    m = hiv("hiv_prevention")
    infected = R0Calculator(m.model).infected_compartments()
    assert "Ce" not in infected and "D" not in infected and "P_H" not in infected
    assert math.isclose(m.r0(), hiv("hiv_tarv").r0(), rel_tol=1e-9)


def test_hiv_prevalence_is_plausible():
    m = hiv("hiv_base")
    res = m.simulate()
    prev = rb.hiv_prevalence(m, res)
    assert 0.5 < rb.at_year(res, prev, 1990) < 2
    assert 3 < prev.max() < 8
    assert rb.at_year(res, rb.hiv_prevalence(m, res, ("H",)), 2005) > 30


def test_interventions_reduce_deaths():
    deaths = {n: hiv(n).simulate().final()["D"] for n in ("hiv_base", "hiv_tarv", "hiv_prevention")}
    assert deaths["hiv_base"] > deaths["hiv_tarv"] > deaths["hiv_prevention"]


def test_ptme_reduces_vertical_transmission():
    src = (MODELS / "hiv_prevention.epi").read_text(encoding="utf-8")
    with_ptme = api.loads(src).simulate().final()["Ce"]
    without = api.loads(src.replace("ptme         : from 2008         { v_u *= 0.25; }", "")).simulate().final()["Ce"]
    assert with_ptme < 0.6 * without


def test_optimizer_removes_repeated_force_of_infection():
    m = hiv("hiv_prevention")
    res = m.compile("python", 2)
    assert res.stats.cse >= 40 and res.stats.instructions_after < 0.7 * res.stats.instructions_before


def test_network_amplifies_transmission():
    m = hiv("hiv_reseau")
    mf = m.simulate("rk4")
    net = m.simulate("network", seed=3)
    att = lambda r, n: 1 - r["S"][-1] / n
    assert att(net, 5000) > 1.5 * att(mf, 5000)


def test_benchmark_runner_quick(tmp_path):
    tables = rb.run(tmp_path, quick=True, only="hiv", use_cpp=False, verbose=False)
    assert [t.key for t in tables] == ["B1", "B2", "B3", "B4", "B5", "B6"]
    b3 = next(t for t in tables if t.key == "B3")
    assert all(r["err"] < 1e-6 for r in b3.rows)
    for name in ("benchmarks.md", "benchmarks.tex", "B4.csv"):
        assert (tmp_path / name).exists()
    tex = (tmp_path / "benchmarks.tex").read_text(encoding="utf-8")
    assert r"\begin{tabular}" in tex and "hiv\\_prevention" in tex
