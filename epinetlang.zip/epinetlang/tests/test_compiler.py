"""Tests du compilateur (IR, optimiseur, backends) et de l'exécution."""
import importlib.util
import math
import shutil
import subprocess
from pathlib import Path

import numpy as np
import pytest

from epinetlang import api
from epinetlang.compiler.backends import BACKEND_NAMES
from epinetlang.compiler.codegen import CodeGenerator, load_model
from epinetlang.compiler.ir import lower
from epinetlang.compiler.optimizer import Optimizer
from epinetlang.runtime.simulator import Network, Simulator, scale_counts

EXAMPLES = Path(__file__).resolve().parent.parent / "examples"
ALL = sorted(p.stem for p in EXAMPLES.glob("*.epi"))


def example(name):
    return api.load(EXAMPLES / f"{name}.epi")


# -- IR et optimisations ----------------------------------------------------------------------
def opt_model(rates: str):
    src = f"""model M {{
      parameters {{ N : count = 100; a : rate = 0.2; b : rate = 0.1; }}
      compartments {{ S = 99; I = 1; R = 0; }}
      transitions {{ {rates} }} }}"""
    return load_model(src)[0]


def test_constant_folding_and_simplification():
    m = opt_model("S -> I : (2 * 3 - 5) * a * S * I / N + 0; I -> R : b * I * 1;")
    opt = Optimizer(2)
    prog = opt.optimize(lower(m))
    ops = [i.op for i in prog.body]
    assert opt.stats.folded >= 2 and opt.stats.simplified >= 3
    assert ops.count("mul") + ops.count("div") == len(prog.body)


def test_common_subexpression_elimination():
    m = opt_model("S -> I : a * S * I / N; I -> R : a * S * I / N * b / a;")
    raw = lower(m)
    opt = Optimizer(2)
    prog = opt.optimize(raw)
    assert opt.stats.cse >= 3 and prog.n_instructions < raw.n_instructions


def test_cse_commutativity():
    m = opt_model("S -> I : a * S; I -> R : S * a;")
    opt = Optimizer(2)
    prog = opt.optimize(lower(m))
    assert prog.flows[0].value == prog.flows[1].value


def test_level_3_inlines_parameters():
    m = opt_model("S -> I : a * 2 * S;")
    prog = Optimizer(3).optimize(lower(m))
    assert all(a.kind != "param" for i in prog.body for a in i.args)
    assert any(a.kind == "const" and math.isclose(a.value, 0.4) for i in prog.body for a in i.args)


def test_dead_code_elimination():
    m = load_model("""model M { parameters { a : rate = 0.1; }
        compartments { S = 1; I = 0; }
        transitions { S -> I : a * S; }
        interventions { x : from 1 to 2 { a *= 1; } } }""")[0]
    raw = lower(m)
    prog, = [Optimizer(2).optimize(raw)]
    assert prog.n_instructions < raw.n_instructions


@pytest.mark.parametrize("level", [0, 1, 2, 3])
def test_optimization_preserves_semantics(level):
    m = example("covid_cameroon").model
    base = Simulator(m, backend="interpreted").run(t_end=250)
    code = CodeGenerator("python", level).compile_model(m).code
    ns = {}
    exec(code, ns)
    t, y = ns["simulate"](t_end=250.0)
    assert np.allclose(y, base.y, rtol=1e-9, atol=1e-6)


def test_ir_dump_is_readable():
    text = example("covid_cameroon").ir()
    assert "window(t, 18, 75)" in text and "event importation" in text


# -- backends --------------------------------------------------------------------------------
@pytest.mark.parametrize("name", ALL)
@pytest.mark.parametrize("target", BACKEND_NAMES)
def test_all_backends_generate(name, target):
    res = example(name).compile(target)
    assert res.code.strip() and res.model.name in res.code


@pytest.mark.parametrize("name", ALL)
def test_python_backend_matches_interpreter(name):
    m = example(name).model
    a = Simulator(m, backend="compiled").run(method="rk4", t_end=60)
    b = Simulator(m, backend="interpreted").run(method="rk4", t_end=60)
    assert np.allclose(a.y, b.y, rtol=1e-10, atol=1e-8)


def test_generated_python_is_standalone(tmp_path):
    out = tmp_path / "sir.py"
    example("sir_model").compile("python").write(out)
    csv = tmp_path / "sir.csv"
    subprocess.run(["python3", str(out), "--out", str(csv)], check=True)
    rows = csv.read_text().splitlines()
    assert rows[0] == "t,S,I,R" and len(rows) > 100


@pytest.mark.skipif(shutil.which("g++") is None, reason="g++ absent")
@pytest.mark.parametrize("name", ALL)
def test_cpp_backend_compiles_and_matches(tmp_path, name):
    m = example(name)
    src = tmp_path / "m.cpp"
    m.compile("cpp").write(src)
    exe = tmp_path / "m"
    subprocess.run(["g++", "-O2", "-std=c++17", "-Wall", "-Werror", str(src), "-o", str(exe)], check=True)
    out = subprocess.run([str(exe)], check=True, capture_output=True, text=True).stdout.splitlines()
    last_cpp = np.array([float(v) for v in out[-1].split(",")[1:]])
    last_py = m.simulate(method="rk4").y[-1]
    assert np.allclose(last_cpp, last_py, rtol=1e-4, atol=1e-3)


# -- exécution et R0 ----------------------------------------------------------------------------
def test_sir_final_size_matches_theory():
    res = example("sir_model").simulate()
    s_inf = res["S"][-1] / 1000
    # taille finale : ln(s∞) = R0 (s∞ − 1)  (s0 ≈ 1)
    assert abs(math.log(s_inf) - 3 * (s_inf - 1)) < 0.02


@pytest.mark.parametrize("method", ["euler", "rk4", "rk45"])
def test_ode_methods_agree(method):
    ref = example("sir_model").simulate("rk4", dt=0.01)
    res = example("sir_model").simulate(method)
    assert abs(res["R"][-1] - ref["R"][-1]) < (2 if method == "euler" else 0.05)


def test_population_conserved():
    res = example("sir_model").simulate()
    assert np.allclose(res.y.sum(axis=1), 1000)


@pytest.mark.parametrize("method", ["gillespie", "tau_leap"])
def test_stochastic_methods(method):
    m = example("sir_model")
    res = m.simulate(method, seed=3)
    assert np.all(res.y >= 0) and np.all(res.y == np.round(res.y))
    assert np.allclose(res.y.sum(axis=1), 1000)
    assert m.simulate(method, seed=3).final() == res.final()        # reproductible


def test_ensemble():
    ens = example("sir_model").ensemble(20, method="tau_leap", seed=1)
    assert ens.runs.shape[0] == 20
    assert 900 < ens.mean[-1][2] < 980


def test_r0_values_match_analytic_formulas():
    assert math.isclose(example("sir_model").r0(), 3.0, rel_tol=1e-6)
    s = example("seir_model")
    p = s.params
    expected = p["beta"] * p["sigma"] / ((p["sigma"] + p["mu"]) * (p["gamma"] + p["mu"]))
    assert math.isclose(s.r0(), expected, rel_tol=1e-6)
    c = example("covid_cameroon")
    p = c.params
    expected = p["beta"] * ((1 - p["p_a"]) / (p["gamma_i"] + p["delta"]) + p["kappa"] * p["p_a"] / p["gamma_a"])
    assert math.isclose(c.r0(), expected, rel_tol=1e-6)
    assert math.isclose(example("network_model").r0(), 3.0, rel_tol=1e-5)


def test_infected_compartments_detection():
    from epinetlang.runtime.r0_calculator import R0Calculator
    assert R0Calculator(example("covid_cameroon").model).infected_compartments() == ["E", "A", "I"]
    assert R0Calculator(example("seir_model").model).infected_compartments() == ["E", "I"]


def test_controlled_reproduction_number():
    c = example("covid_cameroon")
    assert math.isclose(c.rc(30), 0.45 * c.r0(), rel_tol=1e-6)
    assert math.isclose(c.rc(100), 0.75 * c.r0(), rel_tol=1e-6)
    assert math.isclose(c.rc(250), c.r0(), rel_tol=1e-6)


def test_rt_decreases_with_susceptibles():
    m = example("sir_model")
    res = m.simulate()
    t, r = m.rt(res, every=200)
    assert r[0] == pytest.approx(3 * 990 / 1000, rel=1e-4) and r[-1] < 1


def test_with_params_recomputes_derived():
    m = example("sir_model").with_params(R0=2.0)
    assert math.isclose(m.params["beta"], 0.2) and math.isclose(m.r0(), 2.0, rel_tol=1e-6)


def test_interventions_effect():
    c = example("covid_cameroon")
    with_iv = c.simulate()
    src = (EXAMPLES / "covid_cameroon.epi").read_text().split("    interventions {")[0] + \
        "simulation { t_end = 540; dt = 0.25; output_every = 4; } }"
    without = api.loads(src).simulate()
    assert with_iv.peak("I")[0] > without.peak("I")[0]             # pic retardé
    assert with_iv.final()["R"] > 0


def test_pulse_event_applied():
    src = """model M { parameters { g : rate = 0.0; }
      compartments { S = 100; I = 0; R = 0; }
      transitions { I -> R : g * I; }
      interventions { imp : at 5 { I += 7; S -> R : 0.5 * S; } }
      simulation { t_end = 10; dt = 1; } }"""
    for backend in ("compiled", "interpreted"):
        f = api.loads(src).simulate(backend=backend).final()
        assert f == {"S": 50.0, "I": 7.0, "R": 50.0}


# -- réseaux -----------------------------------------------------------------------------------
@pytest.mark.parametrize("kind, opts, expected_k", [
    ("erdos_renyi", {"mean_degree": 6}, 6),
    ("barabasi_albert", {"m": 3}, 6),
    ("watts_strogatz", {"k": 4, "rewiring": 0.2}, 4),
    ("regular", {"k": 6}, 6),
])
def test_network_generators(kind, opts, expected_k):
    from epinetlang.core.model import NetworkConfig
    net = Network.build(NetworkConfig(kind, 3000, opts), np.random.default_rng(0))
    assert abs(net.mean_degree - expected_k) < 0.3
    e = net.edges
    assert np.all(e[:, 0] != e[:, 1])
    keys = np.minimum(e[:, 0], e[:, 1]).astype(np.int64) * 3000 + np.maximum(e[:, 0], e[:, 1])
    assert len(np.unique(keys)) == len(keys)                         # pas d'arête multiple


def test_network_from_file(tmp_path):
    f = tmp_path / "g.csv"
    f.write_text("# arêtes\na,b\nb,c\nc,a\na,b\n")
    net = Network.from_file(str(f))
    assert net.n == 3 and len(net.edges) == 3


def test_scale_counts():
    c = scale_counts(np.array([27_999_900, 50, 20, 30, 0, 0.0]), 1000)
    assert c.sum() == 1000 and np.all(c[1:4] >= 1) and c[4] == 0


def test_network_simulation():
    m = example("network_model")
    res = m.simulate(seed=5)
    assert res.meta["nodes"] == 2000 and abs(res.meta["mean_degree"] - 6) < 0.1
    assert np.all(res.y.sum(axis=1) == 2000)
    assert res.final()["R"] > 500


def test_rk45_without_scipy_falls_back(monkeypatch):
    if importlib.util.find_spec("scipy") is None:
        pytest.skip("scipy déjà absent")
    import builtins
    real_import = builtins.__import__

    def fake(name, *a, **k):
        if name.startswith("scipy"):
            raise ImportError
        return real_import(name, *a, **k)

    monkeypatch.setattr(builtins, "__import__", fake)
    res = example("sir_model").simulate("rk45")
    assert res.meta.get("note", "").startswith("scipy absent")
