"""Tests des stratégies basse ressource (profil, mémoire, précision)."""
from pathlib import Path

import numpy as np
import pytest

from epinetlang import api
from epinetlang.adaptation.memory_optimizer import (DecimatingRecorder, MemoryOptimizer,
                                                    StreamingCSVRecorder)
from epinetlang.adaptation.precision_manager import PrecisionManager
from epinetlang.adaptation.strategies import AdaptationStrategy, ResourceProfile
from epinetlang.runtime.simulator import Simulator

EXAMPLES = Path(__file__).resolve().parent.parent / "examples"


def example(name):
    return api.load(EXAMPLES / f"{name}.epi")


# -- profils ---------------------------------------------------------------------------------
def test_profile_detection_and_presets(monkeypatch):
    monkeypatch.delenv("EPINET_PROFILE", raising=False)
    p = ResourceProfile.detect()
    assert p.name in ("minimal", "low", "standard", "high") and p.budget_mb > 0
    monkeypatch.setenv("EPINET_PROFILE", "minimal")
    assert ResourceProfile.detect().name == "minimal"
    with pytest.raises(ValueError):
        ResourceProfile.preset("inexistant")


# -- précision --------------------------------------------------------------------------------
def test_dtype_choice_depends_on_population_and_profile():
    pm = PrecisionManager()
    assert pm.choose_dtype(example("sir_model").model, "minimal") == np.float32
    assert pm.choose_dtype(example("sir_model").model, "standard") == np.float64
    assert pm.choose_dtype(example("covid_cameroon").model, "minimal") == np.float64


def test_float32_simulation_is_accurate_for_small_population():
    m = example("sir_model").model
    r32 = Simulator(m, dtype=np.float32).run()
    r64 = Simulator(m, dtype=np.float64).run()
    assert r32.y.dtype == np.float32
    assert np.max(np.abs(r32.y - r64.y)) < 1e-2
    assert PrecisionManager().check(r32, m).ok


def test_precision_fallback():
    m = example("sir_model").model
    pm = PrecisionManager(tolerance=1e-12)           # tolérance impossible en float32
    calls = []

    def run(dtype):
        calls.append(np.dtype(dtype).name)
        return Simulator(m, dtype=dtype).run(t_end=20)

    res, report = pm.run_with_fallback(run, m, np.float32)
    assert calls == ["float32", "float64"] and "precision_fallback" in res.meta


def test_conservation_not_checked_with_vital_dynamics():
    m = example("seir_model").model
    assert PrecisionManager().conservation_error(Simulator(m).run(t_end=10), m) is None


def test_kahan_sum():
    values = [1e8] + [1e-8] * 10_000
    assert abs(PrecisionManager.kahan_sum(values) - (1e8 + 1e-4)) < 1e-6


# -- mémoire --------------------------------------------------------------------------------
def test_memory_estimates():
    mo = MemoryOptimizer()
    b64 = mo.trajectory_bytes(10_000, 6, np.float64)
    b32 = mo.trajectory_bytes(10_000, 6, np.float32)
    assert b32 < b64
    assert mo.trajectory_bytes(10_000, 6, np.float64, output_every=10) < b64 / 5
    assert mo.network_bytes(10_000, 6, np.int32) < mo.network_bytes(10_000, 6, np.int64)


def test_output_every_respects_budget():
    mo = MemoryOptimizer()
    every = mo.choose_output_every(1_000_000, 6, np.float64, budget_bytes=1 << 20)
    assert mo.trajectory_bytes(1_000_000, 6, np.float64, every) <= 1 << 20


def test_streaming_recorder(tmp_path):
    m = example("sir_model").model
    path = tmp_path / "flux.csv"
    res = Simulator(m, recorder_factory=lambda: StreamingCSVRecorder(path)).run()
    assert len(res.t) == 0 and res.meta["csv"] == str(path)
    lines = path.read_text().splitlines()
    assert lines[0] == "t,S,I,R" and len(lines) == 1602


def test_decimating_recorder_bounds_memory():
    m = example("sir_model").model
    res = Simulator(m, recorder_factory=lambda: DecimatingRecorder(100)).run()
    assert len(res.t) <= 102 and res.t[0] == 0 and res.t[-1] == 160


# -- planification ------------------------------------------------------------------------------
def test_stability_reduces_dt():
    src = """model Raide { parameters { g : rate = 50; }
      compartments { A = 100; B = 0; }
      transitions { A -> B : g * A; }
      simulation { t_end = 1; dt = 0.1; method = rk4; } }"""
    m = api.loads(src)
    plan = AdaptationStrategy("standard").plan(m.model)
    assert plan.dt < 2.78 / 50 and any("instable" in n for n in plan.notes)
    naive = m.simulate()                          # dt = 0.1 : RK4 diverge (h·λ = 5)
    res, plan, report = m.run_adaptive("standard")
    assert naive.y.max() > 1e3
    assert res.y.max() <= 100 + 1e-9 and res.final()["B"] > 99.9
    assert np.allclose(res.t[:3], [0, 0.1, 0.2])  # même grille de sortie


def test_gillespie_switched_to_tau_leap_for_large_population():
    m = example("covid_cameroon").model
    plan = AdaptationStrategy("low").plan(m, method="gillespie")
    assert plan.method == "tau_leap"


def test_network_falls_back_to_mean_field_when_too_big():
    src = (EXAMPLES / "network_model.epi").read_text().replace("nodes = 2000", "nodes = 2_000_000")
    m = api.loads(src)
    plan = AdaptationStrategy("minimal").plan(m.model)
    assert plan.method == "rk4" and any("champ moyen" in n for n in plan.notes)
    assert AdaptationStrategy("high").plan(m.model).method == "network"


def test_minimal_profile_end_to_end(tmp_path):
    res, plan, report = example("sir_model").run_adaptive("minimal", csv_path=str(tmp_path / "s.csv"))
    assert plan.dtype == np.float32 and report.ok
    assert (tmp_path / "s.csv").exists()
    assert "Plan d'exécution" in res.meta["plan"]
