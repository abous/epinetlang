"""Tests du système de types (dimensions) et du vérificateur sémantique."""
import pytest

from epinetlang.core.errors import EpiSemanticError
from epinetlang.core.types import DIMENSIONLESS, FLOW, POPULATION, RATE, TIME, Dim, TypeChecker
from epinetlang.core.validator import validate
from epinetlang.grammar.parser import parse


def check(body: str):
    return validate(parse(f"model M {{ {body} }}").models[0])


def codes(report):
    return [(d.severity, d.code) for d in report.diagnostics]


BASE = """
parameters { N : count = 1000; beta : rate = 0.3; gamma : rate = 0.1; p : probability = 0.5; }
compartments { S = N - 1; I = 1; R = 0; }
"""


# -- algèbre des dimensions ------------------------------------------------------------
def test_dim_algebra():
    assert RATE * POPULATION == FLOW
    assert POPULATION / POPULATION == DIMENSIONLESS
    assert str(FLOW) == "individus·temps⁻¹"
    assert str(POPULATION ** 2 / TIME) == "individus²·temps⁻¹"
    assert (POPULATION ** 2) ** 0.5 == POPULATION


def infer(expr: str, symbols=None):
    diags = []
    e = parse(f"model M {{ parameters {{ x = {expr}; }} }}").models[0].parameters[0].value
    syms = {"S": POPULATION, "I": POPULATION, "N": POPULATION, "beta": RATE, "k": DIMENSIONLESS}
    return TypeChecker(syms if symbols is None else symbols, {"S", "I"}, diags).infer(e), diags


@pytest.mark.parametrize("expr, dim", [
    ("beta * S * I / N", FLOW),
    ("beta * S * contact(I)", FLOW),
    ("beta * S", FLOW),
    ("S / N", DIMENSIONLESS),
    ("exp(-k) * beta", RATE),
    ("sqrt(S * N)", POPULATION),
    ("t * beta", DIMENSIONLESS),
    ("total()", POPULATION),
    ("min(S, N)", POPULATION),
    ("0.01 * S", None),            # littéral polymorphe : non vérifiable
])
def test_inference(expr, dim):
    d, diags = infer(expr)
    assert not diags and d == dim


@pytest.mark.parametrize("expr, msg", [
    ("S + beta", "incompatibles"),
    ("exp(S)", "sans dimension"),
    ("S ^ beta", "exposant"),
    ("contact(beta)", "compartiment"),
    ("foo(S)", "inconnue"),
    ("min(S)", "au moins 2"),
    ("undefined_name", "non déclaré"),
])
def test_type_errors(expr, msg):
    _, diags = infer(expr)
    assert diags and msg in diags[0].message


# -- validateur ----------------------------------------------------------------------------
def test_valid_model():
    r = check(BASE + "transitions { S -> I : beta * S * I / N; I -> R : gamma * I; }")
    assert r.ok and not r.warnings


def test_missing_division_by_N_is_detected():
    r = check(BASE + "transitions { S -> I : beta * S * I; I -> R : gamma * I; }")
    assert not r.ok
    assert "individus²·temps⁻¹" in r.errors[0].message and "N" in r.errors[0].hint


def test_rate_without_compartment():
    r = check(BASE + "transitions { I -> R : gamma; }")
    assert "multiplier par le compartiment" in r.errors[0].hint


def test_domain_errors():
    r = check("parameters { p : probability = 1.5; g : rate = -0.1; } compartments { S = -3; }")
    msgs = " ".join(d.message for d in r.errors)
    assert "[0, 1]" in msgs and "rate" in msgs and "« S »" in msgs


def test_declared_type_dimension():
    r = check("parameters { N : count = 10; g : rate = N; }")
    assert r.errors[0].code == "TYP"


def test_unknown_type():
    assert "inconnu" in check("parameters { x : vitesse = 1; }").errors[0].message


def test_use_before_declaration():
    r = check("parameters { beta : rate = R0 * gamma; R0 : real = 3; gamma : rate = 0.1; }")
    assert "avant sa déclaration" in r.errors[0].message


def test_duplicates_and_reserved():
    r = check("parameters { t = 1; x = 1; x = 2; } compartments { x = 0; }")
    msgs = [d.message for d in r.errors]
    assert any("réservé" in m for m in msgs) and sum("deux fois" in m for m in msgs) == 2


def test_transition_errors():
    r = check(BASE + "transitions { S -> Z : beta*S; S -> S : beta*S; * -> * : 1; }")
    msgs = " ".join(d.message for d in r.errors)
    assert "« Z » non déclaré" in msgs and "identiques" in msgs and "n'a pas de sens" in msgs


def test_warning_rate_independent_of_source():
    r = check(BASE + "transitions { S -> I : beta * N; I -> R : gamma * I; }")
    assert r.ok and any("ne dépend pas" in w.message for w in r.warnings)


def test_neighbours_requires_network():
    r = check(BASE + "transitions { S -> I : beta * S * neighbours(I); I -> R : gamma*I; }")
    assert any(d.code == "RES" for d in r.errors)


def test_network_validation():
    r = check(BASE + "transitions { S -> I : beta*S*neighbours(I); I -> R : gamma*I; }"
                     "network { type = barabasi_albert; nodes = 100; m = 150; }")
    assert any("m < nodes" in d.message for d in r.errors)
    r = check(BASE + "network { type = watts_strogatz; nodes = 100; k = 3; }")
    assert any("pair" in d.message for d in r.errors)
    r = check(BASE + "network { type = hexagonal; nodes = 10; }")
    assert any("inconnu" in d.message for d in r.errors)


def test_intervention_rules():
    r = check(BASE + """transitions { S -> I : beta*S*I/N; I -> R : gamma*I; }
      interventions {
        a : from 50 to 20 { beta *= 0.5; }
        b : from 10 to 20 { I += 5; }
        c : at 30 { beta *= S; }
        d : at 40 { inconnu = 1; }
        e : at 50 { S -> R : 0.1 * S; }
      }""")
    msgs = [d.message for d in r.errors]
    assert any("doit suivre" in m for m in msgs)                      # a
    assert any("interdite dans une fenêtre" in m for m in msgs)       # b
    assert any("« beta *= … »" in m for m in msgs)                    # c (doit être sans dimension)
    assert any("ni un paramètre" in m for m in msgs)                  # d
    assert not any("« e »" in m for m in msgs)                        # e : transfert valide


def test_simulation_settings():
    r = check(BASE + "simulation { t_end = 10; dt = 20; method = magic; foo = 1; }")
    msgs = " ".join(d.message for d in r.errors)
    assert "magic" in msgs and "foo" in msgs and "dt est plus grand" in msgs


def test_raise_if_errors():
    with pytest.raises(EpiSemanticError):
        validate(parse("model M { compartments { S = x; } }").models[0], raise_on_error=True)
