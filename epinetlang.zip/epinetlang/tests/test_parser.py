"""Tests de l'analyse lexicale et syntaxique."""
import re
from pathlib import Path

import pytest

from epinetlang.core import ast
from epinetlang.core.errors import EpiSyntaxError
from epinetlang.grammar.lexer import tokenize
from epinetlang.grammar.parser import parse

EXAMPLES = Path(__file__).resolve().parent.parent / "examples"


def types(src):
    return [t.type for t in tokenize(src)]


# -- lexer -------------------------------------------------------------------------
def test_lexer_symbols_and_keywords():
    assert types("model X { S -> I : a*b; }") == [
        "model", "ID", "{", "ID", "->", "ID", ":", "ID", "*", "ID", ";", "}", "EOF"]


def test_lexer_numbers():
    toks = tokenize("28_000_000 0.5 .25 1e-3 2.5E+2")
    assert [t.value for t in toks[:-1]] == [28e6, 0.5, 0.25, 1e-3, 250.0]


def test_lexer_comments_and_positions():
    toks = tokenize("// commentaire\n# autre\n/* bloc\n sur deux lignes */ beta")
    assert toks[0].type == "ID" and toks[0].pos.line == 4 and toks[0].pos.column == 21


def test_lexer_compound_assign():
    assert types("beta *= 0.5; I += 3; x -= 1; y /= 2;")[:3] == ["ID", "*=", "NUMBER"]


def test_lexer_unicode_identifiers():
    assert tokenize("guérison")[0].value == "guérison"


def test_lexer_errors():
    with pytest.raises(EpiSyntaxError, match="caractère inattendu"):
        tokenize("beta @ 2")
    with pytest.raises(EpiSyntaxError, match="non terminé"):
        tokenize("/* jamais fermé")


# -- parser ------------------------------------------------------------------------
SIR = """
model SIR {
  parameters { N : count = 1000; beta : rate = 0.3; gamma : rate = 0.1; }
  compartments { S = N - 1; I = 1; R; }
  transitions {
    infection : S -> I : beta * S * I / N;
    I -> R : gamma * I;
  }
  simulation { t_end = 100; method = rk4; }
}
"""


def test_parse_sir_structure():
    m = parse(SIR).models[0]
    assert m.name == "SIR"
    assert [p.name for p in m.parameters] == ["N", "beta", "gamma"]
    assert [p.type_name for p in m.parameters] == ["count", "rate", "rate"]
    assert [c.name for c in m.compartments] == ["S", "I", "R"]
    assert m.compartments[2].initial == ast.Number(0.0)
    t0, t1 = m.transitions
    assert (t0.label, t0.source, t0.target) == ("infection", "S", "I")
    assert t1.label is None and t1.source == "I"


def test_operator_precedence():
    e = parse("model M { parameters { x = 1 + 2 * 3 ^ 2 ^ 1; y = -2^2; } }").models[0].parameters
    assert ast.expr_to_str(e[0].value) == "1 + 2 * 3^2^1"
    root = e[0].value
    assert isinstance(root, ast.BinOp) and root.op == "+"
    pw = root.right.right
    assert pw.op == "^" and isinstance(pw.right, ast.BinOp)        # associativité à droite
    neg = e[1].value
    assert isinstance(neg, ast.UnaryOp) and neg.operand.op == "^"  # -(2^2)


def test_external_endpoints_and_calls():
    src = "model M { transitions { * -> S : mu * total(); S -> * : mu*S; S -> E : b*S*contact(I); } }"
    trs = parse(src).models[0].transitions
    assert trs[0].source is None and trs[1].target is None
    assert isinstance(trs[0].rate.right, ast.Call) and trs[0].rate.right.func == "total"
    assert ast.calls_in(trs[2].rate, "contact")[0].args[0].id == "I"


def test_interventions():
    src = """model M { interventions {
        conf : from 20 to 60 { beta *= 0.5; S -> R : 0.01 * S; }
        imp  : at 50 { I += 10; }
        perm : from 100 { gamma = 0.2; }
    } }"""
    ivs = parse(src).models[0].interventions
    assert [iv.kind for iv in ivs] == ["window", "pulse", "window"]
    assert ivs[0].assigns[0].op == "*=" and ivs[0].transitions[0].target == "R"
    assert ivs[1].assigns[0].target == "I" and ivs[2].end is None


def test_network_settings_and_keyword_values():
    src = 'model M { network { type = barabasi_albert; nodes = 500; file = "g.csv"; } simulation { method = network; } }'
    m = parse(src).models[0]
    assert [s.key for s in m.network] == ["type", "nodes", "file"]
    assert m.network[2].value == "g.csv"
    assert m.simulation[0].value == ast.Name("network")


def test_multiple_models():
    p = parse("model A { } model B { }")
    assert [m.name for m in p.models] == ["A", "B"]


@pytest.mark.parametrize("src, msg", [
    ("model M { parameters { beta = 0.3 } }", "';' attendu"),
    ("model M { foo { } }", "section inconnue"),
    ("model M { transitions { S -> : 1; } }", "compartiment"),
    ("model M { parameters { x = (1 + 2; } }", "')' attendu"),
    ("model M { parameters { } parameters { } }", "deux fois"),
    ("", "aucun modèle"),
])
def test_syntax_errors(src, msg):
    with pytest.raises(EpiSyntaxError, match=re.escape(msg)):
        parse(src)


def test_error_position():
    with pytest.raises(EpiSyntaxError) as exc:
        parse("model M {\n  parameters {\n    beta = 0.3\n  }\n}", "f.epi")
    assert exc.value.diagnostic.pos.line == 4


def test_roundtrip_expressions():
    src = "model M { parameters { x = a * (b + c) / (d - e) - -f; } }"
    e = parse(src).models[0].parameters[0].value
    again = parse(f"model M {{ parameters {{ x = {ast.expr_to_str(e)}; }} }}").models[0].parameters[0].value
    assert again == e


@pytest.mark.parametrize("path", sorted(EXAMPLES.glob("*.epi")), ids=lambda p: p.name)
def test_examples_parse(path):
    assert parse(path.read_text(encoding="utf-8"), str(path)).models
