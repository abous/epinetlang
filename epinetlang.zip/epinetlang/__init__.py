"""EpiNetLang — langage dédié à la modélisation épidémiologique sur réseaux.

Chaîne de compilation : lexer → parser → AST → validateur (types et
dimensions) → modèle → IR → optimiseur → backends (Python, Julia, C++, mobile).
"""
from .api import Model, compile_file, load, loads
from .core.errors import EpiNetLangError, EpiRuntimeError, EpiSemanticError, EpiSyntaxError

__version__ = "1.0.0"
__all__ = ["Model", "load", "loads", "compile_file", "EpiNetLangError", "EpiSyntaxError",
           "EpiSemanticError", "EpiRuntimeError", "__version__"]
