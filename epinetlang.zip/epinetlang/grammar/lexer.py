"""Analyseur lexical d'EpiNetLang (écrit à la main, sans dépendance).

Le type d'un jeton est soit ``NUMBER``, ``STRING``, ``ID``, ``EOF``,
soit le texte même du mot-clé ou du symbole (``'model'``, ``'->'``, ``'{'``…),
ce qui simplifie l'écriture de l'analyseur syntaxique.
"""
from __future__ import annotations

from dataclasses import dataclass

from ..core.errors import EpiSyntaxError, SourcePos

KEYWORDS = frozenset({
    "model", "parameters", "compartments", "transitions", "network",
    "interventions", "simulation", "from", "to", "at",
})

# Ordre important : symboles longs d'abord.
SYMBOLS = ("->", "+=", "-=", "*=", "/=",
           "{", "}", "(", ")", ";", ":", ",", "=", "+", "-", "*", "/", "^")


@dataclass(frozen=True)
class Token:
    type: str
    value: object
    pos: SourcePos

    def __repr__(self) -> str:
        return f"Token({self.type}, {self.value!r}, {self.pos.line}:{self.pos.column})"


class Lexer:
    def __init__(self, source: str, filename: str = "<source>"):
        self.src = source
        self.filename = filename
        self.i = 0
        self.line = 1
        self.col = 1

    # -- utilitaires ---------------------------------------------------------
    def _pos(self) -> SourcePos:
        return SourcePos(self.line, self.col, self.filename)

    def _peek(self, k: int = 0) -> str:
        j = self.i + k
        return self.src[j] if j < len(self.src) else ""

    def _advance(self, n: int = 1) -> str:
        text = self.src[self.i:self.i + n]
        for ch in text:
            if ch == "\n":
                self.line += 1
                self.col = 1
            else:
                self.col += 1
        self.i += n
        return text

    # -- espaces et commentaires ---------------------------------------------
    def _skip_trivia(self) -> None:
        while self.i < len(self.src):
            ch = self._peek()
            if ch in " \t\r\n﻿":
                self._advance()
            elif ch == "#" or (ch == "/" and self._peek(1) == "/"):
                while self.i < len(self.src) and self._peek() != "\n":
                    self._advance()
            elif ch == "/" and self._peek(1) == "*":
                start = self._pos()
                self._advance(2)
                while not (self._peek() == "*" and self._peek(1) == "/"):
                    if self.i >= len(self.src):
                        raise EpiSyntaxError("commentaire /* … */ non terminé", start)
                    self._advance()
                self._advance(2)
            else:
                return

    # -- jetons ----------------------------------------------------------------
    def _number(self) -> Token:
        pos = self._pos()
        start = self.i
        while self._peek().isdigit() or self._peek() == "_":
            self._advance()
        if self._peek() == "." and self._peek(1).isdigit() or (self._peek() == "." and start == self.i):
            self._advance()
            while self._peek().isdigit() or self._peek() == "_":
                self._advance()
        if self._peek() in ("e", "E") and (self._peek(1).isdigit() or
                                           (self._peek(1) in "+-" and self._peek(2).isdigit())):
            self._advance(2)
            while self._peek().isdigit():
                self._advance()
        text = self.src[start:self.i].replace("_", "")
        try:
            value = float(text)
        except ValueError:
            raise EpiSyntaxError(f"nombre mal formé « {self.src[start:self.i]} »", pos) from None
        return Token("NUMBER", value, pos)

    def _string(self) -> Token:
        pos = self._pos()
        quote = self._advance()
        chars = []
        while self._peek() != quote:
            if self.i >= len(self.src) or self._peek() == "\n":
                raise EpiSyntaxError("chaîne de caractères non terminée", pos)
            if self._peek() == "\\":
                self._advance()
            chars.append(self._advance())
        self._advance()
        return Token("STRING", "".join(chars), pos)

    def _ident(self) -> Token:
        pos = self._pos()
        start = self.i
        while self._peek().isalnum() or self._peek() == "_":
            self._advance()
        text = self.src[start:self.i]
        return Token(text if text in KEYWORDS else "ID", text, pos)

    def tokenize(self) -> list[Token]:
        tokens: list[Token] = []
        while True:
            self._skip_trivia()
            if self.i >= len(self.src):
                tokens.append(Token("EOF", None, self._pos()))
                return tokens
            ch = self._peek()
            if ch.isdigit() or (ch == "." and self._peek(1).isdigit()):
                tokens.append(self._number())
            elif ch.isalpha() or ch == "_":
                tokens.append(self._ident())
            elif ch in "\"'":
                tokens.append(self._string())
            else:
                for sym in SYMBOLS:
                    if self.src.startswith(sym, self.i):
                        tokens.append(Token(sym, sym, self._pos()))
                        self._advance(len(sym))
                        break
                else:
                    raise EpiSyntaxError(f"caractère inattendu « {ch} »", self._pos())


def tokenize(source: str, filename: str = "<source>") -> list[Token]:
    return Lexer(source, filename).tokenize()
