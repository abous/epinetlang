/*
 * EpiNetLang — grammaire de référence (ANTLR 4)
 *
 * Langage dédié à la modélisation épidémiologique compartimentale,
 * déterministe, stochastique et sur réseaux.
 *
 * Le compilateur Python utilise un analyseur écrit à la main
 * (grammar/lexer.py, grammar/parser.py) qui suit exactement cette grammaire,
 * pour ne pas dépendre du runtime ANTLR sur les machines à faibles ressources.
 * Pour générer un analyseur ANTLR équivalent :
 *     antlr4 -Dlanguage=Python3 -visitor EpiNetLang.g4
 */
grammar EpiNetLang;

program        : modelDecl+ EOF ;

modelDecl      : 'model' ID '{' section* '}' ;

section        : parametersSec
               | compartmentsSec
               | transitionsSec
               | networkSec
               | interventionsSec
               | simulationSec
               ;

parametersSec    : 'parameters'    '{' paramDecl* '}' ;
compartmentsSec  : 'compartments'  '{' compartmentDecl* '}' ;
transitionsSec   : 'transitions'   '{' transition* '}' ;
networkSec       : 'network'       '{' setting* '}' ;
interventionsSec : 'interventions' '{' intervention* '}' ;
simulationSec    : 'simulation'    '{' setting* '}' ;

// beta : rate = 0.3 ;      (type : rate | probability | count | real | time)
paramDecl        : ID (':' ID)? '=' expr ';' ;

// S = N - 10 ;
compartmentDecl  : ID ('=' expr)? ';' ;

// infection : S -> I : beta * S * I / N ;      '*' = extérieur du système
transition       : (ID ':')? endpoint '->' endpoint ':' expr ';' ;
endpoint         : ID | '*' ;

// type = barabasi_albert ;   file = "contacts.csv" ;
setting          : ID '=' (expr | STRING) ';' ;

// confinement : from 20 to 60 { beta *= 0.5 ; }
// importation : at 50 { I += 10 ; }
intervention     : ID ':' ( 'from' expr ('to' expr)? | 'at' expr ) '{' interventionStmt* '}' ;
interventionStmt : transition
                 | ID assignOp expr ';'
                 ;
assignOp         : '=' | '+=' | '-=' | '*=' | '/=' ;

// Expressions arithmétiques ; '^' est associatif à droite et prioritaire sur le '-' unaire
expr             : term (('+' | '-') term)* ;
term             : unary (('*' | '/') unary)* ;
unary            : ('-' | '+') unary | power ;
power            : primary ('^' unary)? ;
primary          : NUMBER
                 | ID '(' (expr (',' expr)*)? ')'      // exp, log, sqrt, min, max, contact, neighbours, total, step…
                 | ID
                 | '(' expr ')'
                 ;

// ---------------------------------------------------------------- Lexique
NUMBER  : DIGITS ('.' DIGITS?)? EXPONENT? | '.' DIGITS EXPONENT? ;
fragment DIGITS   : [0-9] [0-9_]* ;
fragment EXPONENT : [eE] [+-]? [0-9]+ ;
STRING  : '"' (~["\r\n])* '"' | '\'' (~['\r\n])* '\'' ;
ID      : [\p{L}_] [\p{L}\p{N}_]* ;

LINE_COMMENT  : ('//' | '#') ~[\r\n]* -> skip ;
BLOCK_COMMENT : '/*' .*? '*/' -> skip ;
WS            : [ \t\r\n﻿]+ -> skip ;
