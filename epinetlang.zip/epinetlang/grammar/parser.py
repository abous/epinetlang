"""Analyseur syntaxique descendant récursif d'EpiNetLang.

Il implémente exactement la grammaire de ``EpiNetLang.g4`` (référence formelle),
mais sans dépendre du runtime ANTLR : c'est un choix délibéré pour pouvoir
exécuter le compilateur sur des machines à faibles ressources.
"""
from __future__ import annotations

from ..core import ast
from ..core.errors import EpiSyntaxError
from .lexer import KEYWORDS, Token, tokenize

SECTIONS = ("parameters", "compartments", "transitions", "network", "interventions", "simulation")
ASSIGN_OPS = ("=", "+=", "-=", "*=", "/=")


class Parser:
    def __init__(self, tokens: list[Token], filename: str = "<source>"):
        self.tokens = tokens
        self.k = 0
        self.filename = filename

    # -- navigation -----------------------------------------------------------
    def peek(self, offset: int = 0) -> Token:
        return self.tokens[min(self.k + offset, len(self.tokens) - 1)]

    def check(self, *types: str) -> bool:
        return self.peek().type in types

    def advance(self) -> Token:
        tok = self.peek()
        if tok.type != "EOF":
            self.k += 1
        return tok

    def match(self, *types: str) -> Token | None:
        return self.advance() if self.check(*types) else None

    def expect(self, type_: str, what: str | None = None) -> Token:
        if self.check(type_):
            return self.advance()
        tok = self.peek()
        found = "fin de fichier" if tok.type == "EOF" else f"« {tok.value} »"
        hint = None
        if type_ == ";":
            hint = "chaque déclaration se termine par un point-virgule"
        elif type_ == "}":
            hint = "accolade fermante manquante ?"
        raise EpiSyntaxError(f"{what or repr(type_)} attendu, trouvé {found}", tok.pos, hint)

    # -- programme ------------------------------------------------------------
    def parse_program(self) -> ast.Program:
        start = self.peek().pos
        models = []
        while not self.check("EOF"):
            models.append(self.parse_model())
        if not models:
            raise EpiSyntaxError("aucun modèle déclaré (mot-clé « model » attendu)", start)
        return ast.Program(models, pos=start)

    def parse_model(self) -> ast.ModelDecl:
        kw = self.expect("model", "« model »")
        name = self.expect("ID", "nom du modèle").value
        model = ast.ModelDecl(name, pos=kw.pos)
        self.expect("{")
        seen = set()
        while not self.check("}"):
            tok = self.peek()
            if tok.type not in SECTIONS:
                raise EpiSyntaxError(
                    f"section inconnue « {tok.value} »", tok.pos,
                    "sections possibles : " + ", ".join(SECTIONS))
            if tok.type in seen:
                raise EpiSyntaxError(f"section « {tok.type} » déclarée deux fois", tok.pos)
            seen.add(tok.type)
            getattr(self, f"parse_{tok.type}")(model)
        self.expect("}")
        return model

    # -- sections -------------------------------------------------------------
    def parse_parameters(self, model: ast.ModelDecl) -> None:
        self.advance()
        self.expect("{")
        while not self.check("}"):
            name = self.expect("ID", "nom de paramètre")
            type_name = "real"
            if self.match(":"):
                type_name = self.expect("ID", "type du paramètre (rate, probability, count, real, time)").value
            self.expect("=")
            value = self.parse_expr()
            self.expect(";")
            model.parameters.append(ast.ParamDecl(name.value, type_name, value, pos=name.pos))
        self.expect("}")

    def parse_compartments(self, model: ast.ModelDecl) -> None:
        self.advance()
        self.expect("{")
        while not self.check("}"):
            name = self.expect("ID", "nom de compartiment")
            init: ast.Expr = ast.Number(0.0, pos=name.pos)
            if self.match("="):
                init = self.parse_expr()
            self.expect(";")
            model.compartments.append(ast.CompartmentDecl(name.value, init, pos=name.pos))
        self.expect("}")

    def parse_transitions(self, model: ast.ModelDecl) -> None:
        self.advance()
        self.expect("{")
        while not self.check("}"):
            model.transitions.append(self.parse_transition())
        self.expect("}")

    def _endpoint(self) -> str | None:
        if self.match("*"):
            return None
        return self.expect("ID", "compartiment ou « * »").value

    def parse_transition(self) -> ast.TransitionDecl:
        pos = self.peek().pos
        label = None
        if self.check("ID") and self.peek(1).type == ":":
            label = self.advance().value
            self.advance()
        source = self._endpoint()
        self.expect("->", "« -> »")
        target = self._endpoint()
        self.expect(":", "« : » suivi du taux de la transition")
        rate = self.parse_expr()
        self.expect(";")
        return ast.TransitionDecl(label, source, target, rate, pos=pos)

    def _settings(self) -> list[ast.Setting]:
        self.advance()
        self.expect("{")
        out = []
        while not self.check("}"):
            key = self.expect("ID", "nom de réglage")
            self.expect("=")
            if self.check("STRING"):
                value = self.advance().value
            elif self.peek().type in KEYWORDS and self.peek(1).type == ";":
                tok = self.advance()                 # ex. « method = network; »
                value = ast.Name(tok.value, pos=tok.pos)
            else:
                value = self.parse_expr()
            self.expect(";")
            out.append(ast.Setting(key.value, value, pos=key.pos))
        self.expect("}")
        return out

    def parse_network(self, model: ast.ModelDecl) -> None:
        model.network = self._settings()

    def parse_simulation(self, model: ast.ModelDecl) -> None:
        model.simulation = self._settings()

    def parse_interventions(self, model: ast.ModelDecl) -> None:
        self.advance()
        self.expect("{")
        while not self.check("}"):
            name = self.expect("ID", "nom de l'intervention")
            self.expect(":")
            if self.match("from"):
                start = self.parse_expr()
                end = self.parse_expr() if self.match("to") else None
                iv = ast.InterventionDecl(name.value, "window", start, end, pos=name.pos)
            elif self.match("at"):
                iv = ast.InterventionDecl(name.value, "pulse", self.parse_expr(), None, pos=name.pos)
            else:
                raise EpiSyntaxError("« from … to … » ou « at … » attendu", self.peek().pos)
            self.expect("{")
            while not self.check("}"):
                is_transition = (self.check("*") or
                                 (self.check("ID") and self.peek(1).type in ("->", ":")))
                if is_transition:
                    iv.transitions.append(self.parse_transition())
                else:
                    target = self.expect("ID", "paramètre ou compartiment")
                    op = self.peek()
                    if op.type not in ASSIGN_OPS:
                        raise EpiSyntaxError("opérateur d'affectation attendu (=, +=, -=, *=, /=)", op.pos)
                    self.advance()
                    value = self.parse_expr()
                    self.expect(";")
                    iv.assigns.append(ast.Assign(target.value, op.type, value, pos=target.pos))
            self.expect("}")
            model.interventions.append(iv)
        self.expect("}")

    # -- expressions ------------------------------------------------------------
    def parse_expr(self) -> ast.Expr:
        left = self.parse_term()
        while self.check("+", "-"):
            op = self.advance()
            left = ast.BinOp(op.type, left, self.parse_term(), pos=op.pos)
        return left

    def parse_term(self) -> ast.Expr:
        left = self.parse_unary()
        while self.check("*", "/"):
            op = self.advance()
            left = ast.BinOp(op.type, left, self.parse_unary(), pos=op.pos)
        return left

    def parse_unary(self) -> ast.Expr:
        if self.check("-", "+"):
            op = self.advance()
            operand = self.parse_unary()
            return operand if op.type == "+" else ast.UnaryOp("-", operand, pos=op.pos)
        return self.parse_power()

    def parse_power(self) -> ast.Expr:
        base = self.parse_primary()
        if self.check("^"):
            op = self.advance()
            return ast.BinOp("^", base, self.parse_unary(), pos=op.pos)  # associatif à droite
        return base

    def parse_primary(self) -> ast.Expr:
        tok = self.peek()
        if tok.type == "NUMBER":
            self.advance()
            return ast.Number(tok.value, pos=tok.pos)
        if tok.type == "ID":
            self.advance()
            if self.match("("):
                args = []
                if not self.check(")"):
                    args.append(self.parse_expr())
                    while self.match(","):
                        args.append(self.parse_expr())
                self.expect(")")
                return ast.Call(tok.value, args, pos=tok.pos)
            return ast.Name(tok.value, pos=tok.pos)
        if tok.type == "(":
            self.advance()
            e = self.parse_expr()
            self.expect(")")
            return e
        found = "fin de fichier" if tok.type == "EOF" else f"« {tok.value} »"
        raise EpiSyntaxError(f"expression attendue, trouvé {found}", tok.pos)


def parse(source: str, filename: str = "<source>") -> ast.Program:
    """Source → AST. Lève ``EpiSyntaxError`` en cas d'erreur."""
    return Parser(tokenize(source, filename), filename).parse_program()
