"""API Python d'EpiNetLang.

    >>> from epinetlang import api
    >>> m = api.load("examples/sir_model.epi")
    >>> m.r0()
    3.0
    >>> res = m.simulate()                 # code compilé, méthode du fichier (rk4)
    >>> res.peak("I")
    >>> m.with_params(R0=2.5).simulate()   # paramètres dérivés recalculés
    >>> m.compile("cpp").write("sir.cpp")
"""
from __future__ import annotations

from pathlib import Path

import numpy as np

from .adaptation.strategies import AdaptationStrategy, ExecutionPlan
from .compiler.codegen import CodeGenerator, CompilationResult, load_model
from .core.model import EpidemicModel
from .core.validator import ValidationReport
from .runtime.r0_calculator import R0Calculator
from .runtime.simulator import EnsembleResult, SimulationResult, Simulator


class Model:
    """Modèle EpiNetLang chargé et validé, prêt à être simulé ou compilé."""

    def __init__(self, model: EpidemicModel, report: ValidationReport, source: str = ""):
        self.model = model
        self.report = report
        self.source = source

    # -- informations ------------------------------------------------------------
    @property
    def name(self) -> str:
        return self.model.name

    @property
    def params(self) -> dict[str, float]:
        return dict(self.model.params)

    @property
    def compartments(self) -> list[str]:
        return list(self.model.compartments)

    @property
    def warnings(self):
        return self.report.warnings

    def describe(self) -> str:
        return self.model.describe()

    def with_params(self, **overrides: float) -> "Model":
        return Model(self.model.with_overrides(**overrides), self.report, self.source)

    # -- simulation ------------------------------------------------------------------
    def simulate(self, method: str | None = None, backend: str = "compiled", dtype=np.float64,
                 **kw) -> SimulationResult:
        return Simulator(self.model, backend=backend, dtype=dtype).run(method=method, **kw)

    def ensemble(self, n_runs: int = 50, method: str = "tau_leap", seed: int = 0, **kw) -> EnsembleResult:
        return Simulator(self.model).run_ensemble(n_runs, method=method, seed=seed, **kw)

    def run_adaptive(self, profile: str | None = None, csv_path: str | None = None, **kw):
        """Simulation pilotée par les stratégies basse ressource."""
        return AdaptationStrategy(profile).execute(self.model, csv_path=csv_path, **kw)

    def plan(self, profile: str | None = None) -> ExecutionPlan:
        return AdaptationStrategy(profile).plan(self.model)

    # -- analyse ------------------------------------------------------------------------
    def r0(self) -> float:
        return R0Calculator(self.model).r0()

    def rc(self, t: float, dfe: str = "initial") -> float:
        return R0Calculator(self.model).rc(t, dfe)

    def rt(self, result: SimulationResult, every: int = 1):
        return R0Calculator(self.model).rt(result.t, result.y, every)

    def r0_report(self) -> str:
        return R0Calculator(self.model).report()

    # -- compilation -----------------------------------------------------------------
    def compile(self, target: str = "python", opt_level: int = 2) -> CompilationResult:
        return CodeGenerator(target, opt_level).compile_model(self.model, self.report)

    def ir(self, opt_level: int = 2) -> str:
        return self.compile("python", opt_level).optimized.dump()

    def __repr__(self) -> str:
        return (f"<Model {self.name}: {len(self.compartments)} compartiments, "
                f"{len(self.model.transitions)} transitions>")


def loads(source: str, filename: str = "<source>", model_name: str | None = None) -> Model:
    model, report = load_model(source, filename, model_name)
    return Model(model, report, source)


def load(path: str | Path, model_name: str | None = None) -> Model:
    path = Path(path)
    return loads(path.read_text(encoding="utf-8"), str(path), model_name)


def compile_file(path: str | Path, target: str = "python", opt_level: int = 2,
                 output: str | Path | None = None) -> CompilationResult:
    result = CodeGenerator(target, opt_level).compile_file(path)
    if output:
        result.write(output)
    return result


__all__ = ["Model", "load", "loads", "compile_file"]
